/**
  ******************************************************************************
  * @file    stm32l0xx_hal_flash.c
  * @author  MCD Application Team
  * @brief   FLASH HAL module driver.
  ******************************************************************************
  */

#include "stm32l0xx_hal.h"

#ifdef HAL_FLASH_MODULE_ENABLED

FLASH_ProcessTypeDef pFlash;

extern volatile uint32_t g_eeprom_guard_hits;
extern volatile uint32_t g_eeprom_guard_last_addr;

static void FLASH_SetErrorCode(void);
extern void FLASH_PageErase(uint32_t PageAddress);

HAL_StatusTypeDef HAL_FLASH_Program(uint32_t TypeProgram, uint32_t Address, uint32_t Data)
{
  HAL_StatusTypeDef status = HAL_ERROR;

  __HAL_LOCK(&pFlash);

  assert_param(IS_FLASH_TYPEPROGRAM(TypeProgram));
  assert_param(IS_FLASH_PROGRAM_ADDRESS(Address));

  status = FLASH_WaitForLastOperation(FLASH_TIMEOUT_VALUE);

  if(status == HAL_OK)
  {
    pFlash.ErrorCode = HAL_FLASH_ERROR_NONE;
    *(__IO uint32_t *)Address = Data;
    status = FLASH_WaitForLastOperation(FLASH_TIMEOUT_VALUE);
  }

  __HAL_UNLOCK(&pFlash);

  return status;
}

HAL_StatusTypeDef HAL_FLASH_Program_IT(uint32_t TypeProgram, uint32_t Address, uint32_t Data)
{
  HAL_StatusTypeDef status = HAL_OK;

  __HAL_LOCK(&pFlash);

  assert_param(IS_FLASH_TYPEPROGRAM(TypeProgram));
  assert_param(IS_FLASH_PROGRAM_ADDRESS(Address));

  __HAL_FLASH_ENABLE_IT(FLASH_IT_EOP | FLASH_IT_ERR);

  pFlash.Address = Address;
  pFlash.ProcedureOnGoing = FLASH_PROC_PROGRAM;
  pFlash.ErrorCode = HAL_FLASH_ERROR_NONE;

  if(TypeProgram == FLASH_TYPEPROGRAM_WORD)
  {
    *(__IO uint32_t *)Address = Data;
  }
  return status;
}

void HAL_FLASH_IRQHandler(void)
{
  uint32_t addresstmp = 0;

  if( __HAL_FLASH_GET_FLAG(FLASH_FLAG_WRPERR)     ||
      __HAL_FLASH_GET_FLAG(FLASH_FLAG_PGAERR)     ||
      __HAL_FLASH_GET_FLAG(FLASH_FLAG_SIZERR)     ||
      __HAL_FLASH_GET_FLAG(FLASH_FLAG_OPTVERR)    ||
      __HAL_FLASH_GET_FLAG(FLASH_FLAG_RDERR)      ||
      __HAL_FLASH_GET_FLAG(FLASH_FLAG_FWWERR)     ||
      __HAL_FLASH_GET_FLAG(FLASH_FLAG_NOTZEROERR) )
  {
    if(pFlash.ProcedureOnGoing == FLASH_PROC_PAGEERASE)
    {
      addresstmp = pFlash.Page;
      pFlash.Page = 0xFFFFFFFFU;
    }
    else
    {
      addresstmp = pFlash.Address;
    }
    FLASH_SetErrorCode();
    HAL_FLASH_OperationErrorCallback(addresstmp);
    pFlash.ProcedureOnGoing = FLASH_PROC_NONE;
  }

  if(__HAL_FLASH_GET_FLAG(FLASH_FLAG_EOP))
  {
    __HAL_FLASH_CLEAR_FLAG(FLASH_FLAG_EOP);

    if(pFlash.ProcedureOnGoing != FLASH_PROC_NONE)
    {
      if(pFlash.ProcedureOnGoing == FLASH_PROC_PAGEERASE)
      {
        pFlash.NbPagesToErase--;

        if(pFlash.NbPagesToErase != 0U)
        {
          addresstmp = pFlash.Page;
          HAL_FLASH_EndOfOperationCallback(addresstmp);

          addresstmp = pFlash.Page + FLASH_PAGE_SIZE;
          pFlash.Page = addresstmp;

          CLEAR_BIT(FLASH->PECR, FLASH_PECR_ERASE);
          FLASH_PageErase(addresstmp);
        }
        else
        {
          pFlash.Page = addresstmp = 0xFFFFFFFFU;
          pFlash.ProcedureOnGoing = FLASH_PROC_NONE;
          HAL_FLASH_EndOfOperationCallback(addresstmp);
        }
      }
      else
      {
          CLEAR_BIT(FLASH->PECR, FLASH_PECR_PROG);
          HAL_FLASH_EndOfOperationCallback(pFlash.Address);

          pFlash.Address = 0xFFFFFFFFU;
          pFlash.ProcedureOnGoing = FLASH_PROC_NONE;
      }
    }
  }

  if(pFlash.ProcedureOnGoing == FLASH_PROC_NONE)
  {
    CLEAR_BIT(FLASH->PECR, (FLASH_PECR_ERASE | FLASH_PECR_PROG));
    __HAL_FLASH_DISABLE_IT(FLASH_IT_EOP | FLASH_IT_ERR);
    __HAL_UNLOCK(&pFlash);
  }
}

__weak void HAL_FLASH_EndOfOperationCallback(uint32_t ReturnValue)
{
  UNUSED(ReturnValue);
}

__weak void HAL_FLASH_OperationErrorCallback(uint32_t ReturnValue)
{
  UNUSED(ReturnValue);
}

HAL_StatusTypeDef HAL_FLASH_Unlock(void)
{
  uint32_t primask_bit;

  if(HAL_IS_BIT_SET(FLASH->PECR, FLASH_PECR_PELOCK))
  {
    primask_bit = __get_PRIMASK();
    __disable_irq();

    WRITE_REG(FLASH->PEKEYR, FLASH_PEKEY1);
    WRITE_REG(FLASH->PEKEYR, FLASH_PEKEY2);

    __set_PRIMASK(primask_bit);

    if(HAL_IS_BIT_SET(FLASH->PECR, FLASH_PECR_PELOCK))
    {
      return HAL_ERROR;
    }
  }

  if (HAL_IS_BIT_SET(FLASH->PECR, FLASH_PECR_PRGLOCK))
  {
    primask_bit = __get_PRIMASK();
    __disable_irq();

    WRITE_REG(FLASH->PRGKEYR, FLASH_PRGKEY1);
    WRITE_REG(FLASH->PRGKEYR, FLASH_PRGKEY2);

    __set_PRIMASK(primask_bit);

    if (HAL_IS_BIT_SET(FLASH->PECR, FLASH_PECR_PRGLOCK))
    {
      return HAL_ERROR;
    }
  }

  return HAL_OK;
}

HAL_StatusTypeDef HAL_FLASH_Lock(void)
{
  SET_BIT(FLASH->PECR, FLASH_PECR_PRGLOCK);
  SET_BIT(FLASH->PECR, FLASH_PECR_PELOCK);
  return HAL_OK;
}

HAL_StatusTypeDef HAL_FLASH_OB_Unlock(void)
{
  uint32_t primask_bit;

  if(HAL_IS_BIT_SET(FLASH->PECR, FLASH_PECR_OPTLOCK))
  {
    primask_bit = __get_PRIMASK();
    __disable_irq();

    if(HAL_IS_BIT_SET(FLASH->PECR, FLASH_PECR_PELOCK))
    {
      WRITE_REG(FLASH->PEKEYR, FLASH_PEKEY1);
      WRITE_REG(FLASH->PEKEYR, FLASH_PEKEY2);
    }

    WRITE_REG(FLASH->OPTKEYR, FLASH_OPTKEY1);
    WRITE_REG(FLASH->OPTKEYR, FLASH_OPTKEY2);

    __set_PRIMASK(primask_bit);
  }
  else
  {
    return HAL_ERROR;
  }

  return HAL_OK;
}

HAL_StatusTypeDef HAL_FLASH_OB_Lock(void)
{
  SET_BIT(FLASH->PECR, FLASH_PECR_OPTLOCK);
  return HAL_OK;
}

HAL_StatusTypeDef HAL_FLASH_OB_Launch(void)
{
  SET_BIT(FLASH->PECR, FLASH_PECR_OBL_LAUNCH);
  return(FLASH_WaitForLastOperation(FLASH_TIMEOUT_VALUE));
}

uint32_t HAL_FLASH_GetError(void)
{
   return pFlash.ErrorCode;
}

HAL_StatusTypeDef FLASH_WaitForLastOperation(uint32_t Timeout)
{
  uint32_t tickstart = HAL_GetTick();

  while(__HAL_FLASH_GET_FLAG(FLASH_FLAG_BSY))
  {
    if (Timeout != HAL_MAX_DELAY)
    {
      if((Timeout == 0U) || ((HAL_GetTick()-tickstart) > Timeout))
      {
        return HAL_TIMEOUT;
      }
    }
  }

  if (__HAL_FLASH_GET_FLAG(FLASH_FLAG_EOP))
  {
    __HAL_FLASH_CLEAR_FLAG(FLASH_FLAG_EOP);
  }

  if( __HAL_FLASH_GET_FLAG(FLASH_FLAG_WRPERR)     ||
      __HAL_FLASH_GET_FLAG(FLASH_FLAG_PGAERR)     ||
      __HAL_FLASH_GET_FLAG(FLASH_FLAG_SIZERR)     ||
      __HAL_FLASH_GET_FLAG(FLASH_FLAG_OPTVERR)    ||
      __HAL_FLASH_GET_FLAG(FLASH_FLAG_RDERR)      ||
      __HAL_FLASH_GET_FLAG(FLASH_FLAG_FWWERR)     ||
      __HAL_FLASH_GET_FLAG(FLASH_FLAG_NOTZEROERR) )
  {
    FLASH_SetErrorCode();
    return HAL_ERROR;
  }

  return HAL_OK;
}

static void FLASH_SetErrorCode(void)
{
  uint32_t flags = 0;

  if(__HAL_FLASH_GET_FLAG(FLASH_FLAG_WRPERR))
  {
    pFlash.ErrorCode |= HAL_FLASH_ERROR_WRP;
    flags |= FLASH_FLAG_WRPERR;
  }
  if(__HAL_FLASH_GET_FLAG(FLASH_FLAG_PGAERR))
  {
    pFlash.ErrorCode |= HAL_FLASH_ERROR_PGA;
    flags |= FLASH_FLAG_PGAERR;
  }
  if(__HAL_FLASH_GET_FLAG(FLASH_FLAG_SIZERR))
  {
    pFlash.ErrorCode |= HAL_FLASH_ERROR_SIZE;
    flags |= FLASH_FLAG_SIZERR;
  }
  if(__HAL_FLASH_GET_FLAG(FLASH_FLAG_OPTVERR))
  {
    pFlash.ErrorCode |= HAL_FLASH_ERROR_OPTV;
    flags |= FLASH_FLAG_OPTVERR;
  }
  if(__HAL_FLASH_GET_FLAG(FLASH_FLAG_RDERR))
  {
    pFlash.ErrorCode |= HAL_FLASH_ERROR_RD;
    flags |= FLASH_FLAG_RDERR;
  }
  if(__HAL_FLASH_GET_FLAG(FLASH_FLAG_FWWERR))
  {
    pFlash.ErrorCode |= HAL_FLASH_ERROR_FWWERR;
    flags |= HAL_FLASH_ERROR_FWWERR;
  }
  if(__HAL_FLASH_GET_FLAG(FLASH_FLAG_NOTZEROERR))
  {
    pFlash.ErrorCode |= HAL_FLASH_ERROR_NOTZERO;
    flags |= FLASH_FLAG_NOTZEROERR;
  }

  __HAL_FLASH_CLEAR_FLAG(flags);
}

#endif /* HAL_FLASH_MODULE_ENABLED */