/**
 * ******************************************************************************
 * @file    stm32l0xx_it.c
 * @brief   Main Interrupt Service Routines (Cleaned)
 * ******************************************************************************
 */

#include "stm32l0xx_it.h"

void NMI_Handler(void) {}
void SVC_Handler(void) {}
void PendSV_Handler(void) {}

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/