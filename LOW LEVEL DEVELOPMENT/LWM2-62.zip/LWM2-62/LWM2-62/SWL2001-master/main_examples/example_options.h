/**
 * @file      example_options.h
 *
 * @brief     User options to be used in example applications
 *
 * The Clear BSD License
 * Copyright Semtech Corporation 2021. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted (subject to the limitations in the disclaimer
 * below) provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Semtech corporation nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * NO EXPRESS OR IMPLIED LICENSES TO ANY PARTY'S PATENT RIGHTS ARE GRANTED BY
 * THIS LICENSE. THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
 * CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT
 * NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL SEMTECH CORPORATION BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

#ifndef EXAMPLE_OPTIONS_H
#define EXAMPLE_OPTIONS_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>
#include <stdbool.h>
#include "smtc_modem_api.h"

/**
 * @brief LoRaWAN User credentials (Synced with ChirpStack)
 */
#define USER_LORAWAN_DEVICE_EUI \
    {                           \
        0x5F, 0x6A, 0x23, 0x00, 0xF0, 0x00, 0x04, 0x19 \
    }

#define USER_LORAWAN_JOIN_EUI \
    {                           \
        0x75, 0x87, 0xBB, 0xB7, 0xC5, 0x40, 0x3C, 0xCE \
    }

#define USER_LORAWAN_GEN_APP_KEY \
    {                            \
        0x87, 0xEF, 0x42, 0xF8, 0x3B, 0xE7, 0x96, 0xD3, \
        0x8A, 0x42, 0xB5, 0x08, 0xA7, 0xE7, 0xBA, 0xF2  \
    }

#define USER_LORAWAN_APP_KEY \
    {                            \
        0x45, 0xD4, 0x90, 0xE0, 0x5E, 0xF7, 0xD7, 0xC8, \
        0x89, 0xF2, 0x10, 0x52, 0xAB, 0x8C, 0x0A, 0xA4  \
    }

/**
 * @brief Modem Region define
 */
#ifndef MODEM_EXAMPLE_REGION
#if !defined( SX128X )
#define MODEM_EXAMPLE_REGION SMTC_MODEM_REGION_IN_865
#else
#define MODEM_EXAMPLE_REGION SMTC_MODEM_REGION_WW_2G4
#endif
#endif  // MODEM_EXAMPLE_REGION

#ifdef __cplusplus
}
#endif

#endif  // EXAMPLE_OPTIONS_H