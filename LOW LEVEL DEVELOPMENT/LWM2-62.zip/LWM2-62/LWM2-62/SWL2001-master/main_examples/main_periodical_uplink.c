#if 0
/*!
 * \file      main_periodical_uplink.c
 * \brief     Pure LoRaWAN UART Chat Terminal (Class C Enabled)
 */
       //THIS FILES IS CURRENTLY REMOVED FORM THE PROJECT AND IT IS WORKING UNDER THE lora_chat_app FILE  // ROHAN 
			 // to readd option for the file and add in the include of the project and can be call via main.c 
/*
 * -----------------------------------------------------------------------------
 * --- DEPENDENCIES ------------------------------------------------------------
 */
#include <stdint.h>   // C99 types    
#include <stdbool.h>  // bool type
#include <string.h>

#include "main.h"

#include "smtc_modem_test_api.h"
#include "smtc_modem_api.h"
#include "smtc_modem_utilities.h"

#include "smtc_modem_hal.h"
#include "smtc_hal_dbg_trace.h"

#include "example_options.h"

#include "smtc_hal_mcu.h"
#include "smtc_hal_gpio.h"
#include "smtc_hal_watchdog.h"

#include "modem_pinout.h"
#include "smtc_modem_relay_api.h"

// --- EXTERN DECLARATION FOR HYBRID POLLING --- 
extern bool smtc_modem_hal_poll_radio_irq( void );

// ============================================================================
// --- CUSTOM UART TERMINAL VARIABLES -----------------------------------------
// ============================================================================
#define MAX_PAYLOAD_LEN 64
uint8_t uart_tx_buffer[MAX_PAYLOAD_LEN];
volatile uint8_t rx_index = 0;
volatile bool new_text_ready = false;
// ============================================================================

/*
 * -----------------------------------------------------------------------------
 * --- PRIVATE MACROS-----------------------------------------------------------
 */

#ifndef MIN
#define MIN( a, b ) ( ( ( a ) < ( b ) ) ? ( a ) : ( b ) )
#endif

#define xstr( a ) str( a )
#define str( a ) #a

#define ASSERT_SMTC_MODEM_RC( rc_func )                                                                                        \
    do                                                                                                                         \
    {                                                                                                                          \
        smtc_modem_return_code_t rc = rc_func;                                                                                 \
        if( rc == SMTC_MODEM_RC_NOT_INIT )                                                                                     \
        {                                                                                                                      \
            SMTC_HAL_TRACE_ERROR( "In %s - %s (line %d): %s\n", __FILE__, __func__, __LINE__,                                  \
                                xstr( SMTC_MODEM_RC_NOT_INIT ) );                                                      \
        }                                                                                                                      \
        else if( rc == SMTC_MODEM_RC_INVALID )                                                                                 \
        {                                                                                                                      \
            SMTC_HAL_TRACE_ERROR( "In %s - %s (line %d): %s\n", __FILE__, __func__, __LINE__,                                  \
                                xstr( SMTC_MODEM_RC_INVALID ) );                                                       \
        }                                                                                                                      \
        else if( rc == SMTC_MODEM_RC_BUSY )                                                                                    \
        {                                                                                                                      \
            SMTC_HAL_TRACE_ERROR( "In %s - %s (line %d): %s\n", __FILE__, __func__, __LINE__,                                  \
                                xstr( SMTC_MODEM_RC_BUSY ) );                                                          \
        }                                                                                                                      \
        else if( rc == SMTC_MODEM_RC_FAIL )                                                                                    \
        {                                                                                                                      \
            SMTC_HAL_TRACE_ERROR( "In %s - %s (line %d): %s\n", __FILE__, __func__, __LINE__,                                  \
                                xstr( SMTC_MODEM_RC_FAIL ) );                                                          \
        }                                                                                                                      \
        else if( rc == SMTC_MODEM_RC_NO_TIME )                                                                                 \
        {                                                                                                                      \
            SMTC_HAL_TRACE_WARNING( "In %s - %s (line %d): %s\n", __FILE__, __func__, __LINE__,                                \
                                    xstr( SMTC_MODEM_RC_NO_TIME ) );                                                   \
        }                                                                                                                      \
        else if( rc == SMTC_MODEM_RC_INVALID_STACK_ID )                                                                        \
        {                                                                                                                      \
            SMTC_HAL_TRACE_ERROR( "In %s - %s (line %d): %s\n", __FILE__, __func__, __LINE__,                                  \
                                xstr( SMTC_MODEM_RC_INVALID_STACK_ID ) );                                              \
        }                                                                                                                      \
    } while( 0 )

/*
 * -----------------------------------------------------------------------------
 * --- PRIVATE CONSTANTS -------------------------------------------------------
 */

#define STACK_ID 0

// --- HYBRID ARCHITECTURE CONSTANTS ---
#define POLLING_MARGIN_MS 15 

#if !defined( USE_LR11XX_CREDENTIALS )
static const uint8_t user_dev_eui[8]      = USER_LORAWAN_DEVICE_EUI;
static const uint8_t user_join_eui[8]     = USER_LORAWAN_JOIN_EUI;
static const uint8_t user_gen_app_key[16] = USER_LORAWAN_GEN_APP_KEY;
static const uint8_t user_app_key[16]     = USER_LORAWAN_APP_KEY;
#endif

#define WATCHDOG_RELOAD_PERIOD_MS 20000

/*
 * -----------------------------------------------------------------------------
 * --- PRIVATE VARIABLES -------------------------------------------------------
 */
static uint8_t                 rx_payload[SMTC_MODEM_MAX_LORAWAN_PAYLOAD_LENGTH] = { 0 };  
static uint8_t                 rx_payload_size = 0;      
static smtc_modem_dl_metadata_t rx_metadata     = { 0 };  
static uint8_t                 rx_remaining    = 0;      

volatile bool user_button_is_press = false;  

#if defined( USE_RELAY_TX )
static smtc_modem_relay_tx_config_t relay_config = { 0 };
#endif

#if defined( USE_LR11XX_CREDENTIALS )
static uint8_t chip_eui[SMTC_MODEM_EUI_LENGTH] = { 0 };
static uint8_t chip_pin[SMTC_MODEM_PIN_LENGTH] = { 0 };
#endif

/*
 * -----------------------------------------------------------------------------
 * --- PRIVATE FUNCTIONS DECLARATION -------------------------------------------
 */

void modem_event_callback( void );
void user_button_callback( void* context );

/*
 * -----------------------------------------------------------------------------
 * --- PUBLIC FUNCTIONS DEFINITION ---------------------------------------------
 */

void main_periodical_uplink( void )
{
    uint32_t sleep_time_ms = 0;

    hal_mcu_disable_irq( );
    hal_mcu_init( );
    smtc_modem_init( &modem_event_callback );

    hal_gpio_irq_t nucleo_blue_button = {
        .pin      = EXTI_BUTTON,
        .context  = NULL,                  
        .callback = user_button_callback,  
    };
    hal_gpio_init_in( EXTI_BUTTON, BSP_GPIO_PULL_MODE_NONE, BSP_GPIO_IRQ_MODE_FALLING, &nucleo_blue_button );

    hal_mcu_enable_irq( );

    // Clear buffer safely
    memset(uart_tx_buffer, 0, MAX_PAYLOAD_LEN);

    // =========================================================================
    // --- Beautiful UI Startup Banner
    // =========================================================================
    SMTC_HAL_TRACE_INFO( "\n\n" );
    SMTC_HAL_TRACE_INFO( "=================================================\n" );
    SMTC_HAL_TRACE_INFO( "    STM32 LoRaWAN Chat Terminal (Class C)      \n" );
    SMTC_HAL_TRACE_INFO( "=================================================\n" );
    SMTC_HAL_TRACE_INFO( "[STATUS] Attempting to join network... Please wait.\n" );

    while( 1 )
    {
        // =====================================================================
        // --- Process User UART Input ---
        // =====================================================================
        if( new_text_ready == true )
        {
            smtc_modem_status_mask_t status_mask = 0;
            smtc_modem_get_status( STACK_ID, &status_mask );
            
            // Only send if the modem is actually joined to ChirpStack
            if( ( status_mask & SMTC_MODEM_STATUS_JOINED ) == SMTC_MODEM_STATUS_JOINED )
            {
                // --- STRIP TRAILING NEWLINES / CARRIAGE RETURNS ---
                while( rx_index > 0 && ( uart_tx_buffer[rx_index - 1] == '\r' || uart_tx_buffer[rx_index - 1] == '\n' ) )
                {
                    uart_tx_buffer[rx_index - 1] = '\0';
                    rx_index--;
                }
                // --------------------------------------------------

                if( rx_index > 0 )
                {
                    SMTC_HAL_TRACE_INFO("\n[TX] Sending: '%s' on FPort 10...\n", uart_tx_buffer);
                    ASSERT_SMTC_MODEM_RC( smtc_modem_request_uplink( STACK_ID, 10, false, uart_tx_buffer, rx_index ) );
                }
            }
            else
            {
                SMTC_HAL_TRACE_WARNING("\n[ERROR] Cannot send. Network not joined yet! Please wait for success message.\n");
            }
            
            // Clean up and reset for the next message
            memset(uart_tx_buffer, 0, MAX_PAYLOAD_LEN);
            rx_index = 0;
            new_text_ready = false;
        }
        // =====================================================================

        sleep_time_ms = smtc_modem_run_engine( );

        // --- HYBRID SLEEP-POLLING ENGINE WITH SAFE WATCHDOG FEEDING ---
        hal_mcu_disable_irq( );
        if( ( user_button_is_press == false ) && ( smtc_modem_is_irq_flag_pending( ) == false ) && ( new_text_ready == false ) )
        {
            hal_watchdog_reload( );
            hal_mcu_enable_irq( ); 

            // Stay awake and actively poll the radio via SPI to bypass missing DIO1 pin
            if( sleep_time_ms > 0 )
            {
                uint32_t start_poll = smtc_modem_hal_get_time_in_ms( );
                while( ( smtc_modem_hal_get_time_in_ms( ) - start_poll ) < sleep_time_ms )
                {
                    hal_watchdog_reload( ); // Continuously feed watchdog during sleep intervals

                    if( smtc_modem_is_irq_flag_pending() ) break;
                    if( smtc_modem_hal_poll_radio_irq( ) == true ) break; 
                    if( new_text_ready == true > 0 ) break; // Wake up immediately if text arrived
                    
                    hal_mcu_wait_us( 500 ); 
                }
            }
        }
        else
        {
            hal_mcu_enable_irq( );
        }
        
        hal_watchdog_reload( );
    }
}

/*
 * -----------------------------------------------------------------------------
 * --- PRIVATE FUNCTIONS DEFINITION --------------------------------------------
 */

void modem_event_callback( void )
{
    smtc_modem_event_t current_event;
    uint8_t            event_pending_count;
    uint8_t            stack_id = STACK_ID;

    do
    {
        ASSERT_SMTC_MODEM_RC( smtc_modem_get_event( &current_event, &event_pending_count ) );

        switch( current_event.event_type )
        {
        case SMTC_MODEM_EVENT_RESET:
#if !defined( USE_LR11XX_CREDENTIALS )
            ASSERT_SMTC_MODEM_RC( smtc_modem_set_deveui( stack_id, user_dev_eui ) );
            ASSERT_SMTC_MODEM_RC( smtc_modem_set_joineui( stack_id, user_join_eui ) );
            ASSERT_SMTC_MODEM_RC( smtc_modem_set_appkey( stack_id, user_gen_app_key ) );
            ASSERT_SMTC_MODEM_RC( smtc_modem_set_nwkkey( stack_id, user_app_key ) );
#else
            ASSERT_SMTC_MODEM_RC( smtc_modem_get_chip_eui( stack_id, chip_eui ) );
            ASSERT_SMTC_MODEM_RC( smtc_modem_get_pin( stack_id, chip_pin ) );
#endif
            ASSERT_SMTC_MODEM_RC( smtc_modem_set_region( stack_id, MODEM_EXAMPLE_REGION ) );

            // =========================================================
            // --- CONFIGURE DEVICE AS CLASS C (Continuous Receive Mode)
            // =========================================================
            ASSERT_SMTC_MODEM_RC( smtc_modem_set_class( stack_id, SMTC_MODEM_CLASS_C ) );

#if defined( USE_RELAY_TX )
            relay_config.second_ch_enable = false;
            relay_config.activation = SMTC_MODEM_RELAY_TX_ACTIVATION_MODE_ENABLE; 
            relay_config.number_of_miss_wor_ack_to_switch_in_nosync_mode = 3;
            relay_config.smart_level = 8;
            relay_config.backoff = 0; 
            ASSERT_SMTC_MODEM_RC( smtc_modem_relay_tx_enable( stack_id, &relay_config ) );
#endif
            ASSERT_SMTC_MODEM_RC( smtc_modem_join_network( stack_id ) );
            break;

        case SMTC_MODEM_EVENT_JOINED:
            SMTC_HAL_TRACE_INFO( "\n" );
            SMTC_HAL_TRACE_INFO( "=================================================\n" );
            SMTC_HAL_TRACE_INFO( "    SUCCESS: JOIN ACCEPT RECEIVED (CLASS C)!     \n" );
            SMTC_HAL_TRACE_INFO( "    DEVICE IS READY TO SEND & RECEIVE DATA       \n" );
            SMTC_HAL_TRACE_INFO( "=================================================\n" );
            SMTC_HAL_TRACE_INFO( "\n> Type a message and press Enter: " );
            break;

        case SMTC_MODEM_EVENT_TXDONE:
            SMTC_HAL_TRACE_INFO( "\n[STATUS] Message successfully transmitted over the air.\n" );
            SMTC_HAL_TRACE_INFO( "\n> Type a message and press Enter: " );
            break;

        case SMTC_MODEM_EVENT_DOWNDATA:
            ASSERT_SMTC_MODEM_RC( smtc_modem_get_downlink_data( rx_payload, &rx_payload_size, &rx_metadata, &rx_remaining ) );
            rx_payload[rx_payload_size] = '\0'; // Null terminate safely for printing
            
            SMTC_HAL_TRACE_INFO( "\n\n========== CLASS C DOWNLINK RECEIVED ==========\n" );
            SMTC_HAL_TRACE_INFO( "FPort: %u | RSSI: %d dBm | SNR: %d dB\n", rx_metadata.fport, rx_metadata.rssi, rx_metadata.snr );
            SMTC_HAL_TRACE_INFO( "Text Payload: %s\n", (char*)rx_payload );
            SMTC_HAL_TRACE_INFO( "===============================================\n" );
            SMTC_HAL_TRACE_INFO( "\n> Type a message and press Enter: " );
            break;

        case SMTC_MODEM_EVENT_JOINFAIL:
            SMTC_HAL_TRACE_WARNING( "\n[WARN] Join Failed. Retrying...\n" );
            break;

        case SMTC_MODEM_EVENT_NO_DOWNLINK_THRESHOLD:
            SMTC_HAL_TRACE_WARNING( "\n[INFO] No downlink threshold reached. Staying connected.\n" );
            break;

        default:
            // Silently ignore other internal LoRaWAN events to keep terminal clean
            break;
        }
    } while( event_pending_count > 0 );
}

void user_button_callback( void* context )
{
    ( void ) context;  
    static uint32_t last_press_timestamp_ms = 0;
    if( ( int32_t ) ( smtc_modem_hal_get_time_in_ms( ) - last_press_timestamp_ms ) > 500 )
    {
        last_press_timestamp_ms = smtc_modem_hal_get_time_in_ms( );
        user_button_is_press    = true;
    }
}

/* --- EOF ------------------------------------------------------------------ */
#endif