#ifndef MODEM_PINOUT_H
#define MODEM_PINOUT_H

#ifdef __cplusplus
extern "C" {
#endif

#include "smtc_hal_gpio_pin_names.h"


/* ============================================================
 * Custom Hardware
 *
 * MCU  : STM32L071KBU6
 * Radio: SX1262
 * ============================================================ */


/* ============================================================
 * SPI
 *
 *      PA4  -> SX1262 NSS
 *      PA5  -> SX1262 SCK
 *      PA6  <- SX1262 MISO
 *      PA7  -> SX1262 MOSI
 * ============================================================ */

#define RADIO_SPI_ID       1

#define RADIO_NSS          PA_4
#define RADIO_SCK          PA_5
#define RADIO_MISO         PA_6
#define RADIO_MOSI         PA_7


/* ============================================================
 * SX1262 CONTROL PINS
 *
 * SX1262 pin 15 = NRESET -> STM32 PB0
 * SX1262 pin 14 = BUSY   -> STM32 PB1
 * SX1262 pin 13 = DIO1   -> STM32 PB11  (EXTI line 11)
 *
 * SX1262 DIO2 drives the RF switch internally (no STM32 GPIO).
 * ============================================================ */

#define RADIO_NRST         PB_0
#define RADIO_BUSY_PIN     PB_1

/* Radio interrupt pin used by the Semtech HAL: DIO1 -> PB11 */
#define RADIO_DIOX         PB_11


/* ============================================================
 * DEBUG UART
 * ============================================================ */

#define DEBUG_UART_TX      PA_2
#define DEBUG_UART_RX      PA_3


/* ============================================================
 * EXTERNAL BUTTON (not used on this hardware)
 * ============================================================ */

#define EXTI_BUTTON        NC


#ifdef __cplusplus
}
#endif

#endif /* MODEM_PINOUT_H */