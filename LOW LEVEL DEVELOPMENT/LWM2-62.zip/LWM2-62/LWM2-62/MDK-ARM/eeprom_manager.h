/**
 * @file      eeprom_manager.h
 * @brief     Non-Volatile EEPROM storage for LoRaWAN keys, frame counters, and Multicast contexts.
 */

#ifndef EEPROM_MANAGER_H
#define EEPROM_MANAGER_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>

#define FCNT_RESERVATION_BLOCK_SIZE  100U

typedef struct __attribute__((packed))
{
    uint8_t  dev_eui[8];        
    uint8_t  join_eui[8];       
    uint8_t  app_key[16];       
    uint8_t  gen_app_key[16];   
    uint32_t dev_addr;          
    uint8_t  nwk_s_key[16];     
    uint8_t  app_s_key[16];     
} lora_credentials_t;

typedef struct __attribute__((packed))
{
    uint32_t magic_word;        
    uint8_t  join_eui[8];
    uint8_t  app_key[16];
    uint8_t  gen_app_key[16];
    uint8_t  nwk_s_key[16];
    uint8_t  app_s_key[16];
    uint32_t keys_crc;          
    uint32_t fcnt_up;           
    uint32_t fcnt_down;         
} lora_eeprom_config_t;

typedef enum
{
    EEPROM_ID_NONE = 0,         
    EEPROM_ID_FACTORY,          
    EEPROM_ID_BACKUP            
} eeprom_id_source_t;

typedef enum
{
    EEPROM_SYNC_OK = 0,
    EEPROM_SYNC_WRITE_FAIL,     
    EEPROM_SYNC_NO_DEVICE_ID    
} eeprom_sync_result_t;

extern volatile uint32_t g_eeprom_guard_hits;
extern volatile uint32_t g_eeprom_guard_last_addr;

void eeprom_manager_init( void );
bool eeprom_get_factory_ids( uint8_t dev_eui[8], uint32_t *dev_addr );
eeprom_id_source_t eeprom_get_device_ids( uint8_t dev_eui[8], uint32_t *dev_addr );
void eeprom_print_ids( void );
void eeprom_print_keys( void );
bool eeprom_factory_area_intact( void );

eeprom_sync_result_t eeprom_sync_credentials( const lora_credentials_t *wanted, bool force_reset,
                                              lora_credentials_t *active, uint32_t *fcnt_up, uint32_t *fcnt_down );

void eeprom_update_fcnt_up( uint32_t current_ram_fcnt_up );
void eeprom_update_fcnt_down( uint32_t current_ram_fcnt_down );
bool eeprom_manager_update_key(const char* key_name, uint8_t length, const uint8_t* data);

/* ---------------------------------------------------------------------------
 * Multicast persistence (double-buffered A/B slots, power-fail safe)
 *
 *   0x08080200 : slot A  (0x100 bytes)
 *   0x08080300 : slot B  (0x100 bytes)
 *
 * Each slot = { magic, seq, len, crc32(payload) } + payload.
 * A save always writes the slot that is NOT the newest valid one, verifies it
 * by read-back, and only then does it become the newest (higher seq).
 * A power cut during a save can therefore never destroy the previous good copy.
 * ------------------------------------------------------------------------- */
#define EEPROM_MULTICAST_ADDR        (0x08080000U + 0x0200U)
#define EEPROM_MULTICAST_SLOT_SIZE   0x100U
#define EEPROM_MULTICAST_SLOTS       2U
#define EEPROM_MULTICAST_HDR_SIZE    16U
#define EEPROM_MULTICAST_MAX_LEN     ( EEPROM_MULTICAST_SLOT_SIZE - EEPROM_MULTICAST_HDR_SIZE )   /* 240 */

bool eeprom_manager_save_multicast(const uint8_t* data, uint16_t length);
bool eeprom_manager_load_multicast(uint8_t* data, uint16_t length);
bool eeprom_manager_erase_multicast(void);

#ifdef __cplusplus
}
#endif

#endif // EEPROM_MANAGER_H