/**
  ******************************************************************************
  * @file    stm32l0xx_it.h
  * @brief   Interrupt Service Routines header
  ******************************************************************************
  */

#ifndef __STM32L0XX_IT_H
#define __STM32L0XX_IT_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes */
#include "stm32l0xx_hal.h"

/* Exported functions prototypes */
void NMI_Handler(void);
void HardFault_Handler(void);
void SVC_Handler(void);
void PendSV_Handler(void);
void SysTick_Handler(void);
void EXTI15_10_IRQHandler(void);
void USART2_IRQHandler(void);
void SPI1_IRQHandler(void);
void DMA1_Ch2_3_IRQHandler(void);

#ifdef __cplusplus
}
#endif

#endif /* __STM32L0XX_IT_H */