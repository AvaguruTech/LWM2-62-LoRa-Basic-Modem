/**
 * @file      sensor_manager.c
 * @brief     Dynamic Multi-Sensor Management and Cayenne LPP TLV Serialization
 */

#include "sensor_manager.h"
#include "bsp_mcu.h"
#include "smtc_modem_api.h"
#include "smtc_hal_dbg_trace.h"
#include <string.h>
#include <stdlib.h>
#include <stdint.h>

/* --- Dynamic Mock Driver Functions with Real-World Jitter --- */
static float mock_temp_read(uint8_t addr)
{
    (void)addr;
    // Base temperature around 25.5�C with small dynamic fluctuations (-0.8 to +0.8)
    static float t = 25.5f;
    float jitter = ((float)(rand() % 17) - 8.0f) / 10.0f; // -0.8 to +0.8
    t += jitter;
    if (t < 20.0f) t = 20.0f;
    if (t > 35.0f) t = 35.0f;
    return t; 
}

static float mock_humidity_read(uint8_t addr)
{
    (void)addr;
    // Base humidity around 58.0% RH with small jitter (-1.5 to +1.5)
    static float h = 58.0f;
    float jitter = ((float)(rand() % 31) - 15.0f) / 10.0f; // -1.5 to +1.5
    h += jitter;
    if (h < 30.0f) h = 30.0f;
    if (h > 90.0f) h = 90.0f;
    return h;
}

/* --- Dynamic Sensor Registration Table (Only Temp & Humidity) --- */
static i2c_sensor_descriptor_t sensor_registry[MAX_SUPPORTED_I2C_SENSORS] = {
    {
        .sensor_id       = 0x01,
        .i2c_address     = 0x48,
        .data_type       = TYPE_TEMPERATURE,
        .is_enabled      = true,
        .hardware_online = true,
        .read_value_fn   = &mock_temp_read
    },
    {
        .sensor_id       = 0x02,
        .i2c_address     = 0x40,
        .data_type       = TYPE_HUMIDITY,
        .is_enabled      = true,
        .hardware_online = true,
        .read_value_fn   = &mock_humidity_read
    }
};

static const uint8_t total_registered_sensors = 2;

void sensor_manager_init(void)
{
    SMTC_HAL_TRACE_INFO("[SENSOR] Initializing Multi-Sensor Manager (Cayenne LPP)...\r\n");

    for (uint8_t i = 0; i < total_registered_sensors; i++) {
        SMTC_HAL_TRACE_INFO("[SENSOR] ID: 0x%02X | Type: 0x%02X | Addr: 0x%02X -> ONLINE\r\n",
                            sensor_registry[i].sensor_id,
                            sensor_registry[i].data_type,
                            sensor_registry[i].i2c_address);
    }
}

uint8_t sensor_manager_pack_uplink(uint8_t *out_buffer, uint8_t max_len)
{
    uint8_t offset = 0;

    for (uint8_t i = 0; i < total_registered_sensors; i++) {
        if (!sensor_registry[i].is_enabled || !sensor_registry[i].hardware_online) {
            continue;
        }

        // Reserve at least 4 bytes for safety check
        if ((offset + 4) > max_len) {
            SMTC_HAL_TRACE_WARNING("[SENSOR] Payload buffer limit reached!\r\n");
            break;
        }

        float measurement = 0.0f;
        if (sensor_registry[i].read_value_fn != NULL) {
            measurement = sensor_registry[i].read_value_fn(sensor_registry[i].i2c_address);
        }

        out_buffer[offset++] = sensor_registry[i].sensor_id;
        out_buffer[offset++] = (uint8_t)sensor_registry[i].data_type;

        // Auto-Scale Float into Cayenne LPP Hex Standard
        switch (sensor_registry[i].data_type) {
            case TYPE_TEMPERATURE: {
                int16_t scaled = (int16_t)(measurement * 10.0f); // 0.1 �C resolution
                out_buffer[offset++] = (uint8_t)((scaled >> 8) & 0xFF);
                out_buffer[offset++] = (uint8_t)(scaled & 0xFF);
                break;
            }
            case TYPE_HUMIDITY: {
                uint8_t scaled = (uint8_t)(measurement * 2.0f);  // 0.5 % resolution
                out_buffer[offset++] = scaled;
                break;
            }
            default:
                break;
        }
    }

    return offset;
}

void sensor_manager_process_downlink(const uint8_t *rx_buf, uint8_t rx_len)
{
    if (rx_len < 2) {
        return;
    }

    uint8_t target_id = rx_buf[0];
    uint8_t opcode    = rx_buf[1];

    for (uint8_t i = 0; i < total_registered_sensors; i++) {
        if (sensor_registry[i].sensor_id == target_id) {
            if (opcode == 0x01) {
                sensor_registry[i].is_enabled = true;
                SMTC_HAL_TRACE_INFO("[SENSOR CMD] Sensor 0x%02X Enabled via Downlink\r\n", target_id);
            } else if (opcode == 0x00) {
                sensor_registry[i].is_enabled = false;
                SMTC_HAL_TRACE_INFO("[SENSOR CMD] Sensor 0x%02X Disabled via Downlink\r\n", target_id);
            }
            return;
        }
    }

    SMTC_HAL_TRACE_WARNING("[SENSOR CMD] Sensor ID 0x%02X not found\r\n", target_id);
}

void sensor_manager_trigger_sample_and_send(bool confirmed)
{
    uint8_t payload[SMTC_MODEM_MAX_LORAWAN_PAYLOAD_LENGTH];
    uint8_t payload_len = sensor_manager_pack_uplink(payload, sizeof(payload));

    if (payload_len > 0) {
        SMTC_HAL_TRACE_INFO("[SENSOR] Uplink Dispatch (%d bytes) on FPort %d...\r\n", 
                            payload_len, LORA_PORT_SENSOR_DATA);
        smtc_modem_request_uplink(0, LORA_PORT_SENSOR_DATA, confirmed, payload, payload_len);
    }
}