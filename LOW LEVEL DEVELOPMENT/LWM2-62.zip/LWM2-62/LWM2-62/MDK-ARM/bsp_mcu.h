/**
 * @file      bsp_mcu.h
 * @brief     Board Support Package: clocks, UART, I2C, pinout, Stop-mode interface
 *            for the STM32L071KBU6 + Semtech SX1262.
 */

#ifndef BSP_MCU_H
#define BSP_MCU_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>
#include <stdbool.h>

#include "stm32l0xx_ll_rcc.h"
#include "stm32l0xx_ll_bus.h"
#include "stm32l0xx_ll_gpio.h"
#include "stm32l0xx_ll_usart.h"
#include "stm32l0xx_ll_i2c.h"
#include "stm32l0xx_ll_utils.h"
#include "stm32l0xx_ll_pwr.h"
#include "stm32l0xx_ll_exti.h"
#include "stm32l0xx_ll_system.h"

// ============================================================================
// SECTION 1: SYSTEM CLOCK CONFIGURATION
// ============================================================================
#define BSP_MCU_FREQ_MHZ            32

// ============================================================================
// SECTION 2: TERMINAL UART (USART2 on PA2-TX / PA3-RX)
// ============================================================================
#define BSP_UART_INSTANCE           USART2
#define BSP_UART_BAUDRATE           115200

#define BSP_UART_PORT               GPIOA
#define BSP_UART_TX_PIN             LL_GPIO_PIN_2  // PA2
#define BSP_UART_RX_PIN             LL_GPIO_PIN_3   // Stop-mode wake uses EXTI line 3 / PA3 (see bsp_mcu.c)
#define BSP_UART_AF                 LL_GPIO_AF_4

#define BSP_UART_RX_BUF_SIZE        256

// ============================================================================
// SECTION 3: SENSOR I2C BUS (I2C1 on PB6-SCL / PB7-SDA, AF1)
// If your board really uses PB8/PB9: change the pins, use LL_GPIO_AF_4 and LL_GPIO_SetAFPin_8_15.
// ============================================================================
#define BSP_I2C_INSTANCE            I2C1
#define BSP_I2C_PORT                GPIOB
#define BSP_I2C_SCL_PIN             LL_GPIO_PIN_6
#define BSP_I2C_SDA_PIN             LL_GPIO_PIN_7
#define BSP_I2C_AF                  LL_GPIO_AF_1
#define BSP_I2C_TIMING              0x00707CBB   // 100 kHz Standard Mode @ 32 MHz

// ============================================================================
// SECTION 4: STM32L071 TO SEMTECH SX1262 PINOUT MAPPING
// ============================================================================
#define BSP_RADIO_SPI_PORT          GPIOA
#define BSP_RADIO_NSS_PIN           LL_GPIO_PIN_4
#define BSP_RADIO_SCK_PIN           LL_GPIO_PIN_5
#define BSP_RADIO_MISO_PIN          LL_GPIO_PIN_6
#define BSP_RADIO_MOSI_PIN          LL_GPIO_PIN_7

#define BSP_RADIO_CONTROL_PORT      GPIOB
#define BSP_RADIO_NRST_PIN          LL_GPIO_PIN_0
#define BSP_RADIO_BUSY_PIN          LL_GPIO_PIN_1
#define BSP_RADIO_DIO1_PIN          LL_GPIO_PIN_11

// ============================================================================
// SECTION 5: ONBOARD BUTTON & STATUS LED
// ============================================================================
#define BSP_USER_BUTTON_PORT        GPIOC
#define BSP_USER_BUTTON_PIN         LL_GPIO_PIN_13

#define BSP_LED_PORT                GPIOA
#define BSP_LED_PIN                 LL_GPIO_PIN_5   // NOTE: same pin as radio SCK - check your schematic

// ============================================================================
// SECTION 6: STOP MODE OPTIONS
// ============================================================================
/* 1 = use the LBM RTC wake-up timer (hal_rtc_wakeup_timer_set_ms / _stop from smtc_hal_rtc.h)
 *     to end each Stop slice. Needed to kick the watchdog and to count the 49-day sleep.
 * 0 = no timer: only the UART RX pin wakes the MCU (set this if you get a link error). */
#ifndef BSP_STOP_USE_HAL_RTC
#define BSP_STOP_USE_HAL_RTC        1
#endif
/* A wake earlier than (slice - tolerance) is treated as a UART wake */
#define BSP_STOP_WAKE_TOL_MS        100U

// ============================================================================
// EXPORTED GLOBAL STATE & SYSTEM INTERFACES
// ============================================================================
extern uint8_t          uart_tx_buffer[BSP_UART_RX_BUF_SIZE];
extern volatile uint8_t rx_index;
extern volatile bool    new_text_ready;

void bsp_mcu_init( void );

/** Restores the 32 MHz PLL clock tree after waking from Stop mode. */
void bsp_rcc_init( void );

void bsp_i2c_init( void );
void bsp_watchdog_reload( void );
void bsp_delay_us( uint32_t us );

/** Extracts a complete line (Enter terminated) from the UART buffer. */
bool bsp_uart_get_line( uint8_t* out_buf, uint8_t* out_len );

/** Drops everything received so far (used to discard the garbled wake-up character). */
void bsp_uart_flush( void );

/**
 * @brief Enters Stop mode for at most sleep_duration_ms (0 = until UART).
 *        Wakes on: RTC timer (if BSP_STOP_USE_HAL_RTC), or a falling edge on the UART RX pin.
 * @return true  if woken early (UART / other interrupt)
 *         false if the timer expired
 */
bool bsp_mcu_enter_stop_mode( uint32_t sleep_duration_ms );

#ifdef __cplusplus
}
#endif

#endif // BSP_MCU_H