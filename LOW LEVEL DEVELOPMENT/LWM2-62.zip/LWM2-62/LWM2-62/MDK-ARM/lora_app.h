/**
 * @file      lora_app.h
 * @brief     LoRaWAN & Secure P2P Application Layer Header (Multicast Enabled)
 */

#ifndef LORA_APP_H
#define LORA_APP_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>
#include <stdbool.h>
#include "smtc_modem_api.h"

// --- PROTOCOL SELECTION ---
#define PROTOCOL_LORAWAN            0
#define PROTOCOL_P2P                1

#ifndef CFG_PROTOCOL_MODE
#define CFG_PROTOCOL_MODE           PROTOCOL_LORAWAN
#endif

// --- OPERATING MODE & TIMINGS ---
#ifndef CFG_DEFAULT_OP_MODE
#define CFG_DEFAULT_OP_MODE         1
#endif

#ifndef CFG_WAKE_WINDOW_MS
#define CFG_WAKE_WINDOW_MS          6000U
#endif

#ifndef CFG_RX_WINDOW_MS
#define CFG_RX_WINDOW_MS            5000U
#endif

#ifndef CFG_TX_TIMEOUT_MS
#define CFG_TX_TIMEOUT_MS           20000U
#endif

#ifndef CFG_MODE0_SLEEP_MS
#define CFG_MODE0_SLEEP_MS          0U
#endif

#ifndef CFG_MODE1_SLEEP_MS
#define CFG_MODE1_SLEEP_MS          0xFFFFFFFFUL
#endif

#ifndef CFG_STOP_SLICE_MS
#define CFG_STOP_SLICE_MS           5000U
#endif

#ifndef CFG_SLEEP_PERIODIC_SENSOR_MS
#define CFG_SLEEP_PERIODIC_SENSOR_MS  0U
#endif

#ifndef CFG_PRE_SLEEP_DELAY_MS
#define CFG_PRE_SLEEP_DELAY_MS      20U
#endif

// --- SERIAL COMMANDS ---
#ifndef CFG_CMD_MODE_0
#define CFG_CMD_MODE_0              "mode 0"
#endif
#ifndef CFG_CMD_MODE_1
#define CFG_CMD_MODE_1              "mode 1"
#endif
#ifndef CFG_CMD_MODE_2
#define CFG_CMD_MODE_2              "mode 2"
#endif
#ifndef CFG_CMD_MODE_QUERY
#define CFG_CMD_MODE_QUERY          "mode"
#endif
#ifndef CFG_CMD_TRIGGER_SENSOR
#define CFG_CMD_TRIGGER_SENSOR      "sensor"
#endif
#ifndef CFG_CMD_FORCE_SLEEP_TXT
#define CFG_CMD_FORCE_SLEEP_TXT     "sleep"
#endif
#ifndef CFG_CMD_FORCE_SLEEP_HEX
#define CFG_CMD_FORCE_SLEEP_HEX     "03050201"
#endif
#ifndef CFG_CMD_FORCE_SLEEP_BIN
#define CFG_CMD_FORCE_SLEEP_BIN     { 0x03, 0x05, 0x02, 0x01 }
#endif
#ifndef CFG_CMD_STATUS
#define CFG_CMD_STATUS              "status"
#endif
#ifndef CFG_CMD_RSSI
#define CFG_CMD_RSSI                "rssi"
#endif
#ifndef CFG_CMD_HELP
#define CFG_CMD_HELP                "help"
#endif
#ifndef CFG_CMD_PING
#define CFG_CMD_PING                "ping"
#endif
#ifndef CFG_CMD_STOP
#define CFG_CMD_STOP                "stop"
#endif

#ifndef APP_TIME_MS
#define APP_TIME_MS( )              smtc_modem_hal_get_time_in_ms( )
#endif
#ifndef APP_STOP_ENTER
#define APP_STOP_ENTER( ms )        bsp_mcu_enter_stop_mode( ms )
#endif

// --- ACTIVATION MODE & KEYS ---
#define CUSTOM_ACTIVATION_MODE_OTAA 0
#define CUSTOM_ACTIVATION_MODE_ABP  1
#define LORA_ACTIVATION_MODE        CUSTOM_ACTIVATION_MODE_ABP

#define USE_FACTORY_IDS             1   
#define FORCE_FACTORY_RESET_ABP     0   

#define USER_DEV_EUI             { 0x5F, 0x6A, 0x23, 0x00, 0xF0, 0x00, 0x04, 0x19 } 
#define USER_JOIN_EUI            { 0x75, 0x87, 0xBB, 0xB7, 0xC5, 0x40, 0x3C, 0xCE } 
#define USER_APP_KEY             { 0x45, 0xD4, 0x90, 0xE0, 0x5E, 0xF7, 0xD7, 0xC8, \
                                    0x89, 0xF2, 0x10, 0x52, 0xAB, 0x8C, 0x0A, 0xA4 }

/* GenAppKey (multicast root key): NOT hardcoded. All zeros = "not set".
 * It is only needed for OVER-THE-AIR multicast setup (port 200). Manual 'mc set' does not use it.
 * Provision it per device from the terminal:
 *     *CFG# GENAPPKEY 16 <32 hex>     then     *CFG# REBOOT YES
 * and enter the SAME key in ChirpStack for this device. Check it with 'mc keys'. */
#define USER_GEN_APP_KEY         { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, \
                                    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 }

#define USER_DEV_ADDR            ((uint32_t)0x01997FAE)  
#define USER_NWK_S_KEY           { 0xD7, 0x2A, 0x86, 0x2C, 0x7D, 0xCC, 0x10, 0x40, \
                                    0xE1, 0xE4, 0x9E, 0x81, 0x16, 0x82, 0xDC, 0xAB } 
#define USER_APP_S_KEY           { 0xD7, 0x2A, 0x86, 0x2C, 0x7D, 0xCC, 0x10, 0x40, \
                                    0xE1, 0xE4, 0x9E, 0x81, 0x16, 0x82, 0xDC, 0xAB } 

#define CUSTOM_REGION               SMTC_MODEM_REGION_IN_865    
#ifndef CUSTOM_DEPLOYMENT_CLASS
#define CUSTOM_DEPLOYMENT_CLASS     2
#endif
#define CUSTOM_UPLINK_CONFIRMED     false   
#define LORA_ADR_ON                 true    

// --- PORTS ---
#define LORA_PORT_CHAT              10      
#define LORA_PORT_SENSOR            20      
#define LORA_PORT_STATUS            99      
#define LORA_PORT_MULTICAST_CTRL    200  // Multicast Setup Specification Package Port
#define LORA_PORT_FRAG_CTRL         201  // Forward Error Correction & Firmware transport
#define LORA_PORT_CLOCK_SYNC        202  // GPS Epoch Time Sync for Class C Start

// --- MULTICAST ---
// Allowed Class C multicast downlink frequency range (IN865: 865-867 MHz) and max DR index.
#ifndef CFG_MC_FREQ_MIN_HZ
#define CFG_MC_FREQ_MIN_HZ          865000000UL
#endif
#ifndef CFG_MC_FREQ_MAX_HZ
#define CFG_MC_FREQ_MAX_HZ          867000000UL
#endif
#ifndef CFG_MC_DR_MAX
#define CFG_MC_DR_MAX               5
#endif

// 1 = ask the network for GPS time (DeviceTimeReq) after join so McClassCSessionReq can be scheduled.
#ifndef APP_MC_REQUEST_DEVICE_TIME
#define APP_MC_REQUEST_DEVICE_TIME  1
#endif

// 1 = use rx_metadata.window / fcnt_down to detect multicast frames (enable after checking the
// field/enum names against YOUR smtc_modem_api.h - see lora_app.c, function mc_group_from_window).
#ifndef APP_MC_WINDOW_DETECT
#define APP_MC_WINDOW_DETECT        0
#endif

// 1 = 'mc keys' prints the multicast session keys and the GenAppKey in clear text (bench use).
// Set to 0 for production boards.
#ifndef APP_MC_SHOW_KEYS
#define APP_MC_SHOW_KEYS            1
#endif

void lora_app_init( void );                 
void lora_app_process( void );              
void main_periodical_uplink( void );        
void lora_app_join_network( void );         
void lora_app_leave_network( void );        
void lora_app_set_class( uint8_t new_class ); 
void lora_app_send_text( uint8_t fport, const char* text, bool confirmed ); 
void lora_app_set_adr_profile( uint8_t profile ); 
void lora_app_uart_wake_notify( void );

#ifdef __cplusplus
}
#endif

#endif // LORA_APP_H