/**
 * @file      sensor_manager.h
 * @brief     Extensible Dynamic I2C Multi-Sensor Management Subsystem (Cayenne LPP)
 */

#ifndef SENSOR_MANAGER_H
#define SENSOR_MANAGER_H

#include <stdint.h>
#include <stdbool.h>

#define MAX_SUPPORTED_I2C_SENSORS   16   // Scalable buffer size
#define LORA_PORT_SENSOR_DATA       15   // Dedicated LoRaWAN FPort for telemetry
#define LORA_PORT_SENSOR_CMD        16   // Dedicated LoRaWAN FPort for sensor commands

/**
 * @brief Data Type Identifiers (Compatible with Cayenne LPP standards)
 */
typedef enum {
    TYPE_DIGITAL_INPUT   = 0x00,  // 1 byte
    TYPE_DIGITAL_OUTPUT  = 0x01,  // 1 byte
    TYPE_ANALOG_IN       = 0x02,  // 2 bytes, 0.01 signed
    TYPE_TEMPERATURE     = 0x67,  // 2 bytes, 0.1 deg C signed
    TYPE_HUMIDITY        = 0x68,  // 1 byte, 0.5 % unsigned
    TYPE_BAROMETER       = 0x73,  // 2 bytes, 0.1 hPa unsigned
    TYPE_VOLTAGE         = 0x74,  // 2 bytes, 0.01 V unsigned
} sensor_data_type_t;

/**
 * @brief Sensor Descriptor Structure
 */
typedef struct {
    uint8_t            sensor_id;       // Logical ID (1 to 255) for differentiation
    uint8_t            i2c_address;     // Physical 7-bit I2C device address
    sensor_data_type_t data_type;       // Payload interpretation format
    bool               is_enabled;      // Dynamic run-time enable/disable flag
    bool               hardware_online; // Detected on physical I2C bus scan
    
    // Function pointer to sensor driver read routine returning FLOATS
    float (*read_value_fn)(uint8_t i2c_addr);
} i2c_sensor_descriptor_t;

void sensor_manager_init( void );
uint8_t sensor_manager_pack_uplink( uint8_t *out_buffer, uint8_t max_len );
void sensor_manager_process_downlink( const uint8_t *rx_buf, uint8_t rx_len );
void sensor_manager_trigger_sample_and_send( bool confirmed );

#endif // SENSOR_MANAGER_H