/**
 * @file      bsp_mcu.c
 * @brief     Board Support Package implementation (UART console, I2C, Stop mode)
 *
 * Console changes (vs. old version):
 *  - UART RX ISR only pushes bytes into a FIFO (nothing is lost while a line waits to be handled)
 *  - bsp_console_poll() (main loop) does echo, backspace, Enter -> firmware owns the terminal line
 *  - bsp_console_log_begin()/log_end() let the trace printer erase + redraw the half-typed line,
 *    so log output never lands in the middle of what the user is typing
 *  - bsp_console_is_typing()/has_pending() are used by lora_app.c to stop windows closing / sleep
 *    while the user is typing
 *
 * PuTTY: Terminal -> Local echo = Force off, Local line editing = Force off.
 */

#include <stdint.h>
#include <stdbool.h>
#include <string.h>

#include "bsp_mcu.h"
#include "smtc_hal_mcu.h"
#include "smtc_hal_watchdog.h"
#include "smtc_hal_dbg_trace.h"
#include "smtc_modem_hal.h"
#include "stm32l0xx_hal.h"
#if( BSP_STOP_USE_HAL_RTC == 1 )
#include "smtc_hal_rtc.h"
#endif

extern uint32_t SystemCoreClock;

/* Global UART buffers expected by smtc_hal_uart.c.
 * uart_tx_buffer / rx_index now hold the line being edited. */
uint8_t          uart_tx_buffer[BSP_UART_RX_BUF_SIZE];
volatile uint8_t rx_index       = 0;
volatile bool    new_text_ready = false;

/* ------------------------------------------------------------------------- */
/*  Console tunables                                                          */
/* ------------------------------------------------------------------------- */
#ifndef BSP_RX_FIFO_SIZE
#define BSP_RX_FIFO_SIZE 64u /* must be a power of two, <= 128 */
#endif
#ifndef BSP_CONSOLE_ECHO
#define BSP_CONSOLE_ECHO 0 /* 0 = firmware does NOT echo keys (PuTTY / the HAL already show them) - no doubling.
                            * 1 = firmware echoes keys (only if PuTTY Local echo is Force off and the HAL
                            *     does not echo) - gives correct on-screen backspace */
#endif
#ifndef BSP_HALF_LINE_CAP_MS
#define BSP_HALF_LINE_CAP_MS 15000u /* a half-typed line older than this is discarded */
#endif

#define BSP_ELAPSED( now, ref ) ( ( uint32_t )( ( uint32_t )( now ) - ( uint32_t )( ref ) ) )

static volatile uint8_t s_fifo[BSP_RX_FIFO_SIZE];
static volatile uint8_t s_fifo_head = 0; /* written by the RX ISR   */
static volatile uint8_t s_fifo_tail = 0; /* read by the main loop   */
static uint32_t         s_last_key_ms = 0;
static bool             s_prev_was_cr = false;
static bool             s_log_partial = false; /* last log chunk did not end with a newline */

/* ------------------------------------------------------------------------- */
/*  Clocks                                                                    */
/* ------------------------------------------------------------------------- */
void bsp_rcc_init( void )
{
    uint32_t t;

    /* Stop mode switches HSI/HSE and the PLL off: bring the PLL source and the PLL back first */
    if( LL_RCC_PLL_GetMainSource( ) == LL_RCC_PLLSOURCE_HSE )
    {
        LL_RCC_HSE_Enable( );
        for( t = 1000000U; ( t > 0U ) && !LL_RCC_HSE_IsReady( ); t-- ) { }
    }
    else
    {
        LL_RCC_HSI_Enable( );
        for( t = 1000000U; ( t > 0U ) && !LL_RCC_HSI_IsReady( ); t-- ) { }
    }

    LL_RCC_PLL_Enable( );
    for( t = 1000000U; ( t > 0U ) && !LL_RCC_PLL_IsReady( ); t-- ) { }

    if( LL_RCC_PLL_IsReady( ) )
    {
        LL_RCC_SetSysClkSource( LL_RCC_SYS_CLKSOURCE_PLL );
        for( t = 1000000U; ( t > 0U ) && ( LL_RCC_GetSysClkSource( ) != LL_RCC_SYS_CLKSOURCE_STATUS_PLL ); t-- ) { }
        if( LL_RCC_GetSysClkSource( ) == LL_RCC_SYS_CLKSOURCE_STATUS_PLL )
        {
            LL_SetSystemCoreClock( BSP_MCU_FREQ_MHZ * 1000000 );
            return;
        }
    }
    LL_RCC_SetSysClkSource( LL_RCC_SYS_CLKSOURCE_MSI ); /* fallback */
}

/* ------------------------------------------------------------------------- */
/*  I2C                                                                       */
/* ------------------------------------------------------------------------- */
void bsp_i2c_init( void )
{
    LL_APB1_GRP1_EnableClock( LL_APB1_GRP1_PERIPH_I2C1 );
    LL_IOP_GRP1_EnableClock( LL_IOP_GRP1_PERIPH_GPIOB );

    /* SCL */
    LL_GPIO_SetPinMode( BSP_I2C_PORT, BSP_I2C_SCL_PIN, LL_GPIO_MODE_ALTERNATE );
    LL_GPIO_SetPinOutputType( BSP_I2C_PORT, BSP_I2C_SCL_PIN, LL_GPIO_OUTPUT_OPENDRAIN );
    LL_GPIO_SetPinPull( BSP_I2C_PORT, BSP_I2C_SCL_PIN, LL_GPIO_PULL_UP );
    LL_GPIO_SetPinSpeed( BSP_I2C_PORT, BSP_I2C_SCL_PIN, LL_GPIO_SPEED_FREQ_HIGH );
    LL_GPIO_SetAFPin_0_7( BSP_I2C_PORT, BSP_I2C_SCL_PIN, BSP_I2C_AF );

    /* SDA */
    LL_GPIO_SetPinMode( BSP_I2C_PORT, BSP_I2C_SDA_PIN, LL_GPIO_MODE_ALTERNATE );
    LL_GPIO_SetPinOutputType( BSP_I2C_PORT, BSP_I2C_SDA_PIN, LL_GPIO_OUTPUT_OPENDRAIN );
    LL_GPIO_SetPinPull( BSP_I2C_PORT, BSP_I2C_SDA_PIN, LL_GPIO_PULL_UP );
    LL_GPIO_SetPinSpeed( BSP_I2C_PORT, BSP_I2C_SDA_PIN, LL_GPIO_SPEED_FREQ_HIGH );
    LL_GPIO_SetAFPin_0_7( BSP_I2C_PORT, BSP_I2C_SDA_PIN, BSP_I2C_AF );

    LL_I2C_Disable( BSP_I2C_INSTANCE );
    LL_I2C_SetTiming( BSP_I2C_INSTANCE, BSP_I2C_TIMING );
    LL_I2C_Enable( BSP_I2C_INSTANCE );
}

void bsp_mcu_init( void )
{
    hal_mcu_disable_irq( );
    hal_mcu_init( );

    for( volatile uint32_t i = 0; i < 300000; i++ ) { __NOP( ); }

    bsp_i2c_init( );
    hal_mcu_enable_irq( );
}

void bsp_watchdog_reload( void )
{
    hal_watchdog_reload( );
}

void bsp_delay_us( uint32_t us )
{
    hal_mcu_wait_us( us );
}

/* ------------------------------------------------------------------------- */
/*  Raw UART write (blocking, same USART as the trace output)                 */
/*  If your smtc_hal_uart.c transmits with a different function, call that    */
/*  one here instead so both paths share the same TX mechanism.               */
/* ------------------------------------------------------------------------- */
static void bsp_uart_write( const char* s, uint16_t len )
{
    while( len-- > 0U )
    {
        uint32_t t = 100000U;
        while( !LL_USART_IsActiveFlag_TXE( BSP_UART_INSTANCE ) && ( t-- > 0U ) ) { }
        LL_USART_TransmitData8( BSP_UART_INSTANCE, ( uint8_t ) *s++ );
    }
}

/* ------------------------------------------------------------------------- */
/*  UART RX: ISR side                                                         */
/* ------------------------------------------------------------------------- */
void custom_uart_rx_callback( uint8_t rx_data )
{
    const uint8_t next = ( uint8_t )( ( s_fifo_head + 1U ) & ( BSP_RX_FIFO_SIZE - 1U ) );

    if( next != s_fifo_tail ) /* drop only if the FIFO is completely full */
    {
        s_fifo[s_fifo_head] = rx_data;
        s_fifo_head         = next;
    }
}

/* ------------------------------------------------------------------------- */
/*  Console: main-loop side                                                   */
/* ------------------------------------------------------------------------- */
void bsp_console_poll( void )
{
    while( !new_text_ready && ( s_fifo_tail != s_fifo_head ) )
    {
        const uint8_t c = s_fifo[s_fifo_tail];
        s_fifo_tail     = ( uint8_t )( ( s_fifo_tail + 1U ) & ( BSP_RX_FIFO_SIZE - 1U ) );

        if( c == '\r' || c == '\n' )
        {
            if( ( c == '\n' ) && s_prev_was_cr )
            {
                s_prev_was_cr = false; /* second half of a CR+LF pair */
                continue;
            }
            s_prev_was_cr = ( c == '\r' );

            uart_tx_buffer[rx_index] = '\0';
            bsp_uart_write( "\r\n", 2 );
            s_log_partial  = false;
            s_last_key_ms  = smtc_modem_hal_get_time_in_ms( );
            new_text_ready = true;
        }
        else
        {
            s_prev_was_cr = false;

            if( ( c == '\b' ) || ( c == 0x7F ) )
            {
                s_last_key_ms = smtc_modem_hal_get_time_in_ms( );
                if( rx_index > 0U )
                {
                    rx_index--;
#if( BSP_CONSOLE_ECHO == 1 )
                    bsp_uart_write( "\b \b", 3 );
#endif
                }
            }
            else if( ( c >= 32U ) && ( c < 127U ) ) /* printable only: garbled wake-up bytes are ignored */
            {
                s_last_key_ms = smtc_modem_hal_get_time_in_ms( );
                if( rx_index < ( BSP_UART_RX_BUF_SIZE - 1U ) )
                {
                    uart_tx_buffer[rx_index++] = c;
                    s_log_partial              = false; /* the user now owns this terminal row */
#if( BSP_CONSOLE_ECHO == 1 )
                    bsp_uart_write( ( const char* ) &c, 1 );
#endif
                }
            }
        }
    }
}

/* true while a half-typed line exists (discarded after BSP_HALF_LINE_CAP_MS without a key) */
bool bsp_console_is_typing( void )
{
    if( rx_index == 0U )
    {
        return false;
    }

    if( BSP_ELAPSED( smtc_modem_hal_get_time_in_ms( ), s_last_key_ms ) > BSP_HALF_LINE_CAP_MS )
    {
        hal_mcu_disable_irq( );
        memset( uart_tx_buffer, 0, sizeof( uart_tx_buffer ) );
        rx_index = 0;
        hal_mcu_enable_irq( );
        bsp_uart_write( "\r\n[input cleared - idle too long]\r\n> ", 37 );
        return false;
    }
    return true;
}

/* true if a complete line or unread keystrokes are waiting */
bool bsp_console_has_pending( void )
{
    return new_text_ready || ( s_fifo_tail != s_fifo_head );
}

/* Call at the START of every trace chunk: wipes "> half-typed text" from the terminal row */
void bsp_console_log_begin( void )
{
    if( ( rx_index > 0U ) && !s_log_partial )
    {
        bsp_uart_write( "\r\033[K", 4 );
    }
}

/* Call at the END of every trace chunk with its last character (0 if the chunk was empty) */
void bsp_console_log_end( char last_char )
{
    if( last_char == '\n' )
    {
        s_log_partial = false;
        if( rx_index > 0U )
        {
            bsp_uart_write( "> ", 2 );
            bsp_uart_write( ( const char* ) uart_tx_buffer, rx_index );
        }
    }
    else if( last_char != '\0' )
    {
        s_log_partial = true; /* log line still being built: don't touch the row yet */
    }
}

/* ------------------------------------------------------------------------- */
/*  UART line API (unchanged for lora_app.c)                                  */
/* ------------------------------------------------------------------------- */
bool bsp_uart_get_line( uint8_t* out_buf, uint8_t* out_len )
{
    /* Process keystrokes here too, so typing works even if lora_app.c never calls bsp_console_poll() */
    bsp_console_poll( );

    if( !new_text_ready )
    {
        return false;
    }

    hal_mcu_disable_irq( );

    while( rx_index > 0 && ( uart_tx_buffer[rx_index - 1] == '\r' || uart_tx_buffer[rx_index - 1] == '\n' ) )
    {
        uart_tx_buffer[--rx_index] = '\0';
    }

    *out_len = rx_index;
    memcpy( out_buf, uart_tx_buffer, rx_index );
    out_buf[rx_index] = '\0';

    memset( uart_tx_buffer, 0, sizeof( uart_tx_buffer ) );
    rx_index       = 0;
    new_text_ready = false;

    hal_mcu_enable_irq( );
    return ( *out_len > 0 );
}

void bsp_uart_flush( void )
{
    hal_mcu_disable_irq( );

    memset( uart_tx_buffer, 0, sizeof( uart_tx_buffer ) );
    rx_index       = 0;
    new_text_ready = false;
    s_fifo_head    = 0;
    s_fifo_tail    = 0;
    s_prev_was_cr  = false;
    s_log_partial  = false;

    ( void ) LL_USART_ReceiveData8( BSP_UART_INSTANCE );
    BSP_UART_INSTANCE->ICR = USART_ICR_ORECF | USART_ICR_NCF | USART_ICR_FECF | USART_ICR_PECF;
    LL_USART_RequestRxDataFlush( BSP_UART_INSTANCE );

    hal_mcu_enable_irq( );
}

/* ------------------------------------------------------------------------- */
/*  Stop mode                                                                 */
/* ------------------------------------------------------------------------- */
static void bsp_uart_wait_tx_done( void )
{
    uint32_t t = 200000U;
    while( !LL_USART_IsActiveFlag_TC( BSP_UART_INSTANCE ) && ( t-- > 0U ) ) { }
}

/* The UART RX pin (PA3) is also routed to EXTI line 3 as a falling-edge EVENT (start bit).
 * Event mode needs no interrupt handler. */
static void bsp_uart_wake_exti_arm( void )
{
    LL_IOP_GRP1_EnableClock( LL_IOP_GRP1_PERIPH_GPIOA );
    LL_APB2_GRP1_EnableClock( LL_APB2_GRP1_PERIPH_SYSCFG );

    LL_SYSCFG_SetEXTISource( LL_SYSCFG_EXTI_PORTA, LL_SYSCFG_EXTI_LINE3 );
    LL_EXTI_DisableRisingTrig_0_31( LL_EXTI_LINE_3 );
    LL_EXTI_EnableFallingTrig_0_31( LL_EXTI_LINE_3 );
    LL_EXTI_DisableIT_0_31( LL_EXTI_LINE_3 );
    LL_EXTI_EnableEvent_0_31( LL_EXTI_LINE_3 );
    LL_EXTI_ClearFlag_0_31( LL_EXTI_LINE_3 );
}

bool bsp_mcu_enter_stop_mode( uint32_t sleep_duration_ms )
{
    const uint32_t t0 = smtc_modem_hal_get_time_in_ms( );
    bool           woke_early;

    bsp_uart_wait_tx_done( );

    LL_I2C_Disable( BSP_I2C_INSTANCE );
    LL_GPIO_SetPinMode( BSP_I2C_PORT, BSP_I2C_SCL_PIN, LL_GPIO_MODE_ANALOG );
    LL_GPIO_SetPinMode( BSP_I2C_PORT, BSP_I2C_SDA_PIN, LL_GPIO_MODE_ANALOG );

    bsp_uart_wake_exti_arm( );

#if( BSP_STOP_USE_HAL_RTC == 1 )
    if( sleep_duration_ms > 0U )
    {
        hal_rtc_wakeup_timer_set_ms( ( int32_t ) sleep_duration_ms );
    }
#endif

    LL_RCC_SetClkAfterWakeFromStop( LL_RCC_STOP_WAKEUPCLOCK_HSI ); /* fast wake-up */

    HAL_SuspendTick( );
    __HAL_PWR_CLEAR_FLAG( PWR_FLAG_WU );
    HAL_PWR_EnterSTOPMode( PWR_LOWPOWERREGULATOR_ON, PWR_STOPENTRY_WFE );

    /* ---- awake again ---- */
    bsp_rcc_init( );
    HAL_ResumeTick( );

#if( BSP_STOP_USE_HAL_RTC == 1 )
    hal_rtc_wakeup_timer_stop( );
#endif

    BSP_UART_INSTANCE->ICR = USART_ICR_ORECF | USART_ICR_NCF | USART_ICR_FECF | USART_ICR_PECF;
    bsp_i2c_init( );

    if( ( sleep_duration_ms == 0U ) || ( BSP_STOP_USE_HAL_RTC == 0 ) )
    {
        woke_early = true;
    }
    else
    {
        const uint32_t elapsed = ( uint32_t )( smtc_modem_hal_get_time_in_ms( ) - t0 );
        woke_early             = ( ( elapsed + BSP_STOP_WAKE_TOL_MS ) < sleep_duration_ms );
    }

    if( woke_early )
    {
        /* The first character is garbled (clocks were still starting): let it finish, then drop it.
         * The device never goes to sleep with a half-typed line any more (see lora_app.c), so this
         * flush can only drop the wake-up key itself. */
        hal_mcu_wait_us( 3000 );
        bsp_uart_flush( );
    }
    return woke_early;
}