/**
 * @file      lora_app.c
 * @brief     LoRa app: LoRaWAN (unicast + runtime-switchable multicast + single-channel gateway profile)
 *            & raw P2P application controller (compile-time P2P build AND runtime 'p2p' switch)
 *
 * LoRaWAN cast mode (changed from the terminal, always boots in UNICAST):
 *   unicast    -> normal uplink/downlink, exactly like the known-good build
 *   multicast  -> forces mode 2 (always-on, Class C), loads the multicast groups,
 *                 asks the network for the time and accepts port-200 setup commands
 *   cast       -> print the current cast mode
 *
 * Single-channel gateway profile (terminal):
 *   sc on      -> fixed DR0 (SF12/BW125 in IN865), 51-byte payload limit, longer RX window
 *   sc off     -> back to the normal profile (DR5, multi-channel)
 *   sc         -> show state
 *
 * TX power cap (terminal):
 *   txp        -> show the current TX power cap
 *   txp <dBm>  -> cap the TX power at <dBm> (-9..22). 'txp off' = no cap (default)
 *   LoRaWAN: needs the patch in ral_sx126x.c (reads g_app_tx_pwr_limit_dbm).
 *   Raw P2P (runtime): applied directly by this file.
 *
 * Radio frequency offset (terminal):
 *   sco        -> show the current offset
 *   sco <Hz>   -> shift the radio frequency by <Hz> (-20000..20000) for TX AND RX
 *   LoRaWAN: needs the patch in ral_sx126x.c (reads g_app_freq_offset_hz).
 *   Raw P2P (runtime): applied directly by this file.
 *
 * Runtime protocol switch (terminal):
 *   p2p        -> suspend the LoRaWAN modem and run raw P2P on the SX126x
 *   lorawan    -> leave P2P and hand the radio back to the LoRaWAN modem
 *   psf        -> (P2P only) show spreading factor;  psf <7..12> sets it (BOTH nodes must match)
 *
 * Multicast terminal commands: see 'mc help'.
 * GenAppKey (multicast root key) is NOT hardcoded: set it per device with '*CFG# GENAPPKEY 16 <32 hex>'.
 *
 * ---- CHANGES IN THIS REVISION (runtime P2P CRC-error fix, pass 2) ----
 * 24. rp2p_configure() now does the HARD RESET (sx126x_reset) exactly like the compile-time P2P build, so the
 *     radio starts from the same clean state. 'lorawan' therefore REBOOTS the MCU to give the radio back to
 *     the modem (ABP/OTAA session is restored at boot). P2P sleep uses COLD_START like the compile-time build.
 *
 * ---- CHANGES IN THIS REVISION (runtime P2P CRC-error fix) ----
 * 19. rp2p_configure() now runs the SAME radio set-up sequence as the known-good compile-time P2P build
 *     (standby -> optional TCXO/DCDC -> full calibration -> DIO2 RF switch -> packet type -> frequency ->
 *     image calibration -> modulation/packet params -> sync word -> PA -> IRQs). Before, it skipped the
 *     full calibration and DIO2 set-up and inherited whatever state the LoRaWAN modem had left behind.
 *     The chip is still NOT hard-reset, so the modem's TCXO / regulator set-up survives 'lorawan'.
 * 20. 'sco <Hz>' and 'txp <dBm>' now also work inside raw P2P (frequency offset + TX power cap).
 *     SF12 has a very small frequency tolerance: two boards whose crystals differ by a few kHz show
 *     CRC errors in ONE direction only. Sweep 'sco' on the node that gets the CRC errors.
 * 21. 'psf <7..12>' lets you drop the spreading factor at runtime (SF7-SF9 tolerate far more frequency error).
 * 22. P2P status now shows rx_ok / crc_err counters, SF, frequency and power, so you can measure the fix.
 * 23. P2P_USE_TCXO / P2P_USE_DCDC defaults are now shared by the runtime P2P too (default 0 = keep the
 *     modem's setting; set P2P_USE_TCXO=1 only if the compile-time P2P build needed it).
 * 25. Runtime P2P now calls the same P2P_ANT_SW_RX/TX hooks as the known-good compile-time P2P path,
 *     so boards with an external RF switch select the correct antenna path for both directions.
 *
 * ---- PREVIOUS REVISIONS ----
 *  1-6.  Debug pass (TX-wait timeout, ABP counter saving, multicast EEPROM sanitising, boot diagnostics).
 *  7-10. Unicast downlink fix (boots in normal multi-channel profile).
 * 11-15. 'txp' command, region_in_865 join lock, log cleanups.
 * 16-18. Negative 'txp', 'sco' command, status output.
 */

#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>

#include "lora_app.h"
#include "bsp_mcu.h"
#include "eeprom_manager.h"
#include "sensor_manager.h"

#include "smtc_hal_mcu.h"
#include "smtc_hal_watchdog.h"
#include "smtc_hal_dbg_trace.h"
#include "smtc_modem_hal.h"
#include "smtc_modem_crypto.h"
#include "sx126x.h"
#include "sx126x_hal.h"
#if ( CFG_PROTOCOL_MODE != PROTOCOL_P2P )
#include "smtc_modem_api.h"
#include "smtc_modem_utilities.h"
#include "smtc_secure_element.h"
#endif

#ifndef APP_TEST_CONFIRMED_UPLINK
#define APP_TEST_CONFIRMED_UPLINK 0
#endif
#if( APP_TEST_CONFIRMED_UPLINK == 1 )
#undef CUSTOM_UPLINK_CONFIRMED
#define CUSTOM_UPLINK_CONFIRMED true
#endif

/* Print unhandled modem events (set to 1 only when debugging) */
#ifndef APP_DEBUG_EVENTS
#define APP_DEBUG_EVENTS 0
#endif

/* 1 = multicast code is compiled in (it only RUNS after the 'multicast' command) */
#ifndef APP_ENABLE_MULTICAST
#define APP_ENABLE_MULTICAST 1
#endif

/* Ask the network for the time when entering multicast mode (needed to schedule Class C sessions) */
#ifndef APP_MC_REQUEST_DEVICE_TIME
#define APP_MC_REQUEST_DEVICE_TIME 1
#endif

/* 1 = 'mc keys' prints the multicast keys in clear text (bench use). Set 0 for production. */
#ifndef APP_MC_SHOW_KEYS
#define APP_MC_SHOW_KEYS 1
#endif

/* 1 = detect multicast downlinks from the modem's window enum (verify enum names in your smtc_modem_api.h) */
#ifndef APP_MC_WINDOW_DETECT
#define APP_MC_WINDOW_DETECT 0
#endif

/* ABP only: write the frame counters to EEPROM every N frames (not every frame -> less wear / less corruption risk) */
#ifndef APP_FCNT_SAVE_INTERVAL
#define APP_FCNT_SAVE_INTERVAL 10UL
#endif

/* Minimum time the app waits for TX-done before giving up (must cover uplink airtime + RX1 + RX2).
 * LBM raises TXDONE only AFTER the RX windows, so this must NOT be shorter than the whole exchange. */
#ifndef APP_TX_WAIT_MIN_MS
#define APP_TX_WAIT_MIN_MS 8000UL
#endif
#ifndef APP_TX_WAIT_MIN_SC_MS
#define APP_TX_WAIT_MIN_SC_MS 15000UL   /* SF12 */
#endif

/* 1 = boot directly into the gateway-matched single-channel profile (865.0625 MHz, DR0/SF12).
 * Set to 0 to boot in the normal multi-channel profile and enable it later with 'sc on'. */
#ifndef APP_DEFAULT_SINGLE_CHANNEL
#define APP_DEFAULT_SINGLE_CHANNEL 0
#endif

/* ---- Single-channel gateway profile (matches the gateway: 865062500 Hz, SF12, BW125) ---- */
#ifndef SC_FREQ_HZ
#define SC_FREQ_HZ 865062500UL      /* IN865 channel 0 */
#endif
#define SC_DR             0         /* IN865 DR0 = SF12 / BW125 */
#define SC_MAX_PAYLOAD    51        /* max app payload at IN865 DR0 */
#define SC_POST_TX_RX_MS  6500UL    /* RX1 (1 s) + RX2 (2 s) + SF12 downlink airtime */

/* 1 = 'sc on' also locks the LoRaWAN stack to channel 0 (needs the patched region_in_865.c).
 * Set 0 only if the linker cannot find region_in_865_set_single_channel. */
#ifndef APP_SC_REGION_LOCK
#define APP_SC_REGION_LOCK 1
#endif
#if( APP_SC_REGION_LOCK == 1 ) && ( CFG_PROTOCOL_MODE != PROTOCOL_P2P )
extern void region_in_865_set_single_channel( bool enable );
extern bool region_in_865_is_single_channel( void );
#endif

/* TX power cap set with 'txp <dBm>'. Read by ral_sx126x.c on every transmission (LoRaWAN)
 * and by the runtime P2P code in this file. SX1262 can go down to -9 dBm. */
#define APP_TX_PWR_LIMIT_NONE 127
#define APP_TXP_MIN_DBM       ( -9 )
#define APP_TXP_MAX_DBM       22
#define SC_TX_POWER_CAP_DBM    0   /* diagnostic single-channel bench cap */

/* Radio frequency offset set with 'sco <Hz>'. Read by ral_sx126x.c on every set_rf_freq (LoRaWAN)
 * and by the runtime P2P code in this file. */
#define APP_SCO_MAX_HZ        20000L

/* Shared with ral_sx126x.c in both LoRaWAN and compile-time P2P builds. */
volatile int8_t  g_app_tx_pwr_limit_dbm = ( APP_DEFAULT_SINGLE_CHANNEL == 1 ) ? SC_TX_POWER_CAP_DBM : APP_TX_PWR_LIMIT_NONE;
volatile int32_t g_app_freq_offset_hz    = 0;

/* ---- Runtime P2P defaults (only used if your header does not define them) ---- */
#ifndef P2P_FREQUENCY_HZ
#define P2P_FREQUENCY_HZ 865062500UL
#endif
#ifndef P2P_SPREADING_FACTOR
#define P2P_SPREADING_FACTOR SX126X_LORA_SF12
#endif
#ifndef P2P_CODING_RATE
#define P2P_CODING_RATE SX126X_LORA_CR_4_5
#endif
#ifndef P2P_PREAMBLE_LENGTH
#define P2P_PREAMBLE_LENGTH 8
#endif
#ifndef P2P_TX_POWER_DBM
#define P2P_TX_POWER_DBM 14
#endif

/* Shared by compile-time P2P and runtime P2P.
 * Runtime P2P only re-sends the TCXO / DC-DC set-up when these are 1; with 0 it keeps what the modem configured. */
#ifndef P2P_USE_TCXO
#define P2P_USE_TCXO 0
#endif
#ifndef P2P_TCXO_VOLTAGE
#define P2P_TCXO_VOLTAGE SX126X_TCXO_CTRL_1_8V
#endif
#ifndef P2P_TCXO_TIMEOUT_MS
#define P2P_TCXO_TIMEOUT_MS 5
#endif
#ifndef P2P_USE_DCDC
#define P2P_USE_DCDC 0
#endif

extern void bsp_console_poll( void );
extern bool bsp_console_is_typing( void );
extern bool bsp_console_has_pending( void );

#if( CFG_PROTOCOL_MODE == PROTOCOL_LORAWAN ) && ( CUSTOM_DEPLOYMENT_CLASS != 0 ) && ( CUSTOM_DEPLOYMENT_CLASS != 2 )
#error "CUSTOM_DEPLOYMENT_CLASS must be 0 (Class A) or 2 (Class C)"
#endif

#if( CFG_PROTOCOL_MODE != PROTOCOL_P2P ) && defined( FORCE_FACTORY_RESET_ABP ) && ( FORCE_FACTORY_RESET_ABP == 1 )
#warning "FORCE_FACTORY_RESET_ABP == 1: EEPROM credentials are overwritten with the USER_* defaults on EVERY boot. Set it to 0 or your '*CFG#' keys will 'disappear'."
#endif

#if( CFG_PROTOCOL_MODE == PROTOCOL_P2P )
#define APP_USE_RX_WINDOW 1
#else
#define APP_USE_RX_WINDOW ( CUSTOM_DEPLOYMENT_CLASS == 2 )
#endif

#define APP_IS_LP_MODE( m ) ( ( m ) <= 1 )

#ifndef CFG_TYPING_HOLD_MS
#define CFG_TYPING_HOLD_MS 4000UL
#endif

#define TIME_REACHED( now, due ) ( ( int32_t )( ( uint32_t )( now ) - ( uint32_t )( due ) ) >= 0 )
#define ELAPSED( now, ref )      ( ( uint32_t )( ( uint32_t )( now ) - ( uint32_t )( ref ) ) )

typedef enum
{
    LP_SLEEP = 0,
    LP_WAKE_WINDOW,
    LP_TX_WAIT,
    LP_RX_WINDOW
} lp_state_t;

typedef enum
{
    WAKE_UART = 0,
    WAKE_SLEEP_EXPIRED,
    WAKE_PERIODIC
} wake_cause_t;

static uint8_t         current_op_mode   = CFG_DEFAULT_OP_MODE;
static lp_state_t      s_lp_state        = LP_WAKE_WINDOW;
static uint32_t        s_lp_deadline     = 0;
static volatile bool   s_uart_wake_flag  = false;
static uint32_t        s_periodic_ref_ms = 0;
static bool            s_single_channel  = ( APP_DEFAULT_SINGLE_CHANNEL == 1 ); /* true = single-channel gateway profile (LoRaWAN only) */

static void app_apply_mode( uint8_t mode );
static bool app_tx_text( const char* text );
static bool app_tx_sensor( void );
static void app_rx_open( void );
static void app_rx_close( void );
static void app_radio_sleep( void );
static void app_radio_wake( void );
static bool app_lp_can_sleep( void );
static bool app_protocol_command( const char* s );
static void app_print_status( void );
static void app_print_rssi( void );
static void app_print_protocol_info( void );
static void app_dispatch_line( const uint8_t* line, uint8_t len );

void lora_app_uart_wake_notify( void )
{
    s_uart_wake_flag = true;
}

static char app_lower( char c )
{
    return ( ( c >= 'A' ) && ( c <= 'Z' ) ) ? ( char ) ( c + 32 ) : c;
}

static bool app_cmd_is( const char* line, const char* cmd )
{
    for( ;; )
    {
        while( ( *line != '\0' ) && ( ( unsigned char ) *line <= ' ' ) ) line++;
        while( ( *cmd != '\0' ) && ( ( unsigned char ) *cmd <= ' ' ) ) cmd++;
        if( ( *line == '\0' ) || ( *cmd == '\0' ) ) break;
        if( app_lower( *line ) != app_lower( *cmd ) ) return false;
        line++;
        cmd++;
    }
    return ( *line == '\0' ) && ( *cmd == '\0' );
}

static int app_strcasecmp( const char* a, const char* b )
{
    while( ( *a != '\0' ) && ( *b != '\0' ) && ( app_lower( *a ) == app_lower( *b ) ) )
    {
        a++;
        b++;
    }
    return ( int ) ( unsigned char ) app_lower( *a ) - ( int ) ( unsigned char ) app_lower( *b );
}

static int app_strncasecmp( const char* a, const char* b, size_t n )
{
    while( n > 0 )
    {
        if( ( *a == '\0' ) || ( *b == '\0' ) || ( app_lower( *a ) != app_lower( *b ) ) )
        {
            return ( int ) ( unsigned char ) app_lower( *a ) - ( int ) ( unsigned char ) app_lower( *b );
        }
        a++;
        b++;
        n--;
    }
    return 0;
}

/* true when a 16-byte key is all zeros (= "not set" / wiped) */
static inline bool app_key_is_zero( const uint8_t* k )
{
    for( uint8_t i = 0; i < 16U; i++ )
    {
        if( k[i] != 0U ) return false;
    }
    return true;
}

/* ============================================================================
 * --- CONFIGURATION COMMAND PARSER ---
 * ========================================================================== */

static int8_t hex_nibble( char c )
{
    if( c >= '0' && c <= '9' ) return c - '0';
    if( c >= 'a' && c <= 'f' ) return c - 'a' + 10;
    if( c >= 'A' && c <= 'F' ) return c - 'A' + 10;
    return -1;
}

typedef enum
{
    HEX_OK = 0,
    HEX_ERR_CHAR,
    HEX_ERR_ODD,
    HEX_ERR_TOO_MANY,
    HEX_ERR_TOO_FEW
} hex_result_t;

static bool hex_is_separator( char t )
{
    return ( t == '\0' || t == '\r' || t == '\n' || t == ' ' || t == '\t' || t == ',' || t == '{' || t == '}' ||
             t == ';' );
}

static hex_result_t hex_to_bytes( const char* s, uint8_t* out, uint8_t expected_len, uint8_t* got_len )
{
    uint8_t count = 0;

    while( *s != '\0' && *s != '\r' && *s != '\n' )
    {
        char c = *s;

        if( c == ' ' || c == '\t' || c == ',' || c == '{' || c == '}' || c == ';' )
        {
            s++;
            continue;
        }

        if( c == '0' && ( s[1] == 'x' || s[1] == 'X' ) && hex_nibble( s[2] ) >= 0 )
        {
            s += 2;
        }

        const char* start = s;
        uint8_t     n     = 0;
        while( hex_nibble( s[n] ) >= 0 ) n++;

        if( n == 0 )
        {
            if( got_len ) *got_len = count;
            return HEX_ERR_CHAR;
        }

        if( !hex_is_separator( start[n] ) )
        {
            if( got_len ) *got_len = count;
            return HEX_ERR_CHAR;
        }

        if( n != 1 && ( n & 1U ) )
        {
            if( got_len ) *got_len = count;
            return HEX_ERR_ODD;
        }

        if( n == 1 )
        {
            if( count >= expected_len )
            {
                if( got_len ) *got_len = count + 1;
                return HEX_ERR_TOO_MANY;
            }
            out[count++] = ( uint8_t ) hex_nibble( start[0] );
        }
        else
        {
            for( uint8_t i = 0; i < n; i += 2 )
            {
                if( count >= expected_len )
                {
                    if( got_len ) *got_len = count + 1;
                    return HEX_ERR_TOO_MANY;
                }
                out[count++] = ( uint8_t ) ( ( hex_nibble( start[i] ) << 4 ) | hex_nibble( start[i + 1] ) );
            }
        }
        s = start + n;
    }

    if( got_len ) *got_len = count;
    return ( count == expected_len ) ? HEX_OK : HEX_ERR_TOO_FEW;
}

static void app_print_cfg_help( void )
{
    SMTC_HAL_TRACE_INFO( "\r\n=========== KEY CONFIGURATION HELP ===========\r\n" );
    SMTC_HAL_TRACE_INFO( "Format : *CFG# <NAME> <LENGTH> <HEX / C-Array>\r\n" );
    SMTC_HAL_TRACE_INFO( "Rules  : Accepts continuous hex, 0x-prefixed hex,\r\n" );
    SMTC_HAL_TRACE_INFO( "         or C-style arrays.\r\n" );
    SMTC_HAL_TRACE_INFO( "         Hex   : 01997FAE\r\n" );
    SMTC_HAL_TRACE_INFO( "         Array : { 0x01, 0x99, 0x7F, 0xAE }\r\n\r\n" );
    SMTC_HAL_TRACE_INFO( "  *CFG# DEVEUI     8  <8 bytes>\r\n" );
    SMTC_HAL_TRACE_INFO( "  *CFG# DEVADDR    4  <4 bytes>\r\n" );
    SMTC_HAL_TRACE_INFO( "  *CFG# NWKSKEY    16 <16 bytes> (ABP)\r\n" );
    SMTC_HAL_TRACE_INFO( "  *CFG# APPSKEY    16 <16 bytes> (ABP)\r\n" );
    SMTC_HAL_TRACE_INFO( "  *CFG# JOINEUI    8  <8 bytes>  (OTAA)\r\n" );
    SMTC_HAL_TRACE_INFO( "  *CFG# APPKEY     16 <16 bytes> (OTAA)\r\n" );
    SMTC_HAL_TRACE_INFO( "  *CFG# GENAPPKEY  16 <16 bytes> (Multicast Root Key, unique per device)\r\n\r\n" );
    SMTC_HAL_TRACE_INFO( "Example (Hex)  : *CFG# DEVADDR 4 01997FAE\r\n" );
    SMTC_HAL_TRACE_INFO( "Example (Array): *CFG# DEVADDR 4 { 0x01, 0x99, 0x7F, 0xAE }\r\n" );
    SMTC_HAL_TRACE_INFO( "  *CFG# SHOW         -> print DevEUI / DevAddr\r\n" );
    SMTC_HAL_TRACE_INFO( "  *CFG# SHOW KEYS    -> print all keys stored in EEPROM\r\n" );
    SMTC_HAL_TRACE_INFO( "  *CFG# REBOOT YES   -> reboot and load new values\r\n" );
    SMTC_HAL_TRACE_INFO( "  #HELP              -> show this list\r\n" );
#if( CFG_PROTOCOL_MODE == PROTOCOL_LORAWAN )
    SMTC_HAL_TRACE_INFO( "  unicast / multicast / cast -> change or show the LoRaWAN cast mode\r\n" );
    SMTC_HAL_TRACE_INFO( "  sc on / sc off / sc        -> single-channel gateway profile (SF12, DR0)\r\n" );
    SMTC_HAL_TRACE_INFO( "  txp / txp <dBm>            -> show / cap the TX power (-9..22, or 'off')\r\n" );
    SMTC_HAL_TRACE_INFO( "  sco / sco <Hz>             -> show / set radio frequency offset (-20000..20000 Hz)\r\n" );
    SMTC_HAL_TRACE_INFO( "  p2p / lorawan              -> switch between raw P2P and LoRaWAN\r\n" );
    SMTC_HAL_TRACE_INFO( "  psf / psf <7..12>          -> (P2P only) show / set spreading factor\r\n" );
    SMTC_HAL_TRACE_INFO( "  mc help            -> multicast commands and setup guide\r\n" );
    SMTC_HAL_TRACE_INFO( "  mc show / mc keys  -> view multicast state / keys\r\n" );
#endif
    SMTC_HAL_TRACE_INFO( "Changes apply only AFTER the reboot.\r\n" );
    SMTC_HAL_TRACE_INFO( "==============================================\r\n> " );
}

static void app_handle_cfg_command( const uint8_t* line )
{
    char cmd_buf[200];

    strncpy( cmd_buf, ( const char* ) line + 5, sizeof( cmd_buf ) - 1 );
    cmd_buf[sizeof( cmd_buf ) - 1] = '\0';

    char* token1 = strtok( cmd_buf, " \r\n" );
    char* token2 = strtok( NULL, " \r\n" );
    char* token3 = strtok( NULL, "\r\n" );

    if( !token1 || app_strcasecmp( token1, "HELP" ) == 0 )
    {
        app_print_cfg_help( );
        return;
    }

    if( app_strcasecmp( token1, "SHOW" ) == 0 )
    {
        if( token2 && app_strcasecmp( token2, "KEYS" ) == 0 ) { eeprom_print_keys( ); }
        else                                                  { eeprom_print_ids( ); }
        return;
    }

    if( app_strcasecmp( token1, "REBOOT" ) == 0 )
    {
        if( token2 && app_strcasecmp( token2, "YES" ) == 0 )
        {
            SMTC_HAL_TRACE_INFO( "\r\n[CFG] Rebooting system to apply changes...\r\n" );
            hal_mcu_wait_us( 200000 );
            NVIC_SystemReset( );
        }
        else
        {
            SMTC_HAL_TRACE_INFO( "\r\n[CFG] Reboot cancelled. (Use '*CFG# REBOOT YES' to confirm)\r\n> " );
        }
        return;
    }

    if( !token2 || !token3 )
    {
        SMTC_HAL_TRACE_ERROR( "\r\n[CFG] Syntax Error! Missing arguments.\r\n" );
        SMTC_HAL_TRACE_ERROR( "[CFG] Format: *CFG# <KEY_NAME> <LENGTH> <HEX_OR_ARRAY>\r\n> " );
        return;
    }

    while( *token3 == ' ' || *token3 == '\t' || *token3 == '\r' || *token3 == '\n' )
    {
        token3++;
    }

    uint8_t length = ( uint8_t ) atoi( token2 );
    if( length > 16 || length == 0 )
    {
        SMTC_HAL_TRACE_ERROR( "\r\n[CFG] ERROR: Invalid length specified (%d).\r\n> ", length );
        return;
    }

    uint8_t      bin_data[16] = { 0 };
    uint8_t      got          = 0;
    hex_result_t hr           = hex_to_bytes( token3, bin_data, length, &got );

    if( hr != HEX_OK )
    {
        switch( hr )
        {
        case HEX_ERR_TOO_FEW:
            SMTC_HAL_TRACE_ERROR( "\r\n[CFG] ERROR: Incomplete - expected %d bytes, got %d.\r\n> ", length, got );
            break;
        case HEX_ERR_TOO_MANY:
            SMTC_HAL_TRACE_ERROR( "\r\n[CFG] ERROR: Too many bytes - expected %d.\r\n> ", length );
            break;
        case HEX_ERR_ODD:
            SMTC_HAL_TRACE_ERROR( "\r\n[CFG] ERROR: Odd number of hex digits in a group.\r\n> " );
            break;
        default:
            SMTC_HAL_TRACE_ERROR( "\r\n[CFG] ERROR: Invalid character in key data.\r\n> " );
            break;
        }
        return;
    }

    if( eeprom_manager_update_key( token1, length, bin_data ) )
    {
        SMTC_HAL_TRACE_INFO( "\r\n[CFG] SUCCESS! '%s' safely updated in EEPROM.\r\n", token1 );
        SMTC_HAL_TRACE_INFO( "[CFG] Type '*CFG# SHOW KEYS' to check, '*CFG# REBOOT YES' to load.\r\n> " );
    }
    else
    {
        SMTC_HAL_TRACE_ERROR( "\r\n[CFG] FAILED! Bad key name '%s', wrong length %d, or EEPROM write/verify error.\r\n> ",
                              token1, length );
    }
}

/* ========================================================================== */

static void app_announce_mode( uint8_t mode )
{
    if( mode == 2 )
    {
        SMTC_HAL_TRACE_INFO( "\r\n[MODE 2] ALWAYS-ON | never sleeps, send + receive at any time.\r\n" );
    }
    else if( mode == 1 )
    {
        SMTC_HAL_TRACE_INFO( "\r\n[MODE 1] DEEP SLEEP | Stop mode for %lu ms (or until UART).\r\n",
                             ( unsigned long ) CFG_MODE1_SLEEP_MS );
        SMTC_HAL_TRACE_INFO( "         timer expiry -> %lu ms RX window -> sleep.\r\n", ( unsigned long ) CFG_RX_WINDOW_MS );
        SMTC_HAL_TRACE_INFO( "         UART wake -> %lu ms to type + Enter -> uplink -> RX window -> sleep.\r\n",
                             ( unsigned long ) CFG_WAKE_WINDOW_MS );
    }
    else
    {
        SMTC_HAL_TRACE_INFO( "\r\n[MODE 0] TIMED WAKE | sleeps in Stop mode, UART wakes it.\r\n" );
        SMTC_HAL_TRACE_INFO( "         %lu ms to type + Enter -> uplink -> %lu ms RX window -> sleep.\r\n",
                             ( unsigned long ) CFG_WAKE_WINDOW_MS, ( unsigned long ) CFG_RX_WINDOW_MS );
    }
    app_print_protocol_info( );
    SMTC_HAL_TRACE_INFO( "> " );
}

static void app_print_help( void )
{
#if( CFG_PROTOCOL_MODE == PROTOCOL_LORAWAN )
    SMTC_HAL_TRACE_INFO( "\r\nCommands: %s | %s | %s | %s | %s | %s | %s | %s | %s | unicast | multicast | cast | sc on | sc off | txp | sco | p2p | lorawan | psf | mc | any text = uplink\r\n> ",
                         CFG_CMD_MODE_0, CFG_CMD_MODE_1, CFG_CMD_MODE_2, CFG_CMD_MODE_QUERY, CFG_CMD_TRIGGER_SENSOR,
                         CFG_CMD_FORCE_SLEEP_TXT, CFG_CMD_STATUS, CFG_CMD_RSSI, CFG_CMD_HELP );
#else
    SMTC_HAL_TRACE_INFO( "\r\nCommands: %s | %s | %s | %s | %s | %s | %s | %s | %s | any text = uplink\r\n> ", CFG_CMD_MODE_0,
                         CFG_CMD_MODE_1, CFG_CMD_MODE_2, CFG_CMD_MODE_QUERY, CFG_CMD_TRIGGER_SENSOR,
                         CFG_CMD_FORCE_SLEEP_TXT, CFG_CMD_STATUS, CFG_CMD_RSSI, CFG_CMD_HELP );
#endif
}

static uint32_t app_sleep_ms( void )
{
    return ( current_op_mode == 1 ) ? ( uint32_t ) CFG_MODE1_SLEEP_MS : ( uint32_t ) CFG_MODE0_SLEEP_MS;
}

static void app_periodic_reschedule( void )
{
    s_periodic_ref_ms = APP_TIME_MS( );
}

/* How long to wait for TX-done. LBM reports TXDONE only after RX1/RX2 are over, so this must cover
 * the full uplink + RX1 + RX2 exchange (SF12 is slow). */
static uint32_t app_tx_wait_ms( void )
{
    const uint32_t min_ms = s_single_channel ? APP_TX_WAIT_MIN_SC_MS : APP_TX_WAIT_MIN_MS;
    const uint32_t cfg_ms = ( uint32_t ) CFG_TX_TIMEOUT_MS;
    return ( cfg_ms > min_ms ) ? cfg_ms : min_ms;
}

static void app_lp_begin_wake_window( void )
{
    s_lp_state    = LP_WAKE_WINDOW;
    s_lp_deadline = APP_TIME_MS( ) + CFG_WAKE_WINDOW_MS;
}

static void app_lp_note_tx_started( void )
{
    if( APP_IS_LP_MODE( current_op_mode ) )
    {
        s_lp_state    = LP_TX_WAIT;
        s_lp_deadline = APP_TIME_MS( ) + app_tx_wait_ms( );
    }
}

static void app_lp_open_rx_window( void )
{
    s_lp_state    = LP_RX_WINDOW;
    s_lp_deadline = APP_TIME_MS( ) + CFG_RX_WINDOW_MS;
    app_rx_open( );
}

static void app_lp_on_tx_done( void )
{
    if( APP_IS_LP_MODE( current_op_mode ) && ( s_lp_state == LP_TX_WAIT ) )
    {
        const uint32_t win = s_single_channel ? SC_POST_TX_RX_MS : 3500UL;

        s_lp_state    = LP_RX_WINDOW;
        s_lp_deadline = APP_TIME_MS( ) + win;
        SMTC_HAL_TRACE_INFO( "[MODE %u] Uplink done -> %lu ms RX window active for RX1/RX2 downlinks...\r\n",
                             ( unsigned ) current_op_mode, ( unsigned long ) win );
    }
}

static wake_cause_t app_sleep_until_wake( void )
{
    const uint32_t t0       = APP_TIME_MS( );
    const uint32_t sleep_ms = app_sleep_ms( );

    s_uart_wake_flag = false;

    for( ;; )
    {
        const uint32_t now   = APP_TIME_MS( );
        uint32_t       slice = CFG_STOP_SLICE_MS;

        if( s_uart_wake_flag )
        {
            return WAKE_UART;
        }

        if( sleep_ms != 0U )
        {
            const uint32_t el = ELAPSED( now, t0 );
            if( el >= sleep_ms )
            {
                return WAKE_SLEEP_EXPIRED;
            }
            if( ( sleep_ms - el ) < slice ) slice = sleep_ms - el;
        }

#if( CFG_SLEEP_PERIODIC_SENSOR_MS > 0 )
        {
            const uint32_t el = ELAPSED( now, s_periodic_ref_ms );
            if( el >= CFG_SLEEP_PERIODIC_SENSOR_MS )
            {
                return WAKE_PERIODIC;
            }
            if( ( CFG_SLEEP_PERIODIC_SENSOR_MS - el ) < slice ) slice = CFG_SLEEP_PERIODIC_SENSOR_MS - el;
        }
#endif
        if( slice == 0U ) slice = 1U;

        const bool woke_early = APP_STOP_ENTER( slice );
        bsp_watchdog_reload( );

        if( woke_early )
        {
            return WAKE_UART;
        }
    }
}

static bool app_do_sensor( void )
{
    bool ok = app_tx_sensor( );
    if( ok )
    {
        app_periodic_reschedule( );
        app_lp_note_tx_started( );
    }
    return ok;
}

static void app_lp_service( void )
{
    const uint32_t now = APP_TIME_MS( );

    if( bsp_console_is_typing( ) || bsp_console_has_pending( ) )
    {
        if( ( s_lp_state == LP_WAKE_WINDOW ) || ( s_lp_state == LP_SLEEP ) )
        {
            app_lp_begin_wake_window( );
        }
        else if( ( s_lp_state == LP_RX_WINDOW ) && TIME_REACHED( now + CFG_TYPING_HOLD_MS, s_lp_deadline ) )
        {
            s_lp_deadline = now + CFG_TYPING_HOLD_MS;
        }
    }

    switch( s_lp_state )
    {
    case LP_WAKE_WINDOW:
        if( TIME_REACHED( now, s_lp_deadline ) )
        {
            s_lp_state = LP_SLEEP;
        }
        break;

    case LP_TX_WAIT:
        if( TIME_REACHED( now, s_lp_deadline ) )
        {
            SMTC_HAL_TRACE_INFO( "[MODE %u] No TX-done, giving up.\r\n", ( unsigned ) current_op_mode );
            s_lp_state = LP_SLEEP;
        }
        break;

    case LP_RX_WINDOW:
        if( TIME_REACHED( now, s_lp_deadline ) )
        {
            app_rx_close( );
            SMTC_HAL_TRACE_INFO( "[MODE %u] Receive window closed.\r\n", ( unsigned ) current_op_mode );
            s_lp_state = LP_SLEEP;
        }
        break;

    case LP_SLEEP:
    {
        wake_cause_t cause;

        if( !app_lp_can_sleep( ) )
        {
            app_lp_begin_wake_window( );
            break;
        }
        SMTC_HAL_TRACE_INFO( "\r\n[SLEEP] Mode %u, Stop mode - press any key to wake\r\n", ( unsigned ) current_op_mode );
        hal_mcu_wait_us( CFG_PRE_SLEEP_DELAY_MS * 1000UL );

        bsp_console_poll( );
        if( bsp_console_is_typing( ) || bsp_console_has_pending( ) )
        {
            app_lp_begin_wake_window( );
            break;
        }

        app_radio_sleep( );
        cause = app_sleep_until_wake( );
        app_radio_wake( );

        if( cause == WAKE_UART )
        {
            SMTC_HAL_TRACE_INFO( "[WAKE] Awake - type your command + Enter.\r\n> " );
            app_lp_begin_wake_window( );
        }
        else if( cause == WAKE_PERIODIC )
        {
            SMTC_HAL_TRACE_INFO( "[WAKE] Timer -> sending sensor packet\r\n" );
            if( !app_do_sensor( ) )
            {
                app_lp_begin_wake_window( );
            }
        }
        else
        {
#if( APP_USE_RX_WINDOW )
            SMTC_HAL_TRACE_INFO( "[WAKE] Sleep time over -> %lu ms receive window\r\n", ( unsigned long ) CFG_RX_WINDOW_MS );
            app_lp_open_rx_window( );
#else
            SMTC_HAL_TRACE_INFO( "[WAKE] Sleep time over -> sleeping\r\n" );
            s_lp_state = LP_SLEEP;
#endif
        }
        break;
    }

    default:
        break;
    }
}

static void app_force_sleep( void )
{
    if( !APP_IS_LP_MODE( current_op_mode ) )
    {
        app_apply_mode( 0 );
    }
    s_lp_state = LP_SLEEP;
}

static void app_dispatch_line( const uint8_t* line, uint8_t len )
{
    const char*          s           = ( const char* ) line;
    static const uint8_t sleep_bin[] = CFG_CMD_FORCE_SLEEP_BIN;

    if( len == 0 )
    {
        SMTC_HAL_TRACE_INFO( "> " );
        return;
    }

    if( app_cmd_is( s, "#help" ) )
    {
        app_print_cfg_help( );
        return;
    }

    if( app_strncasecmp( ( const char* ) line, "*CFG#", 5 ) == 0 )
    {
        app_handle_cfg_command( line );
        return;
    }

    if( line[0] == sleep_bin[0] )
    {
        if( ( len >= sizeof( sleep_bin ) ) && ( memcmp( line, sleep_bin, sizeof( sleep_bin ) ) == 0 ) )
        {
            SMTC_HAL_TRACE_INFO( "\r\n[CMD] Hex sleep command received.\r\n" );
            app_force_sleep( );
        }
        else
        {
            SMTC_HAL_TRACE_WARNING( "\r\n[CMD] Unknown hex command sequence\r\n" );
        }
        return;
    }

    if( app_cmd_is( s, CFG_CMD_MODE_0 ) )      { app_apply_mode( 0 ); }
    else if( app_cmd_is( s, CFG_CMD_MODE_1 ) ) { app_apply_mode( 1 ); }
    else if( app_cmd_is( s, CFG_CMD_MODE_2 ) ) { app_apply_mode( 2 ); }
    else if( app_cmd_is( s, CFG_CMD_MODE_QUERY ) )
    {
        SMTC_HAL_TRACE_INFO( "\r\n[MODE] Current mode = %u\r\n", ( unsigned ) current_op_mode );
        app_print_protocol_info( );
        SMTC_HAL_TRACE_INFO( "> " );
    }
    else if( app_cmd_is( s, CFG_CMD_RSSI ) )
    {
        app_print_rssi( );
    }
    else if( app_cmd_is( s, CFG_CMD_STATUS ) )
    {
        app_print_status( );
    }
    else if( app_cmd_is( s, CFG_CMD_HELP ) )
    {
        app_print_help( );
    }
    else if( app_cmd_is( s, CFG_CMD_FORCE_SLEEP_TXT ) || app_cmd_is( s, CFG_CMD_FORCE_SLEEP_HEX ) )
    {
        SMTC_HAL_TRACE_INFO( "\r\n[CMD] Sleep command received.\r\n" );
        app_force_sleep( );
    }
    else if( app_cmd_is( s, CFG_CMD_TRIGGER_SENSOR ) )
    {
        SMTC_HAL_TRACE_INFO( "\r\n[SYSTEM] Reading sensors and sending...\r\n" );
        if( !app_do_sensor( ) )
        {
            SMTC_HAL_TRACE_INFO( "[SYSTEM] Sensor packet not sent.\r\n> " );
        }
    }
    else if( app_protocol_command( s ) )
    {
        /* handled */
    }
    else if( app_tx_text( s ) )
    {
        app_lp_note_tx_started( );
    }

    if( APP_IS_LP_MODE( current_op_mode ) && ( s_lp_state == LP_WAKE_WINDOW ) )
    {
        app_lp_begin_wake_window( );
    }
}

#if ( CFG_PROTOCOL_MODE == PROTOCOL_P2P )

/* ============================================================================
 * --- RAW P2P IMPLEMENTATION (compile-time P2P build, unchanged) ---
 * ========================================================================== */

#ifndef P2P_ANT_SW_RX
#define P2P_ANT_SW_RX( )
#endif
#ifndef P2P_ANT_SW_TX
#define P2P_ANT_SW_TX( )
#endif

#define P2P_PP_REPLY_DELAY_MS 100U
#define P2P_PP_PERIOD_MS      1000U
#define P2P_PP_TIMEOUT_MS     3000U

#define P2P_CHECK( call )                                                         \
    do                                                                            \
    {                                                                             \
        sx126x_status_t st_ = ( call );                                           \
        if( st_ != SX126X_STATUS_OK )                                             \
        {                                                                         \
            SMTC_HAL_TRACE_INFO( "[P2P] " #call " FAILED (status %d)\r\n", st_ ); \
        }                                                                         \
    } while( 0 )

static void*   p2p_context = NULL;
static uint8_t p2p_tx_buffer[255];

static volatile bool p2p_tx_busy      = false;
static bool          p2p_pp_master    = false;
static uint32_t      p2p_next_ping_ms = 0;
static bool          p2p_pong_pending = false;
static uint32_t      p2p_pong_due_ms  = 0;
static uint32_t      p2p_ping_count   = 0;
static uint32_t      p2p_pong_count   = 0;

static void p2p_start_rx( void )
{
    P2P_ANT_SW_RX( );
    sx126x_clear_irq_status( p2p_context, SX126X_IRQ_ALL );
    P2P_CHECK( sx126x_set_rx_with_timeout_in_rtc_step( p2p_context, SX126X_RX_CONTINUOUS ) );
}

static void p2p_standby( void )
{
    P2P_CHECK( sx126x_set_standby( p2p_context, SX126X_STANDBY_CFG_RC ) );
}

static void p2p_print_status( void )
{
    sx126x_chip_status_t chip_status;
    int16_t              rssi = 0;

    sx126x_get_status( p2p_context, &chip_status );
    sx126x_get_rssi_inst( p2p_context, &rssi );

    SMTC_HAL_TRACE_INFO( "\r\n[P2P] mode=%u chip_mode=%d cmd_status=%d inst_RSSI=%d dBm\r\n> ", ( unsigned ) current_op_mode,
                         ( int ) chip_status.chip_mode, ( int ) chip_status.cmd_status, ( int ) rssi );
}

static void p2p_calibrate_image( uint32_t freq_hz )
{
    uint8_t f1, f2;
    if( freq_hz >= 902000000UL )      { f1 = 0xE1; f2 = 0xE9; }
    else if( freq_hz >= 863000000UL ) { f1 = 0xD7; f2 = 0xDB; }
    else if( freq_hz >= 779000000UL ) { f1 = 0xC1; f2 = 0xC5; }
    else if( freq_hz >= 470000000UL ) { f1 = 0x75; f2 = 0x81; }
    else                              { f1 = 0x6B; f2 = 0x6F; }
    P2P_CHECK( sx126x_cal_img( p2p_context, f1, f2 ) );
}

static void p2p_radio_configure( void )
{
    P2P_CHECK( sx126x_reset( p2p_context ) );
    P2P_CHECK( sx126x_wakeup( p2p_context ) );
    P2P_CHECK( sx126x_set_standby( p2p_context, SX126X_STANDBY_CFG_RC ) );

#if( P2P_USE_TCXO == 1 )
    P2P_CHECK( sx126x_set_dio3_as_tcxo_ctrl( p2p_context, P2P_TCXO_VOLTAGE,
                                            ( uint32_t )( ( P2P_TCXO_TIMEOUT_MS * 1000UL ) / 15.625 ) ) );
#endif
#if( P2P_USE_DCDC == 1 )
    P2P_CHECK( sx126x_set_reg_mode( p2p_context, SX126X_REG_MODE_DCDC ) );
#endif
    P2P_CHECK( sx126x_cal( p2p_context, SX126X_CAL_ALL ) );
    P2P_CHECK( sx126x_set_standby( p2p_context, SX126X_STANDBY_CFG_RC ) );

    P2P_CHECK( sx126x_set_dio2_as_rf_sw_ctrl( p2p_context, true ) );

    P2P_CHECK( sx126x_set_pkt_type( p2p_context, SX126X_PKT_TYPE_LORA ) );
    P2P_CHECK( sx126x_set_rf_freq( p2p_context, P2P_FREQUENCY_HZ ) );
    p2p_calibrate_image( P2P_FREQUENCY_HZ );

    sx126x_mod_params_lora_t mod_params;
    mod_params.sf   = ( sx126x_lora_sf_t ) P2P_SPREADING_FACTOR;
    mod_params.bw   = SX126X_LORA_BW_125;
    mod_params.cr   = ( sx126x_lora_cr_t ) P2P_CODING_RATE;
    mod_params.ldro = ( ( mod_params.sf >= SX126X_LORA_SF11 ) && ( mod_params.bw == SX126X_LORA_BW_125 ) ) ? 1 : 0;
    P2P_CHECK( sx126x_set_lora_mod_params( p2p_context, &mod_params ) );

    sx126x_pkt_params_lora_t pkt_params;
    pkt_params.preamble_len_in_symb = P2P_PREAMBLE_LENGTH;
    pkt_params.header_type          = SX126X_LORA_PKT_EXPLICIT;
    pkt_params.pld_len_in_bytes     = 255;
    pkt_params.crc_is_on            = true;
    pkt_params.invert_iq_is_on      = false;
    P2P_CHECK( sx126x_set_lora_pkt_params( p2p_context, &pkt_params ) );

    P2P_CHECK( sx126x_set_lora_sync_word( p2p_context, 0x34 ) );
    P2P_CHECK( sx126x_set_buffer_base_address( p2p_context, 0, 0 ) );
    P2P_CHECK( sx126x_cfg_rx_boosted( p2p_context, true ) );

    sx126x_pa_cfg_params_t pa_cfg = { .pa_duty_cycle = 0x04, .hp_max = 0x07, .device_sel = 0x00, .pa_lut = 0x01 };
    P2P_CHECK( sx126x_set_pa_cfg( p2p_context, &pa_cfg ) );
    P2P_CHECK( sx126x_set_tx_params( p2p_context, P2P_TX_POWER_DBM, SX126X_RAMP_40_US ) );

    const sx126x_irq_mask_t irq_mask = SX126X_IRQ_TX_DONE | SX126X_IRQ_RX_DONE | SX126X_IRQ_TIMEOUT |
                                       SX126X_IRQ_CRC_ERROR | SX126X_IRQ_PREAMBLE_DETECTED |
                                       SX126X_IRQ_HEADER_VALID | SX126X_IRQ_HEADER_ERROR;
    P2P_CHECK( sx126x_set_dio_irq_params( p2p_context, irq_mask, irq_mask, SX126X_IRQ_NONE, SX126X_IRQ_NONE ) );
    P2P_CHECK( sx126x_clear_irq_status( p2p_context, SX126X_IRQ_ALL ) );

    p2p_tx_busy = false;
}

static bool p2p_send_raw( const uint8_t* data, uint8_t len )
{
    if( ( data == NULL ) || ( len == 0 ) )
    {
        return false;
    }
    if( p2p_tx_busy )
    {
        SMTC_HAL_TRACE_INFO( "[P2P TX] Busy, packet dropped\r\n> " );
        return false;
    }

    memcpy( p2p_tx_buffer, data, len );

    sx126x_pkt_params_lora_t pkt_params;
    pkt_params.preamble_len_in_symb = P2P_PREAMBLE_LENGTH;
    pkt_params.header_type          = SX126X_LORA_PKT_EXPLICIT;
    pkt_params.pld_len_in_bytes     = len;
    pkt_params.crc_is_on            = true;
    pkt_params.invert_iq_is_on      = false;
    P2P_CHECK( sx126x_set_lora_pkt_params( p2p_context, &pkt_params ) );

    P2P_ANT_SW_TX( );
    sx126x_clear_irq_status( p2p_context, SX126X_IRQ_ALL );
    P2P_CHECK( sx126x_write_buffer( p2p_context, 0, p2p_tx_buffer, len ) );
    p2p_tx_busy = true;
    if( sx126x_set_tx( p2p_context, 0 ) != SX126X_STATUS_OK )
    {
        SMTC_HAL_TRACE_INFO( "[P2P TX] set_tx FAILED\r\n> " );
        p2p_tx_busy = false;
        return false;
    }
    return true;
}

static void app_apply_mode( uint8_t mode )
{
    current_op_mode  = mode;
    p2p_pong_pending = false;
    if( mode != 2 )
    {
        p2p_pp_master = false;
    }

    if( mode == 2 )
    {
        p2p_start_rx( );
    }
    else
    {
        p2p_standby( );
        app_lp_begin_wake_window( );
    }
    app_announce_mode( mode );
    if( mode == 2 )
    {
        p2p_print_status( );
    }
}

static bool app_tx_text( const char* text )
{
    uint8_t len;
    if( text == NULL ) return false;
    len = ( uint8_t ) strlen( text );
    if( len == 0 ) return false;

    SMTC_HAL_TRACE_INFO( "\r\n[P2P TX] Broadcasting Direct RAW Bytes: '%s'\r\n", text );
    return p2p_send_raw( ( const uint8_t* ) text, len );
}

static bool app_tx_sensor( void )
{
    uint8_t buf[64];
    uint8_t n = ( uint8_t ) P2P_SENSOR_BUILD_PAYLOAD( buf, sizeof( buf ) );
    if( n == 0 )
    {
        return false;
    }
    SMTC_HAL_TRACE_INFO( "[P2P TX] Sensor packet, %u bytes\r\n", ( unsigned ) n );
    return p2p_send_raw( buf, n );
}

static void app_rx_open( void )  { p2p_start_rx( ); }
static void app_rx_close( void ) { p2p_standby( ); }

static void app_radio_sleep( void )
{
    P2P_CHECK( sx126x_set_sleep( p2p_context, SX126X_SLEEP_CFG_COLD_START ) );
}

static void app_radio_wake( void )
{
    p2p_radio_configure( );
}

static bool app_lp_can_sleep( void )
{
    return true;
}

static void app_print_status( void )
{
    p2p_print_status( );
}

static void app_print_rssi( void )
{
    p2p_print_status( );
}

static void app_print_protocol_info( void )
{
    SMTC_HAL_TRACE_INFO( "         Protocol: P2P raw LoRa %lu Hz SF%d\r\n", ( unsigned long ) P2P_FREQUENCY_HZ,
                         ( int ) P2P_SPREADING_FACTOR );
}

static void p2p_handle_rx_packet( const uint8_t* buf, uint8_t len )
{
    const uint32_t now = APP_TIME_MS( );

    if( ( len == 4 ) && ( memcmp( buf, "PING", 4 ) == 0 ) )
    {
        p2p_ping_count++;
        SMTC_HAL_TRACE_INFO( "[PINGPONG] PING #%lu received -> replying PONG\r\n", ( unsigned long ) p2p_ping_count );
        p2p_pong_pending = true;
        p2p_pong_due_ms  = now + P2P_PP_REPLY_DELAY_MS;
    }
    else if( ( len == 4 ) && ( memcmp( buf, "PONG", 4 ) == 0 ) )
    {
        p2p_pong_count++;
        SMTC_HAL_TRACE_INFO( "[PINGPONG] PONG #%lu received\r\n", ( unsigned long ) p2p_pong_count );
        if( p2p_pp_master )
        {
            p2p_next_ping_ms = now + P2P_PP_PERIOD_MS;
        }
    }
}

static bool app_protocol_command( const char* s )
{
    if( app_cmd_is( s, CFG_CMD_PING ) )
    {
        p2p_pp_master    = true;
        p2p_next_ping_ms = APP_TIME_MS( );
        app_apply_mode( 2 );
        p2p_pp_master = true;
        SMTC_HAL_TRACE_INFO( "[PINGPONG] Master started. Type '%s' to end.\r\n> ", CFG_CMD_STOP );
        return true;
    }
    if( app_cmd_is( s, CFG_CMD_STOP ) )
    {
        p2p_pp_master    = false;
        p2p_pong_pending = false;
        SMTC_HAL_TRACE_INFO( "[PINGPONG] Stopped.\r\n> " );
        return true;
    }
    return false;
}

static void p2p_service_radio( void )
{
    sx126x_irq_mask_t irq = 0;

    if( APP_IS_LP_MODE( current_op_mode ) && ( s_lp_state != LP_TX_WAIT ) && ( s_lp_state != LP_RX_WINDOW ) )
    {
        return;
    }

    sx126x_get_irq_status( p2p_context, &irq );
    if( irq == 0 )
    {
        return;
    }

    sx126x_clear_irq_status( p2p_context, irq );

    if( irq & SX126X_IRQ_PREAMBLE_DETECTED ) SMTC_HAL_TRACE_INFO( "[P2P] preamble detected\r\n" );
    if( irq & SX126X_IRQ_HEADER_VALID )      SMTC_HAL_TRACE_INFO( "[P2P] header valid\r\n" );
    if( irq & SX126X_IRQ_HEADER_ERROR )      SMTC_HAL_TRACE_INFO( "[P2P] header error\r\n" );
    if( irq & SX126X_IRQ_CRC_ERROR )         SMTC_HAL_TRACE_INFO( "[P2P] CRC error (packet dropped)\r\n" );

    if( irq & SX126X_IRQ_TX_DONE )
    {
        p2p_tx_busy = false;
        SMTC_HAL_TRACE_INFO( "[P2P TX] Transmission complete.\r\n> " );
        if( current_op_mode == 2 )
        {
            p2p_start_rx( );
        }
        else if( s_lp_state == LP_TX_WAIT )
        {
            app_lp_on_tx_done( );
        }
        else if( s_lp_state == LP_RX_WINDOW )
        {
            p2p_start_rx( );
        }
    }

    if( ( irq & SX126X_IRQ_RX_DONE ) && !( irq & SX126X_IRQ_CRC_ERROR ) )
    {
        uint8_t                   buffer_rx[256] = { 0 };
        sx126x_rx_buffer_status_t rx_buffer_status;
        sx126x_get_rx_buffer_status( p2p_context, &rx_buffer_status );

        if( rx_buffer_status.pld_len_in_bytes > 0 )
        {
            sx126x_read_buffer( p2p_context, rx_buffer_status.buffer_start_pointer, buffer_rx,
                                rx_buffer_status.pld_len_in_bytes );

            sx126x_pkt_status_lora_t pkt_status;
            sx126x_get_lora_pkt_status( p2p_context, &pkt_status );

            buffer_rx[rx_buffer_status.pld_len_in_bytes] = '\0';

            SMTC_HAL_TRACE_INFO( "\r\n\r\n========== DIRECT P2P MESSAGE ==========\r\n" );
            SMTC_HAL_TRACE_INFO( "RSSI: %d dBm | SNR: %d dB | Size: %u bytes\r\n", pkt_status.rssi_pkt_in_dbm,
                                 pkt_status.snr_pkt_in_db, rx_buffer_status.pld_len_in_bytes );
            SMTC_HAL_TRACE_INFO( "Payload: %s\r\n", ( char* ) buffer_rx );
            SMTC_HAL_TRACE_INFO( "==========================================\r\n> " );

            p2p_handle_rx_packet( buffer_rx, ( uint8_t ) rx_buffer_status.pld_len_in_bytes );
        }
    }

    if( ( irq & SX126X_IRQ_TIMEOUT ) && ( current_op_mode == 2 ) )
    {
        p2p_start_rx( );
    }
}

static void p2p_service_pingpong( void )
{
    const uint32_t now = APP_TIME_MS( );

    if( p2p_tx_busy )
    {
        return;
    }

    if( p2p_pong_pending && TIME_REACHED( now, p2p_pong_due_ms ) )
    {
        p2p_pong_pending = false;
        SMTC_HAL_TRACE_INFO( "[PINGPONG] Sending PONG\r\n" );
        p2p_send_raw( ( const uint8_t* ) "PONG", 4 );
        return;
    }

    if( p2p_pp_master && TIME_REACHED( now, p2p_next_ping_ms ) )
    {
        SMTC_HAL_TRACE_INFO( "[PINGPONG] Sending PING\r\n" );
        p2p_send_raw( ( const uint8_t* ) "PING", 4 );
        p2p_next_ping_ms = now + P2P_PP_TIMEOUT_MS;
    }
}

void lora_app_init( void )
{
    eeprom_manager_init( );
    sensor_manager_init( );

    SMTC_HAL_TRACE_INFO( "\r\n=================================================\r\n" );
    SMTC_HAL_TRACE_INFO( "     Smart IoT Terminal (STM32L0 P2P)              \r\n" );
    SMTC_HAL_TRACE_INFO( "=================================================\r\n" );
    SMTC_HAL_TRACE_INFO( "[P2P] freq=%lu Hz | SF%d | BW125 | CR=4/5 | preamble=%d | CRC=ON | IQ=normal | sync=0x34 | pwr=%d dBm\r\n",
                         ( unsigned long ) P2P_FREQUENCY_HZ, ( int ) P2P_SPREADING_FACTOR,
                         ( int ) P2P_PREAMBLE_LENGTH, ( int ) P2P_TX_POWER_DBM );

    p2p_radio_configure( );
    app_periodic_reschedule( );
    app_apply_mode( current_op_mode );
    app_print_help( );
}

void lora_app_set_adr_profile( uint8_t profile ) { ( void ) profile; }
void lora_app_join_network( void ) {}
void lora_app_leave_network( void ) {}
void lora_app_set_class( uint8_t new_class ) { app_apply_mode( ( new_class == 2 ) ? 2 : 0 ); }

void lora_app_send_text( uint8_t fport, const char* text, bool confirmed )
{
    ( void ) fport;
    ( void ) confirmed;
    ( void ) app_tx_text( text );
}

void lora_app_process( void )
{
    uint8_t tx_payload[BSP_UART_RX_BUF_SIZE];
    uint8_t tx_len = 0;

    p2p_service_radio( );
    p2p_service_pingpong( );

    bsp_console_poll( );
    if( bsp_uart_get_line( tx_payload, &tx_len ) )
    {
        if( ( uint32_t ) tx_len >= sizeof( tx_payload ) ) tx_len = ( uint8_t )( sizeof( tx_payload ) - 1 );
        tx_payload[tx_len] = '\0';
        app_dispatch_line( tx_payload, tx_len );
    }

    if( APP_IS_LP_MODE( current_op_mode ) )
    {
        app_lp_service( );
    }

    bsp_watchdog_reload( );
    hal_mcu_wait_us( 200 );
}

void main_periodical_uplink( void )
{
    lora_app_init( );
    while( 1 )
    {
        lora_app_process( );
    }
}

#else

/* ============================================================================
 * --- LORAWAN: UNICAST (default) + MULTICAST + SINGLE-CHANNEL + RUNTIME P2P ---
 * ========================================================================== */

#if( LORA_ACTIVATION_MODE == CUSTOM_ACTIVATION_MODE_ABP )
static uint32_t active_fcnt_up   = 0;
static uint32_t active_fcnt_down = 0;
#endif

extern bool smtc_modem_hal_poll_radio_irq( void );
static void modem_event_callback( void );

#ifndef LORA_PORT_SENSOR_CMD
#define LORA_PORT_SENSOR_CMD LORA_PORT_SENSOR
#endif

static bool     s_network_ready  = false;
static bool     s_multicast_mode = false;   /* false = UNICAST (boot default), true = MULTICAST */
static bool     s_p2p_active     = false;   /* true = raw P2P running instead of LoRaWAN */
static bool     s_dl_valid       = false;
static int16_t  s_dl_rssi        = 0;
static int16_t  s_dl_snr         = 0;
static uint8_t  s_dl_fport       = 0;
static uint32_t s_dl_time_ms     = 0;

/* Runtime P2P spreading factor (change with 'psf <7..12>', BOTH nodes must use the same value) */
static uint8_t  rp2p_sf          = ( uint8_t ) P2P_SPREADING_FACTOR;

/* false until single-channel has been requested (boot default or 'sc on'). While false the region
 * code and the DR profile are never touched, so the stack behaves exactly like the known-good build. */
static bool s_sc_touched = ( APP_DEFAULT_SINGLE_CHANNEL == 1 );

static void app_sync_sc_lock( void )
{
#if( APP_SC_REGION_LOCK == 1 )
    if( !s_sc_touched ) return;
    region_in_865_set_single_channel( s_single_channel );
#endif
}

/* Unicast: the class selected by CUSTOM_DEPLOYMENT_CLASS. Multicast: always Class C. */
static smtc_modem_class_t app_listen_class( void )
{
    if( s_multicast_mode )
    {
        return SMTC_MODEM_CLASS_C;
    }
#if( CUSTOM_DEPLOYMENT_CLASS == 2 )
    return SMTC_MODEM_CLASS_C;
#else
    return SMTC_MODEM_CLASS_A;
#endif
}

/* set_class always fails before the join: only warn once the network is ready */
static void app_set_modem_class( smtc_modem_class_t c )
{
    smtc_modem_return_code_t rc = smtc_modem_set_class( 0, c );
    if( ( rc != SMTC_MODEM_RC_OK ) && s_network_ready )
    {
        SMTC_HAL_TRACE_WARNING( "\r\n[CLASS] set_class(%s) REFUSED by modem, rc=%d\r\n",
                                ( c == SMTC_MODEM_CLASS_C ) ? "C" : "A", ( int ) rc );
    }
}

/* Normal profile: fixed DR5. Single-channel profile: fixed DR0 (SF12/BW125). 1 transmission per uplink. */
static void app_apply_dr_profile( void )
{
    /* The modem rejects ADR-profile changes before the stack has joined. For OTAA,
     * the regional join distribution is forced to DR0 separately in region_in_865.c.
     * Apply the uplink profile only after JOINED / ABP activation. */
    if( !s_network_ready )
    {
        return;
    }

    uint8_t custom_dr[SMTC_MODEM_CUSTOM_ADR_DATA_LENGTH];
    const uint8_t target_dr = s_single_channel ? SC_DR : 5U;
    memset( custom_dr, target_dr, sizeof( custom_dr ) );

    smtc_modem_return_code_t rc =
        smtc_modem_adr_set_profile( 0, SMTC_MODEM_ADR_PROFILE_CUSTOM, custom_dr );
    if( rc != SMTC_MODEM_RC_OK )
    {
        SMTC_HAL_TRACE_WARNING( "\r\n[ADR] Failed to apply custom DR%d profile (rc=%d).\r\n",
                                ( int ) target_dr, ( int ) rc );
        return;
    }

    rc = smtc_modem_set_nb_trans( 0, 1 );
    if( rc != SMTC_MODEM_RC_OK )
    {
        SMTC_HAL_TRACE_WARNING( "\r\n[ADR] Failed to set NbTrans=1 (rc=%d).\r\n", ( int ) rc );
    }
}

void lora_app_set_adr_profile( uint8_t profile )
{
    ( void ) profile;
    app_apply_dr_profile( );
}

/* Re-apply lock + DR profile ONLY when single-channel has been used. Otherwise do nothing (known-good behaviour). */
static void app_sc_refresh( void )
{
    if( s_sc_touched )
    {
        app_sync_sc_lock( );
        app_apply_dr_profile( );
    }
}

/* 'txp' -> show, 'txp <dBm>' -> cap the TX power (negative allowed), 'txp off' -> no cap.
 * Returns true when the line was a txp command. */
static bool app_txp_command( const char* s )
{
    const char* p;

    if( ( app_strncasecmp( s, "txp", 3 ) != 0 ) || ( ( s[3] != '\0' ) && ( s[3] != ' ' ) && ( s[3] != '\t' ) ) )
    {
        return false;
    }

    p = s + 3;
    while( ( *p == ' ' ) || ( *p == '\t' ) ) p++;

    if( *p != '\0' )
    {
        if( app_strncasecmp( p, "off", 3 ) == 0 )
        {
            g_app_tx_pwr_limit_dbm = APP_TX_PWR_LIMIT_NONE;
        }
        else
        {
            int         v;
            const char* d = p;

            if( ( *d == '-' ) || ( *d == '+' ) ) d++;
            if( ( *d < '0' ) || ( *d > '9' ) )
            {
                SMTC_HAL_TRACE_ERROR( "\r\n[TXP] usage: txp <%d..%d> (dBm cap) | txp off\r\n> ", APP_TXP_MIN_DBM, APP_TXP_MAX_DBM );
                return true;
            }
            v = atoi( p );
            if( ( v < APP_TXP_MIN_DBM ) || ( v > APP_TXP_MAX_DBM ) )
            {
                SMTC_HAL_TRACE_ERROR( "\r\n[TXP] value out of range, use %d..%d or 'off'\r\n> ", APP_TXP_MIN_DBM, APP_TXP_MAX_DBM );
                return true;
            }
            g_app_tx_pwr_limit_dbm = ( int8_t ) v;
        }
    }

    if( g_app_tx_pwr_limit_dbm == APP_TX_PWR_LIMIT_NONE )
    {
        SMTC_HAL_TRACE_INFO( "\r\n[TXP] No TX power cap (stack default = full power). Use 'txp <dBm>' e.g. 'txp 14' or 'txp -9'.\r\n> " );
    }
    else
    {
        SMTC_HAL_TRACE_INFO( "\r\n[TXP] TX power capped at %d dBm. 'txp off' removes the cap.\r\n> ", ( int ) g_app_tx_pwr_limit_dbm );
    }
    return true;
}

/* 'sco' -> show, 'sco <Hz>' -> set the radio frequency offset (TX and RX). Returns true when it was an sco command. */
static bool app_sco_command( const char* s )
{
    const char* p;

    if( ( app_strncasecmp( s, "sco", 3 ) != 0 ) || ( ( s[3] != '\0' ) && ( s[3] != ' ' ) && ( s[3] != '\t' ) ) )
    {
        return false;
    }

    p = s + 3;
    while( ( *p == ' ' ) || ( *p == '\t' ) ) p++;

    if( *p != '\0' )
    {
        const char* d = p;
        long        v;

        if( ( *d == '-' ) || ( *d == '+' ) ) d++;
        if( ( *d < '0' ) || ( *d > '9' ) )
        {
            SMTC_HAL_TRACE_ERROR( "\r\n[SCO] usage: sco <-%ld..%ld> (Hz)\r\n> ", APP_SCO_MAX_HZ, APP_SCO_MAX_HZ );
            return true;
        }
        v = strtol( p, NULL, 10 );
        if( ( v < -APP_SCO_MAX_HZ ) || ( v > APP_SCO_MAX_HZ ) )
        {
            SMTC_HAL_TRACE_ERROR( "\r\n[SCO] value out of range, use -%ld..%ld Hz\r\n> ", APP_SCO_MAX_HZ, APP_SCO_MAX_HZ );
            return true;
        }
        g_app_freq_offset_hz = ( int32_t ) v;
    }

    SMTC_HAL_TRACE_INFO( "\r\n[SCO] Radio frequency offset = %ld Hz (applies to the next TX / RX). 'sco 0' = none.\r\n> ",
                         ( long ) g_app_freq_offset_hz );
    return true;
}

static void app_sc_set( bool on )
{
    if( s_p2p_active )
    {
        SMTC_HAL_TRACE_WARNING( "\r\n[SC] Type 'lorawan' first.\r\n> " );
        return;
    }
    if( on && s_multicast_mode )
    {
        SMTC_HAL_TRACE_WARNING( "\r\n[SC] Type 'unicast' first (multicast uses its own frequency).\r\n> " );
        return;
    }

    /* Keep the bench profile self-contained: sc on implies sco 0 and txp 0.
     * These values affect the device radio only; txp does not configure gateway TX. */
    g_app_freq_offset_hz = 0;
    g_app_tx_pwr_limit_dbm = on ? SC_TX_POWER_CAP_DBM : APP_TX_PWR_LIMIT_NONE;

    if( s_single_channel == on )
    {
        app_sync_sc_lock( );
        app_apply_dr_profile( );
        SMTC_HAL_TRACE_INFO( "\r\n[SC] Single-channel profile is already %s (%lu Hz, SF12/BW125, DR%d).\r\n> ",
                             on ? "ON" : "OFF", ( unsigned long ) SC_FREQ_HZ, SC_DR );
        return;
    }

    s_single_channel = on;
    if( on ) s_sc_touched = true;

    app_sync_sc_lock( );
    app_apply_dr_profile( );

    if( on )
    {
        SMTC_HAL_TRACE_INFO( "\r\n[SC] >>> SINGLE-CHANNEL profile ON: %lu Hz, SF12/BW125 (DR%d), max payload %d bytes.\r\n",
                             ( unsigned long ) SC_FREQ_HZ, SC_DR, SC_MAX_PAYLOAD );
#if( APP_SC_REGION_LOCK == 1 )
        SMTC_HAL_TRACE_INFO( "[SC] Channel-0 lock applied (%lu Hz, DR%d). Disable ADR on the server.\r\n",
                             ( unsigned long ) SC_FREQ_HZ, SC_DR );
#else
        SMTC_HAL_TRACE_INFO( "[SC] Channel lock NOT compiled in: the stack may still hop channels.\r\n" );
#endif
        SMTC_HAL_TRACE_INFO( "[SC] Gateway shows IRQ_CRC_ERROR? Try 'txp -9' with the node 3+ m away, then sweep 'sco 3000', 'sco -3000', 'sco 6000' ...\r\n> " );
    }
    else
    {
        SMTC_HAL_TRACE_INFO( "\r\n[SC] >>> Normal multi-channel profile (DR5).\r\n> " );
    }
}

static void app_print_protocol_info( void )
{
    if( s_p2p_active )
    {
        SMTC_HAL_TRACE_INFO( "         Protocol: P2P raw LoRa %ld Hz SF%u\r\n",
                             ( long ) ( ( int32_t ) P2P_FREQUENCY_HZ + g_app_freq_offset_hz ), ( unsigned ) rp2p_sf );
        return;
    }
    SMTC_HAL_TRACE_INFO( "         Protocol: LoRaWAN | cast: %s | profile: %s | selected class: %s | active: %s\r\n",
                         s_multicast_mode ? "MULTICAST" : "UNICAST",
                         s_single_channel ? "SINGLE-CHANNEL (SF12)" : "multi-channel",
                         ( CUSTOM_DEPLOYMENT_CLASS == 2 ) ? "Class C" : "Class A",
                         ( app_listen_class( ) == SMTC_MODEM_CLASS_C ) ? "Class C" : "Class A" );
}

/* ============================================================================
 * --- RUNTIME RAW P2P (commands: p2p / lorawan) ---
 * Hard-resets the radio chip and follows the known-good compile-time P2P sequence exactly.
 * Because the reset wipes the modem's radio set-up, 'lorawan' reboots the MCU.
 * ========================================================================== */
/* Match the known-good compile-time P2P RF-switch handling.
 * Boards with an external RF switch may override these macros in their headers. */
#ifndef P2P_ANT_SW_RX
#define P2P_ANT_SW_RX( )
#endif
#ifndef P2P_ANT_SW_TX
#define P2P_ANT_SW_TX( )
#endif

#define RP2P_PP_REPLY_DELAY_MS 100U
#define RP2P_PP_PERIOD_MS      1000U
#define RP2P_PP_TIMEOUT_MS     3000U

#define RP2P_CHECK( call )                                                         \
    do                                                                             \
    {                                                                              \
        sx126x_status_t st_ = ( call );                                            \
        if( st_ != SX126X_STATUS_OK )                                              \
        {                                                                          \
            SMTC_HAL_TRACE_INFO( "[P2P] " #call " FAILED (status %d)\r\n", st_ );  \
        }                                                                          \
    } while( 0 )

static void*         rp2p_ctx = NULL;
static uint8_t       rp2p_tx_buf[255];
static volatile bool rp2p_tx_busy      = false;
static bool          rp2p_pp_master    = false;
static uint32_t      rp2p_next_ping_ms = 0;
static bool          rp2p_pong_pending = false;
static uint32_t      rp2p_pong_due_ms  = 0;
static uint32_t      rp2p_ping_count   = 0;
static uint32_t      rp2p_pong_count   = 0;
static uint32_t      rp2p_rx_ok_count  = 0;
static uint32_t      rp2p_rx_crc_count = 0;

/* Frequency actually programmed: nominal + 'sco' offset */
static uint32_t rp2p_freq_hz( void )
{
    return ( uint32_t ) ( ( int32_t ) P2P_FREQUENCY_HZ + g_app_freq_offset_hz );
}

/* Power actually programmed: P2P_TX_POWER_DBM, lowered by the 'txp' cap if set */
static int8_t rp2p_tx_power_dbm( void )
{
    int8_t p = ( int8_t ) P2P_TX_POWER_DBM;
    if( ( g_app_tx_pwr_limit_dbm != APP_TX_PWR_LIMIT_NONE ) && ( g_app_tx_pwr_limit_dbm < p ) )
    {
        p = g_app_tx_pwr_limit_dbm;
    }
    return p;
}

static void rp2p_start_rx( void )
{
    /* Put the external RF path in RX before enabling the receiver. */
    P2P_ANT_SW_RX( );
    RP2P_CHECK( sx126x_clear_irq_status( rp2p_ctx, SX126X_IRQ_ALL ) );
    RP2P_CHECK( sx126x_set_rx_with_timeout_in_rtc_step( rp2p_ctx, SX126X_RX_CONTINUOUS ) );
}

static void rp2p_standby( void )
{
    RP2P_CHECK( sx126x_set_standby( rp2p_ctx, SX126X_STANDBY_CFG_RC ) );
}

static void rp2p_print_status( void )
{
    sx126x_chip_status_t chip_status;
    int16_t              rssi = 0;

    sx126x_get_status( rp2p_ctx, &chip_status );
    sx126x_get_rssi_inst( rp2p_ctx, &rssi );
    SMTC_HAL_TRACE_INFO( "\r\n[P2P] mode=%u chip_mode=%d cmd_status=%d inst_RSSI=%d dBm\r\n", ( unsigned ) current_op_mode,
                         ( int ) chip_status.chip_mode, ( int ) chip_status.cmd_status, ( int ) rssi );
    SMTC_HAL_TRACE_INFO( "[P2P] freq=%lu Hz (offset %ld) | SF%u | BW125 | CR=4/5 | preamble=%u | CRC=ON | IQ=normal | sync=0x34 | pwr=%d dBm\r\n",
                         ( unsigned long ) rp2p_freq_hz( ), ( long ) g_app_freq_offset_hz, ( unsigned ) rp2p_sf,
                         ( unsigned ) P2P_PREAMBLE_LENGTH, ( int ) rp2p_tx_power_dbm( ) );
    SMTC_HAL_TRACE_INFO( "[P2P] rx_ok=%lu crc_err=%lu\r\n> ",
                         ( unsigned long ) rp2p_rx_ok_count, ( unsigned long ) rp2p_rx_crc_count );
}

static void rp2p_calibrate_image( uint32_t freq_hz )
{
    uint8_t f1, f2;
    if( freq_hz >= 902000000UL )      { f1 = 0xE1; f2 = 0xE9; }
    else if( freq_hz >= 863000000UL ) { f1 = 0xD7; f2 = 0xDB; }
    else if( freq_hz >= 779000000UL ) { f1 = 0xC1; f2 = 0xC5; }
    else if( freq_hz >= 470000000UL ) { f1 = 0x75; f2 = 0x81; }
    else                              { f1 = 0x6B; f2 = 0x6F; }
    RP2P_CHECK( sx126x_cal_img( rp2p_ctx, f1, f2 ) );
}

static void rp2p_configure( void )
{
    /* IDENTICAL to the known-good compile-time P2P build: hard reset first, so no register left over
     * from the LoRaWAN modem (TCXO/DC-DC/IQ/timeouts/...) can survive. After this the chip is in the
     * same state as in a pure P2P firmware. Leaving P2P therefore reboots the MCU (see rp2p_exit). */
    RP2P_CHECK( sx126x_reset( rp2p_ctx ) );
    RP2P_CHECK( sx126x_wakeup( rp2p_ctx ) );
    RP2P_CHECK( sx126x_set_standby( rp2p_ctx, SX126X_STANDBY_CFG_RC ) );

#if( P2P_USE_TCXO == 1 )
    RP2P_CHECK( sx126x_set_dio3_as_tcxo_ctrl( rp2p_ctx, P2P_TCXO_VOLTAGE,
                                             ( uint32_t ) ( ( P2P_TCXO_TIMEOUT_MS * 1000UL ) / 15.625 ) ) );
#endif
#if( P2P_USE_DCDC == 1 )
    RP2P_CHECK( sx126x_set_reg_mode( rp2p_ctx, SX126X_REG_MODE_DCDC ) );
#endif
    /* Full calibration (RC64k, RC13M, PLL, ADC, image): the modem may have left the chip in a
     * state that was calibrated for a different set-up. */
    RP2P_CHECK( sx126x_cal( rp2p_ctx, SX126X_CAL_ALL ) );
    RP2P_CHECK( sx126x_set_standby( rp2p_ctx, SX126X_STANDBY_CFG_RC ) );

    RP2P_CHECK( sx126x_set_dio2_as_rf_sw_ctrl( rp2p_ctx, true ) );

    RP2P_CHECK( sx126x_set_pkt_type( rp2p_ctx, SX126X_PKT_TYPE_LORA ) );
    RP2P_CHECK( sx126x_set_rf_freq( rp2p_ctx, rp2p_freq_hz( ) ) );
    rp2p_calibrate_image( rp2p_freq_hz( ) );

    sx126x_mod_params_lora_t mod;
    mod.sf   = ( sx126x_lora_sf_t ) rp2p_sf;
    mod.bw   = SX126X_LORA_BW_125;
    mod.cr   = ( sx126x_lora_cr_t ) P2P_CODING_RATE;
    mod.ldro = ( ( mod.sf >= SX126X_LORA_SF11 ) && ( mod.bw == SX126X_LORA_BW_125 ) ) ? 1 : 0;
    RP2P_CHECK( sx126x_set_lora_mod_params( rp2p_ctx, &mod ) );

    sx126x_pkt_params_lora_t pkt;
    pkt.preamble_len_in_symb = P2P_PREAMBLE_LENGTH;
    pkt.header_type          = SX126X_LORA_PKT_EXPLICIT;
    pkt.pld_len_in_bytes     = 255;
    pkt.crc_is_on            = true;
    pkt.invert_iq_is_on      = false;
    RP2P_CHECK( sx126x_set_lora_pkt_params( rp2p_ctx, &pkt ) );

    RP2P_CHECK( sx126x_set_lora_sync_word( rp2p_ctx, 0x34 ) );
    RP2P_CHECK( sx126x_set_buffer_base_address( rp2p_ctx, 0, 0 ) );
    RP2P_CHECK( sx126x_cfg_rx_boosted( rp2p_ctx, true ) );

    sx126x_pa_cfg_params_t pa = { .pa_duty_cycle = 0x04, .hp_max = 0x07, .device_sel = 0x00, .pa_lut = 0x01 };
    RP2P_CHECK( sx126x_set_pa_cfg( rp2p_ctx, &pa ) );
    RP2P_CHECK( sx126x_set_tx_params( rp2p_ctx, rp2p_tx_power_dbm( ), SX126X_RAMP_40_US ) );

    const sx126x_irq_mask_t m = SX126X_IRQ_TX_DONE | SX126X_IRQ_RX_DONE | SX126X_IRQ_TIMEOUT | SX126X_IRQ_CRC_ERROR |
                                SX126X_IRQ_PREAMBLE_DETECTED | SX126X_IRQ_HEADER_VALID | SX126X_IRQ_HEADER_ERROR;
    RP2P_CHECK( sx126x_set_dio_irq_params( rp2p_ctx, m, m, SX126X_IRQ_NONE, SX126X_IRQ_NONE ) );
    RP2P_CHECK( sx126x_clear_irq_status( rp2p_ctx, SX126X_IRQ_ALL ) );
    rp2p_tx_busy = false;
}

/* Re-apply frequency (+offset) and TX power after 'sco' / 'txp' while in P2P */
static void rp2p_refresh_rf( void )
{
    if( !s_p2p_active || rp2p_tx_busy ) return;

    rp2p_standby( );
    RP2P_CHECK( sx126x_set_rf_freq( rp2p_ctx, rp2p_freq_hz( ) ) );
    rp2p_calibrate_image( rp2p_freq_hz( ) );
    RP2P_CHECK( sx126x_set_tx_params( rp2p_ctx, rp2p_tx_power_dbm( ), SX126X_RAMP_40_US ) );
    if( current_op_mode == 2 ) rp2p_start_rx( );
}

/* 'psf' -> show, 'psf <7..12>' -> set the spreading factor. Only meaningful in P2P. */
static bool rp2p_sf_command( const char* s )
{
    const char* p;

    if( ( app_strncasecmp( s, "psf", 3 ) != 0 ) || ( ( s[3] != '\0' ) && ( s[3] != ' ' ) && ( s[3] != '\t' ) ) )
    {
        return false;
    }

    p = s + 3;
    while( ( *p == ' ' ) || ( *p == '\t' ) ) p++;

    if( *p != '\0' )
    {
        int v = atoi( p );
        if( ( v < 7 ) || ( v > 12 ) || ( *p < '0' ) || ( *p > '9' ) )
        {
            SMTC_HAL_TRACE_ERROR( "\r\n[PSF] usage: psf <7..12>\r\n> " );
            return true;
        }
        if( rp2p_tx_busy )
        {
            SMTC_HAL_TRACE_WARNING( "\r\n[PSF] TX busy, try again.\r\n> " );
            return true;
        }
        rp2p_sf = ( uint8_t ) v;
        rp2p_configure( );
        if( current_op_mode == 2 ) rp2p_start_rx( );
    }
    SMTC_HAL_TRACE_INFO( "\r\n[PSF] P2P spreading factor = SF%u (both nodes must match)\r\n> ", ( unsigned ) rp2p_sf );
    return true;
}

static bool rp2p_send_raw( const uint8_t* data, uint8_t len )
{
    if( ( data == NULL ) || ( len == 0 ) ) return false;
    if( rp2p_tx_busy )
    {
        SMTC_HAL_TRACE_INFO( "[P2P TX] Busy, packet dropped\r\n> " );
        return false;
    }
    memcpy( rp2p_tx_buf, data, len );

    sx126x_pkt_params_lora_t pkt;
    pkt.preamble_len_in_symb = P2P_PREAMBLE_LENGTH;
    pkt.header_type          = SX126X_LORA_PKT_EXPLICIT;
    pkt.pld_len_in_bytes     = len;
    pkt.crc_is_on            = true;
    pkt.invert_iq_is_on      = false;
    RP2P_CHECK( sx126x_set_lora_pkt_params( rp2p_ctx, &pkt ) );

    /* Match the known-good P2P path: switch antenna before loading/starting TX. */
    P2P_ANT_SW_TX( );
    RP2P_CHECK( sx126x_clear_irq_status( rp2p_ctx, SX126X_IRQ_ALL ) );
    RP2P_CHECK( sx126x_write_buffer( rp2p_ctx, 0, rp2p_tx_buf, len ) );
    rp2p_tx_busy = true;
    if( sx126x_set_tx( rp2p_ctx, 0 ) != SX126X_STATUS_OK )
    {
        SMTC_HAL_TRACE_INFO( "[P2P TX] set_tx FAILED\r\n> " );
        rp2p_tx_busy = false;
        return false;
    }
    return true;
}

static bool rp2p_tx_text( const char* text )
{
    if( ( text == NULL ) || ( strlen( text ) == 0 ) ) return false;
    SMTC_HAL_TRACE_INFO( "\r\n[P2P TX] Broadcasting RAW bytes: '%s'\r\n", text );
    return rp2p_send_raw( ( const uint8_t* ) text, ( uint8_t ) strlen( text ) );
}

static void rp2p_apply_mode( uint8_t mode )
{
    current_op_mode   = mode;
    rp2p_pong_pending = false;
    if( mode != 2 ) rp2p_pp_master = false;

    if( mode == 2 ) { rp2p_start_rx( ); }
    else            { rp2p_standby( ); app_lp_begin_wake_window( ); }

    app_announce_mode( mode );
    if( mode == 2 ) rp2p_print_status( );
}

static void rp2p_on_rx_packet( const uint8_t* buf, uint8_t len )
{
    const uint32_t now = APP_TIME_MS( );

    if( ( len == 4 ) && ( memcmp( buf, "PING", 4 ) == 0 ) )
    {
        rp2p_ping_count++;
        SMTC_HAL_TRACE_INFO( "[PINGPONG] PING #%lu received -> replying PONG\r\n", ( unsigned long ) rp2p_ping_count );
        rp2p_pong_pending = true;
        rp2p_pong_due_ms  = now + RP2P_PP_REPLY_DELAY_MS;
    }
    else if( ( len == 4 ) && ( memcmp( buf, "PONG", 4 ) == 0 ) )
    {
        rp2p_pong_count++;
        SMTC_HAL_TRACE_INFO( "[PINGPONG] PONG #%lu received\r\n", ( unsigned long ) rp2p_pong_count );
        if( rp2p_pp_master ) rp2p_next_ping_ms = now + RP2P_PP_PERIOD_MS;
    }
}

static void rp2p_service_radio( void )
{
    sx126x_irq_mask_t irq = 0;

    if( APP_IS_LP_MODE( current_op_mode ) && ( s_lp_state != LP_TX_WAIT ) && ( s_lp_state != LP_RX_WINDOW ) ) return;

    sx126x_get_irq_status( rp2p_ctx, &irq );
    if( irq == 0 ) return;
    sx126x_clear_irq_status( rp2p_ctx, irq );

    if( irq & SX126X_IRQ_CRC_ERROR )
    {
        rp2p_rx_crc_count++;
        SMTC_HAL_TRACE_INFO( "[P2P] CRC error (packet dropped)\r\n" );
    }

    if( irq & SX126X_IRQ_TX_DONE )
    {
        rp2p_tx_busy = false;
        SMTC_HAL_TRACE_INFO( "[P2P TX] Transmission complete.\r\n> " );
        if( current_op_mode == 2 )            rp2p_start_rx( );
        else if( s_lp_state == LP_TX_WAIT )   app_lp_on_tx_done( );
        else if( s_lp_state == LP_RX_WINDOW ) rp2p_start_rx( );
    }

    if( ( irq & SX126X_IRQ_RX_DONE ) && !( irq & SX126X_IRQ_CRC_ERROR ) )
    {
        uint8_t                   rx[256] = { 0 };
        sx126x_rx_buffer_status_t bs;
        sx126x_get_rx_buffer_status( rp2p_ctx, &bs );

        if( bs.pld_len_in_bytes > 0 )
        {
            sx126x_read_buffer( rp2p_ctx, bs.buffer_start_pointer, rx, bs.pld_len_in_bytes );
            sx126x_pkt_status_lora_t ps;
            sx126x_get_lora_pkt_status( rp2p_ctx, &ps );
            rx[bs.pld_len_in_bytes] = '\0';
            rp2p_rx_ok_count++;

            SMTC_HAL_TRACE_INFO( "\r\n\r\n========== DIRECT P2P MESSAGE ==========\r\n" );
            SMTC_HAL_TRACE_INFO( "RSSI: %d dBm | SNR: %d dB | Size: %u bytes\r\n", ps.rssi_pkt_in_dbm, ps.snr_pkt_in_db,
                                 bs.pld_len_in_bytes );
            SMTC_HAL_TRACE_INFO( "Payload: %s\r\n", ( char* ) rx );
            SMTC_HAL_TRACE_INFO( "==========================================\r\n> " );
            rp2p_on_rx_packet( rx, ( uint8_t ) bs.pld_len_in_bytes );
        }
    }

    if( ( irq & SX126X_IRQ_TIMEOUT ) && ( current_op_mode == 2 ) ) rp2p_start_rx( );
}

static void rp2p_service_pingpong( void )
{
    const uint32_t now = APP_TIME_MS( );
    if( rp2p_tx_busy ) return;

    if( rp2p_pong_pending && TIME_REACHED( now, rp2p_pong_due_ms ) )
    {
        rp2p_pong_pending = false;
        SMTC_HAL_TRACE_INFO( "[PINGPONG] Sending PONG\r\n" );
        rp2p_send_raw( ( const uint8_t* ) "PONG", 4 );
        return;
    }
    if( rp2p_pp_master && TIME_REACHED( now, rp2p_next_ping_ms ) )
    {
        SMTC_HAL_TRACE_INFO( "[PINGPONG] Sending PING\r\n" );
        rp2p_send_raw( ( const uint8_t* ) "PING", 4 );
        rp2p_next_ping_ms = now + RP2P_PP_TIMEOUT_MS;
    }
}

static void rp2p_enter( void )
{
    if( s_p2p_active )
    {
        SMTC_HAL_TRACE_INFO( "\r\n[P2P] Already in P2P mode.\r\n> " );
        return;
    }
    if( s_multicast_mode )
    {
        SMTC_HAL_TRACE_WARNING( "\r\n[P2P] Type 'unicast' first.\r\n> " );
        return;
    }
    SMTC_HAL_TRACE_INFO( "\r\n[P2P] >>> Switching to raw P2P (LoRaWAN modem suspended)...\r\n" );
    ( void ) smtc_modem_suspend_radio_communications( true );
    hal_mcu_wait_us( 100000 );   /* let the modem release the radio */

    rp2p_configure( );
    rp2p_rx_ok_count  = 0;
    rp2p_rx_crc_count = 0;
    s_p2p_active      = true;
    rp2p_pp_master    = false;
    rp2p_pong_pending = false;
    rp2p_apply_mode( current_op_mode );
    SMTC_HAL_TRACE_INFO( "[P2P] Type 'lorawan' to go back. 'ping' / 'stop' = ping-pong test. 'sco' / 'txp' / 'psf' = tuning.\r\n> " );
}

static void rp2p_exit( void )
{
    if( !s_p2p_active )
    {
        SMTC_HAL_TRACE_INFO( "\r\n[LORAWAN] Already in LoRaWAN mode.\r\n> " );
        return;
    }
    /* The P2P set-up hard-reset the radio chip, which wiped the modem's TCXO / regulator / RF set-up.
     * The only safe way back is a clean MCU reboot (the modem re-initialises the radio at boot). */
    rp2p_standby( );
    s_p2p_active   = false;
    rp2p_pp_master = false;

    SMTC_HAL_TRACE_INFO( "\r\n[LORAWAN] >>> Rebooting to restore LoRaWAN...\r\n" );
    hal_mcu_wait_us( 200000 );
    NVIC_SystemReset( );
}

#if( APP_ENABLE_MULTICAST == 1 )
/* ============================================================================
 * --- MULTICAST (LoRaWAN Remote Multicast Setup Specification v1.0.0) ---
 *
 *  - Key derivation (1.0.x scheme, root = GenAppKey stored in EEPROM)
 *  - Groups persisted in EEPROM and pushed to the modem when multicast mode starts
 *  - Port 200 commands (only handled in multicast mode): PackageVersion, GroupStatus,
 *    GroupSetup, GroupDelete, ClassCSession, ClassBSession (answered: unsupported)
 *  - Manual provisioning through the "mc ..." serial commands
 * ========================================================================== */

#define MC_MAX_GROUPS        4
#define MC_FLAG_DEFINED      0x00000001UL
#define MC_ANS_MAX           48

#define MC_PKG_VERSION_REQ       0x00
#define MC_GROUP_STATUS_REQ      0x01
#define MC_GROUP_SETUP_REQ       0x02
#define MC_GROUP_DELETE_REQ      0x03
#define MC_CLASS_C_SESSION_REQ   0x04
#define MC_CLASS_B_SESSION_REQ   0x05

typedef struct
{                           /* 48 bytes per group -> 192 bytes, stored in EEPROM as-is */
    uint32_t flags;
    uint32_t mc_addr;
    uint32_t min_fcnt;
    uint32_t max_fcnt;
    uint8_t  nwk_s_key[16];
    uint8_t  app_s_key[16];
} mc_group_t;

typedef struct
{
    bool     armed;         /* waiting for SessionTime */
    bool     running;       /* session started on the modem */
    bool     has_end;
    uint32_t start_ms;
    uint32_t end_ms;
    uint32_t freq_hz;
    uint32_t timeout_s;
    uint8_t  dr;
} mc_session_t;

static mc_group_t   mc_groups[MC_MAX_GROUPS];
static mc_session_t mc_sess[MC_MAX_GROUPS];
static uint8_t      s_active_gen_app_key[16];

#define mc_key_is_zero app_key_is_zero

static bool mc_is_defined( uint8_t g ) { return ( mc_groups[g].flags & MC_FLAG_DEFINED ) != 0U; }

static uint32_t rd_u32_le( const uint8_t* p )
{
    return ( uint32_t ) p[0] | ( ( uint32_t ) p[1] << 8 ) | ( ( uint32_t ) p[2] << 16 ) | ( ( uint32_t ) p[3] << 24 );
}

static uint32_t rd_u24_le( const uint8_t* p )
{
    return ( uint32_t ) p[0] | ( ( uint32_t ) p[1] << 8 ) | ( ( uint32_t ) p[2] << 16 );
}

static uint8_t mc_defined_count( void )
{
    uint8_t n = 0;
    for( uint8_t g = 0; g < MC_MAX_GROUPS; g++ )
        if( mc_is_defined( g ) ) n++;
    return n;
}

static bool mc_session_running( void )
{
    for( uint8_t g = 0; g < MC_MAX_GROUPS; g++ )
        if( mc_sess[g].running ) return true;
    return false;
}

static bool mc_session_active( void )   /* armed or running */
{
    for( uint8_t g = 0; g < MC_MAX_GROUPS; g++ )
        if( mc_sess[g].armed || mc_sess[g].running ) return true;
    return false;
}

#if( APP_MC_SHOW_KEYS == 1 )
static void mc_print_hex( const char* label, const uint8_t* d, uint8_t n )
{
    static const char hx[] = "0123456789abcdef";
    char              s[33];
    uint8_t           k = 0;

    for( uint8_t i = 0; ( i < n ) && ( k < 32U ); i++ )
    {
        s[k++] = hx[d[i] >> 4];
        s[k++] = hx[d[i] & 0x0F];
    }
    s[k] = '\0';
    SMTC_HAL_TRACE_INFO( "     %s: %s\r\n", label, s );
}
#endif

/* ---- crypto: AES-128 ECB through the Secure Element ----
 * The SE can only encrypt with keys stored in its slots, so the key is loaded into a scratch slot
 * first. If the modem's own multicast handling (SMTC_MULTICAST) uses SMTC_SE_MC_KE_KEY, pick another slot. */
#define MC_SE_SCRATCH_SLOT SMTC_SE_MC_KE_KEY

static bool mc_aes_ecb( const uint8_t key[16], const uint8_t in[16], uint8_t out[16] )
{
    static const uint8_t zero_key[16] = { 0 };
    bool                 ok;

    ok = ( smtc_secure_element_set_key( MC_SE_SCRATCH_SLOT, key, 0 ) == SMTC_SE_RC_SUCCESS );
    ok = ok && ( smtc_secure_element_aes_encrypt( in, 16, MC_SE_SCRATCH_SLOT, out, 0 ) == SMTC_SE_RC_SUCCESS );

    ( void ) smtc_secure_element_set_key( MC_SE_SCRATCH_SLOT, zero_key, 0 );   /* don't leave key material behind */
    return ok;
}

static bool mc_derive_session_keys( uint32_t mc_addr, const uint8_t mc_key_enc[16], uint8_t out_app[16],
                                    uint8_t out_nwk[16] )
{
    uint8_t blk[16] = { 0 }, root[16], ke[16], mckey[16];
    bool    ok;

    /* Over-the-air setup needs the per-device GenAppKey. Refuse instead of deriving wrong keys silently. */
    if( mc_key_is_zero( s_active_gen_app_key ) )
    {
        SMTC_HAL_TRACE_ERROR( "[MC] GenAppKey not set: use '*CFG# GENAPPKEY 16 <32 hex>' then reboot\r\n" );
        return false;
    }

    ok = mc_aes_ecb( s_active_gen_app_key, blk, root );   /* McRootKey = aes128(GenAppKey, 0x00|pad16) */
    ok = ok && mc_aes_ecb( root, blk, ke );               /* McKEKey   = aes128(McRootKey, 0x00|pad16) */
    ok = ok && mc_aes_ecb( ke, mc_key_enc, mckey );       /* McKey     = aes128(McKEKey, McKey_encrypted) */

    memset( blk, 0, 16 );
    blk[0] = 0x01;
    blk[1] = ( uint8_t ) ( mc_addr );
    blk[2] = ( uint8_t ) ( mc_addr >> 8 );
    blk[3] = ( uint8_t ) ( mc_addr >> 16 );
    blk[4] = ( uint8_t ) ( mc_addr >> 24 );
    ok = ok && mc_aes_ecb( mckey, blk, out_app );         /* McAppSKey */
    blk[0] = 0x02;
    ok = ok && mc_aes_ecb( mckey, blk, out_nwk );         /* McNwkSKey */

    memset( root, 0, 16 );
    memset( ke, 0, 16 );
    memset( mckey, 0, 16 );
    return ok;
}

/* ---- persistence + modem push ---- */
static bool mc_save( void )
{
    return eeprom_manager_save_multicast( ( const uint8_t* ) mc_groups, sizeof( mc_groups ) );
}

static void mc_load_from_eeprom( void )   /* RAM only: safe to call before smtc_modem_init() */
{
    if( !eeprom_manager_load_multicast( ( uint8_t* ) mc_groups, sizeof( mc_groups ) ) )
    {
        memset( mc_groups, 0, sizeof( mc_groups ) );
        return;
    }
    /* Sanitise: erased EEPROM reads 0xFF.. and would otherwise look like 4 "defined" groups with garbage keys. */
    for( uint8_t g = 0; g < MC_MAX_GROUPS; g++ )
    {
        if( mc_groups[g].flags != MC_FLAG_DEFINED )
        {
            memset( &mc_groups[g], 0, sizeof( mc_groups[g] ) );
        }
    }
}

static bool mc_push( uint8_t g )
{
    smtc_modem_return_code_t rc = smtc_modem_multicast_set_grp_config(
        0, ( smtc_modem_mc_grp_id_t ) g, mc_groups[g].mc_addr, mc_groups[g].nwk_s_key, mc_groups[g].app_s_key );
    if( rc != SMTC_MODEM_RC_OK )
    {
        SMTC_HAL_TRACE_ERROR( "[MC] set_grp_config(G%u) rc=%d (is SMTC_MULTICAST defined?)\r\n", ( unsigned ) g, ( int ) rc );
    }
    return ( rc == SMTC_MODEM_RC_OK );
}

static void lora_multicast_push_all( void )
{
    for( uint8_t g = 0; g < MC_MAX_GROUPS; g++ )
    {
        if( mc_is_defined( g ) && mc_push( g ) )
        {
            SMTC_HAL_TRACE_INFO( "[MC] Loaded G%u addr 0x%08lX into the modem\r\n", ( unsigned ) g,
                                 ( unsigned long ) mc_groups[g].mc_addr );
        }
    }
}

/* ---- sessions ---- */
static void mc_stop_session( uint8_t g )
{
    bool was_running = mc_sess[g].running;

    if( was_running )
    {
        ( void ) smtc_modem_multicast_class_c_stop_session( 0, ( smtc_modem_mc_grp_id_t ) g );
        SMTC_HAL_TRACE_INFO( "[MC] Class C session stopped, G%u\r\n", ( unsigned ) g );
    }
    memset( &mc_sess[g], 0, sizeof( mc_sess[g] ) );

    if( was_running && !mc_session_running( ) )
    {
        app_set_modem_class( app_listen_class( ) );
    }
}

static bool mc_start_now( uint8_t g, uint32_t freq_hz, uint8_t dr, uint32_t timeout_s )
{
    if( !s_multicast_mode )
    {
        SMTC_HAL_TRACE_ERROR( "[MC] Not in multicast mode - type 'multicast' first\r\n" );
        return false;
    }

    app_set_modem_class( SMTC_MODEM_CLASS_C );

    smtc_modem_return_code_t rc = smtc_modem_multicast_class_c_start_session( 0, ( smtc_modem_mc_grp_id_t ) g, freq_hz, dr );
    if( rc != SMTC_MODEM_RC_OK )
    {
        SMTC_HAL_TRACE_ERROR( "[MC] start_session G%u rc=%d\r\n", ( unsigned ) g, ( int ) rc );
        return false;
    }
    mc_sess[g].armed   = false;
    mc_sess[g].running = true;
    mc_sess[g].has_end = ( timeout_s != 0U );
    mc_sess[g].end_ms  = APP_TIME_MS( ) + timeout_s * 1000UL;
    SMTC_HAL_TRACE_INFO( "[MC] Class C session ACTIVE G%u %lu Hz DR%u timeout %lu s\r\n", ( unsigned ) g,
                         ( unsigned long ) freq_hz, ( unsigned ) dr, ( unsigned long ) timeout_s );
    return true;
}

static void lora_multicast_service( void )   /* called from lora_app_process() in multicast mode only */
{
    const uint32_t now = APP_TIME_MS( );

    for( uint8_t g = 0; g < MC_MAX_GROUPS; g++ )
    {
        if( mc_sess[g].armed && TIME_REACHED( now, mc_sess[g].start_ms ) )
        {
            if( !mc_start_now( g, mc_sess[g].freq_hz, mc_sess[g].dr, mc_sess[g].timeout_s ) )
            {
                memset( &mc_sess[g], 0, sizeof( mc_sess[g] ) );
            }
        }
        if( mc_sess[g].running && mc_sess[g].has_end && TIME_REACHED( now, mc_sess[g].end_ms ) )
        {
            mc_stop_session( g );
        }
    }
}

static bool mc_gps_now( uint32_t* gps_s )
{
    uint32_t frac = 0;
    if( smtc_modem_get_lorawan_mac_time( 0, gps_s, &frac ) == SMTC_MODEM_RC_OK ) return true;
#if defined( ADD_SMTC_ALC_SYNC )
    if( smtc_modem_get_alcsync_time( 0, gps_s ) == SMTC_MODEM_RC_OK ) return true;
#endif
    return false;
}

static void mc_forget_group( uint8_t g )
{
    static const uint8_t zero_key[16] = { 0 };

    mc_stop_session( g );
    memset( &mc_groups[g], 0, sizeof( mc_groups[g] ) );
    /* No "remove group" API in this LBM build: blank the group in the modem (best effort).
     * The EEPROM copy is the source of truth, so the group is gone after the next boot anyway. */
    ( void ) smtc_modem_multicast_set_grp_config( 0, ( smtc_modem_mc_grp_id_t ) g, 0, zero_key, zero_key );
}

/* ---- port 200: Remote Multicast Setup v1.0.0 ---- */
static void lora_multicast_process_downlink( const uint8_t* p, uint8_t size )
{
    uint8_t tx[MC_ANS_MAX];
    uint8_t n = 0;
    uint8_t i = 0;

    while( i < size )
    {
        const uint8_t left = ( uint8_t ) ( size - i );

        switch( p[i] )
        {
        case MC_PKG_VERSION_REQ:
            if( ( n + 3 ) > MC_ANS_MAX ) goto done;
            tx[n++] = MC_PKG_VERSION_REQ;
            tx[n++] = 2;   /* package identifier: multicast control */
            tx[n++] = 1;   /* package version 1 */
            i += 1;
            SMTC_HAL_TRACE_INFO( "[MC] PackageVersionReq\r\n" );
            break;

        case MC_GROUP_STATUS_REQ:
        {
            if( left < 2 ) goto done;
            uint8_t req = p[i + 1] & 0x0F, ans = 0, total = 0, rec[20], rn = 0;

            for( uint8_t g = 0; g < MC_MAX_GROUPS; g++ )
            {
                if( !mc_is_defined( g ) ) continue;
                total++;
                if( req & ( 1U << g ) )
                {
                    ans |= ( uint8_t ) ( 1U << g );
                    rec[rn++] = g;
                    rec[rn++] = ( uint8_t ) ( mc_groups[g].mc_addr );
                    rec[rn++] = ( uint8_t ) ( mc_groups[g].mc_addr >> 8 );
                    rec[rn++] = ( uint8_t ) ( mc_groups[g].mc_addr >> 16 );
                    rec[rn++] = ( uint8_t ) ( mc_groups[g].mc_addr >> 24 );
                }
            }
            if( ( n + 2 + rn ) > MC_ANS_MAX ) goto done;
            tx[n++] = MC_GROUP_STATUS_REQ;
            tx[n++] = ( uint8_t ) ( ( total << 4 ) | ans );   /* RFU(1) | NbTotalGroups(3) | AnsGroupMask(4) */
            memcpy( &tx[n], rec, rn );
            n += rn;
            i += 2;
            SMTC_HAL_TRACE_INFO( "[MC] GroupStatusReq mask=0x%X\r\n", ( unsigned ) req );
            break;
        }

        case MC_GROUP_SETUP_REQ:   /* CID + 29 bytes */
        {
            if( left < 30 ) goto done;
            uint8_t  g    = p[i + 1] & 0x03;
            uint32_t addr = rd_u32_le( &p[i + 2] );
            uint8_t  app[16], nwk[16];
            bool     ok = mc_derive_session_keys( addr, &p[i + 6], app, nwk );

            if( ok )
            {
                mc_stop_session( g );
                mc_groups[g].flags    = MC_FLAG_DEFINED;
                mc_groups[g].mc_addr  = addr;
                mc_groups[g].min_fcnt = rd_u32_le( &p[i + 22] );
                mc_groups[g].max_fcnt = rd_u32_le( &p[i + 26] );
                memcpy( mc_groups[g].app_s_key, app, 16 );
                memcpy( mc_groups[g].nwk_s_key, nwk, 16 );

                ok = mc_push( g );
                if( ok ) ok = mc_save( );
                if( !ok ) memset( &mc_groups[g], 0, sizeof( mc_groups[g] ) );
            }
            memset( app, 0, 16 );
            memset( nwk, 0, 16 );
            SMTC_HAL_TRACE_INFO( "[MC] GroupSetup G%u addr 0x%08lX -> %s\r\n", ( unsigned ) g, ( unsigned long ) addr,
                                 ok ? "OK (saved to EEPROM + modem)" : "FAILED" );

            if( ( n + 2 ) > MC_ANS_MAX ) goto done;
            tx[n++] = MC_GROUP_SETUP_REQ;
            tx[n++] = ( uint8_t ) ( ( ok ? 0U : ( 1U << 2 ) ) | g );   /* IDerror = bit 2 */
            i += 30;
            break;
        }

        case MC_GROUP_DELETE_REQ:
        {
            if( left < 2 ) goto done;
            uint8_t g     = p[i + 1] & 0x03;
            uint8_t undef = mc_is_defined( g ) ? 0U : ( 1U << 2 );   /* McGroupUndefined = bit 2 */

            mc_forget_group( g );
            ( void ) mc_save( );
            SMTC_HAL_TRACE_INFO( "[MC] GroupDelete G%u\r\n", ( unsigned ) g );

            if( ( n + 2 ) > MC_ANS_MAX ) goto done;
            tx[n++] = MC_GROUP_DELETE_REQ;
            tx[n++] = ( uint8_t ) ( undef | g );
            i += 2;
            break;
        }

        case MC_CLASS_C_SESSION_REQ:   /* CID + 10 bytes */
        {
            if( left < 11 ) goto done;
            uint8_t  g  = p[i + 1] & 0x03;
            uint32_t t  = rd_u32_le( &p[i + 2] );    /* SessionTime: GPS seconds */
            uint8_t  to = p[i + 6] & 0x0F;           /* TimeOut: max duration 2^to seconds */
            uint32_t hz = 100UL * rd_u24_le( &p[i + 7] );
            uint8_t  dr = p[i + 10];
            uint8_t  st = g;   /* RFU(3) | McGroupUndefined=bit4 | FreqError=bit3 | DRError=bit2 | McGroupID(2) */

            if( !mc_is_defined( g ) )                                         st |= ( 1U << 4 );
            if( ( hz < CFG_MC_FREQ_MIN_HZ ) || ( hz > CFG_MC_FREQ_MAX_HZ ) )  st |= ( 1U << 3 );
            if( dr > CFG_MC_DR_MAX )                                          st |= ( 1U << 2 );

            if( ( n + 5 ) > MC_ANS_MAX ) goto done;
            tx[n++] = MC_CLASS_C_SESSION_REQ;
            tx[n++] = st;

            if( ( st & 0x1C ) == 0 )   /* no error: TimeToStart (3 bytes) is appended */
            {
                uint32_t now_gps = 0, tts = 0;

                if( mc_gps_now( &now_gps ) )
                {
                    int32_t d = ( int32_t ) ( t - now_gps );
                    tts       = ( d > 0 ) ? ( uint32_t ) d : 0U;
                }
                else
                {
                    SMTC_HAL_TRACE_WARNING( "[MC] No network time yet -> session starts immediately\r\n" );
                }
                mc_stop_session( g );
                mc_sess[g].armed     = true;
                mc_sess[g].start_ms  = APP_TIME_MS( ) + tts * 1000UL;
                mc_sess[g].freq_hz   = hz;
                mc_sess[g].dr        = dr;
                mc_sess[g].timeout_s = 1UL << to;

                tx[n++] = ( uint8_t ) ( tts );
                tx[n++] = ( uint8_t ) ( tts >> 8 );
                tx[n++] = ( uint8_t ) ( tts >> 16 );
                SMTC_HAL_TRACE_INFO( "[MC] ClassCSession G%u %lu Hz DR%u in %lu s for %lu s\r\n", ( unsigned ) g,
                                     ( unsigned long ) hz, ( unsigned ) dr, ( unsigned long ) tts,
                                     ( unsigned long ) mc_sess[g].timeout_s );
            }
            else
            {
                SMTC_HAL_TRACE_WARNING( "[MC] ClassCSession rejected, status=0x%02X\r\n", ( unsigned ) st );
            }
            i += 11;
            break;
        }

        case MC_CLASS_B_SESSION_REQ:   /* CID + 10 bytes. Class B is not implemented */
        {
            if( left < 11 ) goto done;
            uint8_t g  = p[i + 1] & 0x03;
            uint8_t st = ( uint8_t ) ( g | ( 1U << 3 ) );   /* FreqError: "cannot use this", no TimeToStart */
            if( !mc_is_defined( g ) ) st |= ( 1U << 4 );

            if( ( n + 2 ) > MC_ANS_MAX ) goto done;
            tx[n++] = MC_CLASS_B_SESSION_REQ;
            tx[n++] = st;
            i += 11;
            SMTC_HAL_TRACE_WARNING( "[MC] ClassBSession refused (not supported)\r\n" );
            break;
        }

        default:   /* unknown CID: its length is unknown, stop */
            SMTC_HAL_TRACE_WARNING( "[MC] Unknown command 0x%02X, stop parsing\r\n", ( unsigned ) p[i] );
            goto done;
        }
    }

done:
    if( n > 0 )
    {
        smtc_modem_return_code_t rc = smtc_modem_request_uplink( 0, LORA_PORT_MULTICAST_CTRL, false, tx, n );
        if( rc != SMTC_MODEM_RC_OK )
        {
            SMTC_HAL_TRACE_ERROR( "[MC] answer uplink rc=%d\r\n", ( int ) rc );
        }
    }
}

#if( APP_MC_WINDOW_DETECT == 1 )
/* Returns 0..3 when the downlink came through a multicast group, -1 otherwise.
 * !! Verify these enum names against YOUR smtc_modem_api.h (smtc_modem_downlink_window_t) !! */
static int mc_group_from_window( uint8_t w )
{
    switch( w )
    {
    case SMTC_MODEM_EVENT_DOWN_WINDOW_RXC_MC_GRP0: return 0;
    case SMTC_MODEM_EVENT_DOWN_WINDOW_RXC_MC_GRP1: return 1;
    case SMTC_MODEM_EVENT_DOWN_WINDOW_RXC_MC_GRP2: return 2;
    case SMTC_MODEM_EVENT_DOWN_WINDOW_RXC_MC_GRP3: return 3;
    default:                                       return -1;
    }
}
#endif

/* ---- manual provisioning from the serial console ---- */
static bool mc_parse_hex( const char* s, uint8_t* out, uint8_t n )
{
    uint8_t got = 0;
    return ( s != NULL ) && ( hex_to_bytes( s, out, n, &got ) == HEX_OK );
}

static void app_mc_cli( const char* line )
{
    char  buf[160];
    char* t1;
    char* a;
    char* b;
    char* c;
    char* d;

    strncpy( buf, line, sizeof( buf ) - 1U );
    buf[sizeof( buf ) - 1U] = '\0';
    ( void ) strtok( buf, " \r\n" );   /* the word "mc" */
    t1 = strtok( NULL, " \r\n" );

    if( ( t1 == NULL ) || ( app_strcasecmp( t1, "HELP" ) == 0 ) )
    {
        SMTC_HAL_TRACE_INFO( "\r\n=========== MULTICAST HELP ===========\r\n" );
        SMTC_HAL_TRACE_INFO( "Commands:\r\n" );
        SMTC_HAL_TRACE_INFO( "  multicast | unicast | cast     switch / show the cast mode\r\n" );
        SMTC_HAL_TRACE_INFO( "  mc show                        groups + session state\r\n" );
        SMTC_HAL_TRACE_INFO( "  mc keys                        print stored keys + GenAppKey\r\n" );
        SMTC_HAL_TRACE_INFO( "  mc set <g> <addr> <nwk> <app>  store a group (g = 0..3)\r\n" );
        SMTC_HAL_TRACE_INFO( "  mc clear [g]                   delete one / all groups\r\n" );
        SMTC_HAL_TRACE_INFO( "  mc start <g> <freq_hz> <dr> [timeout_s]\r\n" );
        SMTC_HAL_TRACE_INFO( "  mc stop [g]                    stop one / all sessions\r\n\r\n" );
        SMTC_HAL_TRACE_INFO( "SETUP (manual, no server setup needed):\r\n" );
        SMTC_HAL_TRACE_INFO( " 1. In ChirpStack create a multicast group (type Class-C) and note:\r\n" );
        SMTC_HAL_TRACE_INFO( "      Multicast address         -> <addr>  8 hex digits\r\n" );
        SMTC_HAL_TRACE_INFO( "      Network session key       -> <nwk>   32 hex digits\r\n" );
        SMTC_HAL_TRACE_INFO( "      Application session key   -> <app>   32 hex digits\r\n" );
        SMTC_HAL_TRACE_INFO( "      Frequency (Hz), Data-rate -> for 'mc start'\r\n" );
        SMTC_HAL_TRACE_INFO( "    (order is network key FIRST, then application key)\r\n" );
        SMTC_HAL_TRACE_INFO( " 2. Add your gateway and this device to the group in ChirpStack.\r\n" );
        SMTC_HAL_TRACE_INFO( " 3. Here:  multicast\r\n" );
        SMTC_HAL_TRACE_INFO( "           mc set 0 <addr> <nwk> <app>   -> expect modem=OK eeprom=OK\r\n" );
        SMTC_HAL_TRACE_INFO( "           mc start 0 <freq> <dr> 0      -> 0 = run until 'mc stop'\r\n" );
        SMTC_HAL_TRACE_INFO( "           status                        -> session RUNNING\r\n" );
        SMTC_HAL_TRACE_INFO( " 4. ChirpStack > group > Queue: send on FPort 10 (NOT 200-202).\r\n\r\n" );
        SMTC_HAL_TRACE_INFO( "India (IN865) values: freq 866550000, DR 2. They must equal the group\r\n" );
        SMTC_HAL_TRACE_INFO( "settings in ChirpStack. Stay in mode 2 (Class C needs the radio on).\r\n\r\n" );
        SMTC_HAL_TRACE_INFO( "Over-the-air setup only: GenAppKey (unique per device):\r\n" );
        SMTC_HAL_TRACE_INFO( "  *CFG# GENAPPKEY 16 <32 hex>  then  *CFG# REBOOT YES\r\n" );
        SMTC_HAL_TRACE_INFO( "  and enter the same key in ChirpStack for this device.\r\n" );
        SMTC_HAL_TRACE_INFO( "Tip: press Enter once on an empty line before pasting a long command.\r\n" );
        SMTC_HAL_TRACE_INFO( "======================================\r\n> " );
        return;
    }

    if( app_strcasecmp( t1, "SHOW" ) == 0 )
    {
        for( uint8_t g = 0; g < MC_MAX_GROUPS; g++ )
        {
            SMTC_HAL_TRACE_INFO( "[MC] G%u %s addr 0x%08lX fcnt[%lu..%lu) session=%s\r\n", ( unsigned ) g,
                                 mc_is_defined( g ) ? "DEFINED" : "empty  ", ( unsigned long ) mc_groups[g].mc_addr,
                                 ( unsigned long ) mc_groups[g].min_fcnt, ( unsigned long ) mc_groups[g].max_fcnt,
                                 mc_sess[g].running ? "RUNNING" : ( mc_sess[g].armed ? "ARMED" : "off" ) );
        }
    }
    else if( app_strcasecmp( t1, "KEYS" ) == 0 )
    {
#if( APP_MC_SHOW_KEYS == 1 )
        if( mc_defined_count( ) == 0U )
        {
            SMTC_HAL_TRACE_INFO( "[MC] no group defined yet (use 'mc set')\r\n" );
        }
        for( uint8_t g = 0; g < MC_MAX_GROUPS; g++ )
        {
            if( !mc_is_defined( g ) ) continue;
            SMTC_HAL_TRACE_INFO( "[MC] G%u addr 0x%08lX\r\n", ( unsigned ) g, ( unsigned long ) mc_groups[g].mc_addr );
            mc_print_hex( "McNwkSKey", mc_groups[g].nwk_s_key, 16 );
            mc_print_hex( "McAppSKey", mc_groups[g].app_s_key, 16 );
        }
        if( mc_key_is_zero( s_active_gen_app_key ) )
        {
            SMTC_HAL_TRACE_INFO( "[MC] GenAppKey: NOT SET (*CFG# GENAPPKEY 16 <32 hex>)\r\n" );
        }
        else
        {
            mc_print_hex( "GenAppKey", s_active_gen_app_key, 16 );
        }
#else
        SMTC_HAL_TRACE_INFO( "[MC] key printing disabled (APP_MC_SHOW_KEYS=0)\r\n" );
#endif
    }
    else if( app_strcasecmp( t1, "SET" ) == 0 )
    {
        uint8_t ab[4], nk[16], ak[16];

        a = strtok( NULL, " \r\n" );
        b = strtok( NULL, " \r\n" );
        c = strtok( NULL, " \r\n" );
        d = strtok( NULL, " \r\n" );

        if( ( a == NULL ) || ( atoi( a ) < 0 ) || ( atoi( a ) >= MC_MAX_GROUPS ) || !mc_parse_hex( b, ab, 4 ) ||
            !mc_parse_hex( c, nk, 16 ) || !mc_parse_hex( d, ak, 16 ) )
        {
            SMTC_HAL_TRACE_ERROR( "[MC] usage: mc set <0-3> <8 hex addr> <32 hex nwkskey> <32 hex appskey>\r\n> " );
            return;
        }
        uint8_t g = ( uint8_t ) atoi( a );

        mc_stop_session( g );
        mc_groups[g].flags    = MC_FLAG_DEFINED;
        mc_groups[g].mc_addr  = ( ( uint32_t ) ab[0] << 24 ) | ( ( uint32_t ) ab[1] << 16 ) | ( ( uint32_t ) ab[2] << 8 ) |
                               ( uint32_t ) ab[3];   /* typed as ChirpStack shows it */
        mc_groups[g].min_fcnt = 0;
        mc_groups[g].max_fcnt = 0xFFFFFFFFUL;
        memcpy( mc_groups[g].nwk_s_key, nk, 16 );
        memcpy( mc_groups[g].app_s_key, ak, 16 );

        bool okp = mc_push( g );
        bool oks = mc_save( );
        SMTC_HAL_TRACE_INFO( "[MC] G%u set: modem=%s eeprom=%s\r\n", ( unsigned ) g, okp ? "OK" : "FAIL", oks ? "OK" : "FAIL" );
        memset( nk, 0, 16 );
        memset( ak, 0, 16 );
    }
    else if( app_strcasecmp( t1, "CLEAR" ) == 0 )
    {
        a = strtok( NULL, " \r\n" );
        for( uint8_t g = 0; g < MC_MAX_GROUPS; g++ )
        {
            if( ( a == NULL ) || ( ( uint8_t ) atoi( a ) == g ) ) mc_forget_group( g );
        }
        SMTC_HAL_TRACE_INFO( "[MC] cleared, eeprom=%s\r\n", mc_save( ) ? "OK" : "FAIL" );
    }
    else if( app_strcasecmp( t1, "START" ) == 0 )
    {
        a = strtok( NULL, " \r\n" );
        b = strtok( NULL, " \r\n" );
        c = strtok( NULL, " \r\n" );
        d = strtok( NULL, " \r\n" );

        if( ( a == NULL ) || ( b == NULL ) || ( c == NULL ) || ( atoi( a ) < 0 ) || ( atoi( a ) >= MC_MAX_GROUPS ) ||
            !mc_is_defined( ( uint8_t ) atoi( a ) ) )
        {
            SMTC_HAL_TRACE_ERROR( "[MC] usage: mc start <defined g> <freq_hz> <dr> [timeout_s]\r\n> " );
            return;
        }
        ( void ) mc_start_now( ( uint8_t ) atoi( a ), strtoul( b, NULL, 10 ), ( uint8_t ) atoi( c ),
                               ( d != NULL ) ? strtoul( d, NULL, 10 ) : 0UL );
    }
    else if( app_strcasecmp( t1, "STOP" ) == 0 )
    {
        a = strtok( NULL, " \r\n" );
        for( uint8_t g = 0; g < MC_MAX_GROUPS; g++ )
        {
            if( ( a == NULL ) || ( ( uint8_t ) atoi( a ) == g ) ) mc_stop_session( g );
        }
    }
    else
    {
        SMTC_HAL_TRACE_ERROR( "[MC] unknown subcommand, type 'mc help'\r\n" );
    }
    SMTC_HAL_TRACE_INFO( "> " );
}
#endif /* APP_ENABLE_MULTICAST == 1 */

/* ---- cast mode switching (terminal commands: unicast / multicast / cast) ---- */
static void app_cast_enter_multicast( void )
{
#if( APP_ENABLE_MULTICAST == 1 )
    if( s_single_channel )
    {
        SMTC_HAL_TRACE_WARNING( "\r\n[CAST] Type 'sc off' first.\r\n> " );
        return;
    }
    if( s_multicast_mode )
    {
        SMTC_HAL_TRACE_INFO( "\r\n[CAST] Already in MULTICAST mode.\r\n> " );
        return;
    }
    s_multicast_mode = true;

    SMTC_HAL_TRACE_INFO( "\r\n[CAST] >>> MULTICAST mode: always-on (mode 2), Class C, port-200 setup enabled.\r\n" );
    app_apply_mode( 2 );   /* radio always on, sets Class C and announces */

    if( s_network_ready )
    {
        lora_multicast_push_all( );
#if( APP_MC_REQUEST_DEVICE_TIME == 1 )
        /* network (GPS) time is needed to schedule McClassCSessionReq */
        ( void ) smtc_modem_trig_lorawan_mac_request( 0, SMTC_MODEM_LORAWAN_MAC_REQ_DEVICE_TIME );
#endif
    }
    SMTC_HAL_TRACE_INFO( "[CAST] Type 'unicast' to go back to normal uplink/downlink.\r\n> " );
#else
    SMTC_HAL_TRACE_INFO( "\r\n[CAST] Multicast is not compiled in (APP_ENABLE_MULTICAST=0).\r\n> " );
#endif
}

static void app_cast_enter_unicast( void )
{
    if( !s_multicast_mode )
    {
        SMTC_HAL_TRACE_INFO( "\r\n[CAST] Already in UNICAST mode.\r\n> " );
        return;
    }
#if( APP_ENABLE_MULTICAST == 1 )
    for( uint8_t g = 0; g < MC_MAX_GROUPS; g++ )
    {
        mc_stop_session( g );
    }
#endif
    s_multicast_mode = false;

    if( s_network_ready )
    {
        app_set_modem_class( app_listen_class( ) );
    }
    SMTC_HAL_TRACE_INFO( "\r\n[CAST] >>> UNICAST mode: normal uplink/downlink.\r\n" );
    app_print_protocol_info( );
    SMTC_HAL_TRACE_INFO( "> " );
}

static void app_apply_mode( uint8_t mode )
{
    if( s_p2p_active )
    {
        rp2p_apply_mode( mode );
        return;
    }
    if( s_multicast_mode && ( mode != 2 ) )
    {
        SMTC_HAL_TRACE_WARNING( "\r\n[MODE] Multicast needs the radio always on (mode 2). Type 'unicast' first.\r\n> " );
        return;
    }

    current_op_mode = mode;

    if( s_network_ready )
    {
        app_set_modem_class( app_listen_class( ) );
    }
    if( APP_IS_LP_MODE( mode ) )
    {
        app_lp_begin_wake_window( );
    }
    app_announce_mode( mode );
}

static bool app_tx_text( const char* text )
{
    if( s_p2p_active ) return rp2p_tx_text( text );
    if( text == NULL ) return false;
    if( strlen( text ) == 0 ) return false;
    if( s_single_channel && ( strlen( text ) > SC_MAX_PAYLOAD ) )
    {
        SMTC_HAL_TRACE_ERROR( "\r\n[SC] Text too long for SF12: %u > %d bytes\r\n> ", ( unsigned ) strlen( text ),
                              SC_MAX_PAYLOAD );
        return false;
    }
    app_sc_refresh( );
    lora_app_send_text( LORA_PORT_CHAT, text, CUSTOM_UPLINK_CONFIRMED );
    return true;
}

static bool app_tx_sensor( void )
{
    if( s_p2p_active )
    {
#ifdef P2P_SENSOR_BUILD_PAYLOAD
        uint8_t buf[64];
        uint8_t n = ( uint8_t ) P2P_SENSOR_BUILD_PAYLOAD( buf, sizeof( buf ) );
        return ( n > 0 ) && rp2p_send_raw( buf, n );
#else
        SMTC_HAL_TRACE_INFO( "[P2P] sensor packet not available in this build\r\n> " );
        return false;
#endif
    }
    app_sc_refresh( );
    sensor_manager_trigger_sample_and_send( CUSTOM_UPLINK_CONFIRMED );
    return true;
}

static void app_rx_open( void )
{
    if( s_p2p_active ) { rp2p_start_rx( ); return; }
    app_set_modem_class( app_listen_class( ) );
}

static void app_rx_close( void )
{
    if( s_p2p_active ) { rp2p_standby( ); return; }
    app_set_modem_class( app_listen_class( ) );
}

static void app_radio_sleep( void )
{
    if( s_p2p_active )
    {
        RP2P_CHECK( sx126x_set_sleep( rp2p_ctx, SX126X_SLEEP_CFG_COLD_START ) );
        return;
    }
    smtc_modem_suspend_radio_communications( true );   /* library forces Class A here */
}

static void app_radio_wake( void )
{
    if( s_p2p_active ) { rp2p_configure( ); return; }
    smtc_modem_suspend_radio_communications( false );
    app_sc_refresh( );
    app_set_modem_class( app_listen_class( ) );        /* restore the selected class */
}

static bool app_lp_can_sleep( void )
{
    if( s_p2p_active ) return true;
    /* never suspend the radio in multicast mode (Class C must keep listening) */
    return s_network_ready && !s_multicast_mode && !smtc_modem_is_irq_flag_pending( );
}

static void app_print_status( void )
{
    if( s_p2p_active ) { rp2p_print_status( ); return; }

    smtc_modem_class_t real = SMTC_MODEM_CLASS_A;
    bool               ok   = ( smtc_modem_get_class( 0, &real ) == SMTC_MODEM_RC_OK );
    bool               sc_locked = s_single_channel;
#if( APP_SC_REGION_LOCK == 1 )
    sc_locked = sc_locked && region_in_865_is_single_channel( );
#endif

    SMTC_HAL_TRACE_INFO( "\r\n[STATUS] mode=%u | cast=%s | profile=%s (%lu Hz, DR%d, lock=%s) | selected class=%s | modem reports=%s | network_ready=%u\r\n",
                         ( unsigned ) current_op_mode, s_multicast_mode ? "MULTICAST" : "UNICAST",
                         s_single_channel ? "SINGLE-CHANNEL" : "multi-channel", ( unsigned long ) SC_FREQ_HZ, SC_DR,
                         sc_locked ? "ON" : "OFF",
                         ( CUSTOM_DEPLOYMENT_CLASS == 2 ) ? "C" : "A",
                         ok ? ( ( real == SMTC_MODEM_CLASS_C ) ? "C" : "A" ) : "?", ( unsigned ) s_network_ready );

    if( g_app_tx_pwr_limit_dbm == APP_TX_PWR_LIMIT_NONE )
    {
        SMTC_HAL_TRACE_INFO( "[STATUS] TX power cap: none (full power)\r\n" );
    }
    else
    {
        SMTC_HAL_TRACE_INFO( "[STATUS] TX power cap: %d dBm\r\n", ( int ) g_app_tx_pwr_limit_dbm );
    }
    SMTC_HAL_TRACE_INFO( "[STATUS] Radio frequency offset: %ld Hz\r\n", ( long ) g_app_freq_offset_hz );
#if( LORA_ACTIVATION_MODE == CUSTOM_ACTIVATION_MODE_ABP )
    SMTC_HAL_TRACE_INFO( "[STATUS] ABP counters seen by app: uplinks=%lu downlinks=%lu\r\n", ( unsigned long ) active_fcnt_up,
                         ( unsigned long ) active_fcnt_down );
#endif
#if( APP_ENABLE_MULTICAST == 1 )
    SMTC_HAL_TRACE_INFO( "[STATUS] Multicast: %u group(s) defined | session %s\r\n", ( unsigned ) mc_defined_count( ),
                         mc_session_running( ) ? "RUNNING" : ( mc_session_active( ) ? "ARMED" : "off" ) );
#endif
    if( ( CUSTOM_DEPLOYMENT_CLASS == 2 ) && APP_IS_LP_MODE( current_op_mode ) )
    {
        SMTC_HAL_TRACE_WARNING( "[STATUS] Class C downlinks are missed in mode 0/1 (radio sleeps). Type 'mode 2'.\r\n" );
    }
    SMTC_HAL_TRACE_INFO( "> " );
}

static void app_print_rssi( void )
{
    if( s_p2p_active ) { rp2p_print_status( ); return; }

    if( !s_dl_valid )
    {
        SMTC_HAL_TRACE_INFO( "\r\n[RSSI] No downlink received yet.\r\n> " );
        return;
    }
    SMTC_HAL_TRACE_INFO( "\r\n[RSSI] Last downlink: RSSI %d dBm | SNR %d dB | FPort %u | %lu s ago\r\n> ", ( int ) s_dl_rssi,
                         ( int ) s_dl_snr, ( unsigned ) s_dl_fport,
                         ( unsigned long ) ( ELAPSED( APP_TIME_MS( ), s_dl_time_ms ) / 1000UL ) );
}

static bool app_protocol_command( const char* s )
{
    /* ---- runtime protocol switch ---- */
    if( app_cmd_is( s, "p2p" ) )     { rp2p_enter( ); return true; }
    if( app_cmd_is( s, "lorawan" ) ) { rp2p_exit( );  return true; }

    if( s_p2p_active )
    {
#ifdef CFG_CMD_PING
        if( app_cmd_is( s, CFG_CMD_PING ) )
        {
            rp2p_apply_mode( 2 );
            rp2p_pp_master    = true;
            rp2p_next_ping_ms = APP_TIME_MS( );
            SMTC_HAL_TRACE_INFO( "[PINGPONG] Master started. Type '%s' to end.\r\n> ", CFG_CMD_STOP );
            return true;
        }
        if( app_cmd_is( s, CFG_CMD_STOP ) )
        {
            rp2p_pp_master    = false;
            rp2p_pong_pending = false;
            SMTC_HAL_TRACE_INFO( "[PINGPONG] Stopped.\r\n> " );
            return true;
        }
#endif
        /* P2P tuning: frequency offset, TX power cap, spreading factor */
        if( app_sco_command( s ) || app_txp_command( s ) )
        {
            rp2p_refresh_rf( );
            return true;
        }
        if( rp2p_sf_command( s ) ) { return true; }

        if( app_cmd_is( s, "multicast" ) || app_cmd_is( s, "unicast" ) || app_cmd_is( s, "sc on" ) ||
            app_cmd_is( s, "sc off" ) || app_cmd_is( s, "sc" ) )
        {
            SMTC_HAL_TRACE_WARNING( "\r\n[P2P] LoRaWAN-only command. Type 'lorawan' first.\r\n> " );
            return true;
        }
        return false;   /* anything else = raw P2P text */
    }

    /* ---- TX power reduction: 'txp' / 'txp <dBm>' ---- */
    if( app_txp_command( s ) ) { return true; }

    /* ---- radio frequency offset: 'sco' / 'sco <Hz>' ---- */
    if( app_sco_command( s ) ) { return true; }

    /* ---- P2P-only command typed while in LoRaWAN ---- */
    if( ( app_strncasecmp( s, "psf", 3 ) == 0 ) && ( ( s[3] == '\0' ) || ( s[3] == ' ' ) || ( s[3] == '\t' ) ) )
    {
        SMTC_HAL_TRACE_WARNING( "\r\n[PSF] P2P-only command. Type 'p2p' first.\r\n> " );
        return true;
    }

    /* ---- single-channel gateway profile ---- */
    if( app_cmd_is( s, "sc on" ) )  { app_sc_set( true );  return true; }
    if( app_cmd_is( s, "sc off" ) ) { app_sc_set( false ); return true; }
    if( app_cmd_is( s, "sc" ) )
    {
        SMTC_HAL_TRACE_INFO( "\r\n[SC] Single-channel profile: %s (%lu Hz, SF12/BW125, DR0)\r\n> ",
                             s_single_channel ? "ON" : "OFF", ( unsigned long ) SC_FREQ_HZ );
        return true;
    }

    /* ---- cast mode / multicast ---- */
    if( app_cmd_is( s, "multicast" ) ) { app_cast_enter_multicast( ); return true; }
    if( app_cmd_is( s, "unicast" ) )   { app_cast_enter_unicast( );   return true; }
    if( app_cmd_is( s, "cast" ) )
    {
        SMTC_HAL_TRACE_INFO( "\r\n[CAST] Current cast mode = %s\r\n> ", s_multicast_mode ? "MULTICAST" : "UNICAST" );
        return true;
    }
#if( APP_ENABLE_MULTICAST == 1 )
    /* "mc" or "mc <subcommand...>" */
    if( ( app_strncasecmp( s, "mc", 2 ) == 0 ) && ( ( s[2] == ' ' ) || ( s[2] == '\0' ) || ( s[2] == '\t' ) ) )
    {
        app_mc_cli( s );
        return true;
    }
#endif
    return false;
}

void lora_app_init( void )
{
    eeprom_manager_init( );

#if( APP_ENABLE_MULTICAST == 1 )
    /* RAM-only load: no modem call here, the groups are pushed to the modem when multicast mode starts */
    mc_load_from_eeprom( );
#endif

    app_sync_sc_lock( );
    smtc_modem_init( &modem_event_callback );
    /* Re-apply after smtc_modem_init() so s_real_ref in region_in_865.c is populated */
    app_sync_sc_lock( );
    sensor_manager_init( );

    SMTC_HAL_TRACE_INFO( "\r\n=================================================\r\n" );
    SMTC_HAL_TRACE_INFO( "     Smart IoT Terminal (LoRaWAN)                \r\n" );
    SMTC_HAL_TRACE_INFO( "=================================================\r\n" );
#if( APP_ENABLE_MULTICAST == 1 )
    SMTC_HAL_TRACE_INFO( "[MC] %u multicast group(s) stored in EEPROM | boot cast mode: UNICAST ('multicast' to switch)\r\n",
                         ( unsigned ) mc_defined_count( ) );
#endif
    app_periodic_reschedule( );
    if( APP_IS_LP_MODE( current_op_mode ) )
    {
        app_lp_begin_wake_window( );
    }
    app_announce_mode( current_op_mode );
}

void lora_app_join_network( void )
{
    static const uint8_t m_dev_eui[8]      = USER_DEV_EUI;
    static const uint8_t m_join_eui[8]     = USER_JOIN_EUI;
    static const uint8_t m_app_key[16]     = USER_APP_KEY;
    static const uint8_t m_gen_app_key[16] = USER_GEN_APP_KEY;
    static const uint8_t m_nwk_s_key[16]   = USER_NWK_S_KEY;
    static const uint8_t m_app_s_key[16]   = USER_APP_S_KEY;

    lora_credentials_t wanted;
    lora_credentials_t active;
    uint32_t           fcnt_up   = 0;
    uint32_t           fcnt_down = 0;

    memcpy( wanted.dev_eui, m_dev_eui, 8 );
    memcpy( wanted.join_eui, m_join_eui, 8 );
    memcpy( wanted.app_key, m_app_key, 16 );
    memcpy( wanted.gen_app_key, m_gen_app_key, 16 );
    memcpy( wanted.nwk_s_key, m_nwk_s_key, 16 );
    memcpy( wanted.app_s_key, m_app_s_key, 16 );
    wanted.dev_addr = USER_DEV_ADDR;

    ( void ) eeprom_sync_credentials( &wanted, ( FORCE_FACTORY_RESET_ABP == 1 ), &active, &fcnt_up, &fcnt_down );

#if( FORCE_FACTORY_RESET_ABP == 1 )
    SMTC_HAL_TRACE_WARNING( "[CFG] FORCE_FACTORY_RESET_ABP=1 -> EEPROM keys were reset to the compiled USER_* values!\r\n" );
#endif

    /* Diagnostic: tells you right at boot if the keys were wiped (all zero) or fell back to defaults. */
#if( LORA_ACTIVATION_MODE == CUSTOM_ACTIVATION_MODE_OTAA )
    if( app_key_is_zero( active.app_key ) )
    {
        SMTC_HAL_TRACE_WARNING( "[CFG] WARNING: AppKey read from EEPROM is ALL ZERO -> keys were lost/erased. Re-enter with '*CFG#'.\r\n" );
    }
#else
    if( app_key_is_zero( active.nwk_s_key ) || app_key_is_zero( active.app_s_key ) )
    {
        SMTC_HAL_TRACE_WARNING( "[CFG] WARNING: NwkSKey/AppSKey read from EEPROM are ALL ZERO -> keys were lost/erased. Re-enter with '*CFG#'.\r\n" );
    }
#endif

#if( APP_ENABLE_MULTICAST == 1 )
    memcpy( s_active_gen_app_key, active.gen_app_key, 16 );   /* GenAppKey from EEPROM, used for multicast key derivation */
    if( mc_key_is_zero( s_active_gen_app_key ) )
    {
        SMTC_HAL_TRACE_WARNING( "[MC] GenAppKey is NOT set (only needed for over-the-air multicast setup)\r\n" );
    }
#endif

    app_sync_sc_lock( );

#if( LORA_ACTIVATION_MODE == CUSTOM_ACTIVATION_MODE_OTAA )
    ( void ) fcnt_up;
    ( void ) fcnt_down;

    smtc_modem_set_deveui( 0, active.dev_eui );
    smtc_modem_set_joineui( 0, active.join_eui );
    smtc_modem_set_appkey( 0, active.gen_app_key );
    smtc_modem_set_nwkkey( 0, active.app_key );

    app_sc_refresh( );

    /* class cannot be set before the join: it is applied in the JOINED event */
    smtc_modem_join_network( 0 );

    SMTC_HAL_TRACE_INFO( "[STATUS] Initiating OTAA Join | DevEUI: %02X%02X%02X%02X%02X%02X%02X%02X\r\n", active.dev_eui[0],
                         active.dev_eui[1], active.dev_eui[2], active.dev_eui[3], active.dev_eui[4], active.dev_eui[5],
                         active.dev_eui[6], active.dev_eui[7] );

#elif( LORA_ACTIVATION_MODE == CUSTOM_ACTIVATION_MODE_ABP )
    /* EEPROM copy is only written every APP_FCNT_SAVE_INTERVAL frames, so add the interval to stay ahead. */
    active_fcnt_up   = ( fcnt_up   != 0U ) ? ( fcnt_up   + APP_FCNT_SAVE_INTERVAL ) : 0U;
    active_fcnt_down = ( fcnt_down != 0U ) ? ( fcnt_down + APP_FCNT_SAVE_INTERVAL ) : 0U;

    smtc_modem_leave_network( 0 );

    smtc_modem_set_deveui( 0, active.dev_eui );
    smtc_modem_set_joineui( 0, ( const uint8_t[] ){ 0, 0, 0, 0, 0, 0, 0, 0 } );
    smtc_modem_debug_connect_with_abp( 0, active.dev_addr, active.nwk_s_key, active.app_s_key );

    app_sync_sc_lock( );
    /* ABP activation above has established the modem session. Set this flag
     * BEFORE applying the ADR profile: app_apply_dr_profile() intentionally
     * refuses to call the modem API while the application is not ready. */
    s_network_ready = true;
    lora_app_set_adr_profile( 0 );
    app_set_modem_class( app_listen_class( ) );

    SMTC_HAL_TRACE_INFO( "[STATUS] ABP Activated | DevEUI: %02X%02X%02X%02X%02X%02X%02X%02X | DevAddr: 0x%08lX | fcnt_up=%lu | Mode %u\r\n",
                         active.dev_eui[0], active.dev_eui[1], active.dev_eui[2], active.dev_eui[3], active.dev_eui[4],
                         active.dev_eui[5], active.dev_eui[6], active.dev_eui[7], ( unsigned long ) active.dev_addr,
                         ( unsigned long ) active_fcnt_up, ( unsigned ) current_op_mode );
    SMTC_HAL_TRACE_WARNING( "[ABP] The modem restarts its uplink counter at 0 after every reboot: in ChirpStack enable 'Disable frame-counter validation' (device profile / device) or uplinks AND downlinks are dropped.\r\n" );
    app_print_help( );
#endif
}

void lora_app_leave_network( void )
{
#if( APP_ENABLE_MULTICAST == 1 )
    for( uint8_t g = 0; g < MC_MAX_GROUPS; g++ ) mc_stop_session( g );
#endif
    smtc_modem_leave_network( 0 );
    s_network_ready = false;
    SMTC_HAL_TRACE_INFO( "[STATUS] Left LoRaWAN Network.\r\n" );
}

void lora_app_set_class( uint8_t new_class )
{
    app_apply_mode( ( new_class == 2 ) ? 2 : 0 );
}

void lora_app_send_text( uint8_t fport, const char* text, bool confirmed )
{
    if( s_p2p_active )
    {
        ( void ) rp2p_tx_text( text );
        return;
    }
    if( text == NULL ) return;
    uint8_t len = ( uint8_t ) strlen( text );
    if( len == 0 ) return;

    app_sc_refresh( );

#if( LORA_ACTIVATION_MODE == CUSTOM_ACTIVATION_MODE_ABP )
    SMTC_HAL_TRACE_INFO( "\r\n[TX] Transmitting: '%s' (fport=%u, %s, DR%d, app_fcnt_up=%lu)\r\n", text,
                         ( unsigned ) fport, s_single_channel ? "SINGLE-CH 865.0625 MHz SF12" : "MULTI-CH",
                         s_single_channel ? SC_DR : 5,
                         ( unsigned long ) active_fcnt_up );
#else
    SMTC_HAL_TRACE_INFO( "\r\n[TX] Transmitting: '%s' (fport=%u, %s, DR%d)\r\n", text,
                         ( unsigned ) fport, s_single_channel ? "SINGLE-CH 865.0625 MHz SF12" : "MULTI-CH",
                         s_single_channel ? SC_DR : 5 );
#endif
    smtc_modem_return_code_t rc = smtc_modem_request_uplink( 0, fport, confirmed, ( const uint8_t* ) text, len );
    if( rc != SMTC_MODEM_RC_OK )
    {
        SMTC_HAL_TRACE_ERROR( "[TX] request_uplink FAILED rc=%d\r\n> ", ( int ) rc );
    }
}

void lora_app_process( void )
{
    uint8_t tx_payload[BSP_UART_RX_BUF_SIZE];
    uint8_t tx_len = 0;

    if( s_p2p_active )
    {
        rp2p_service_radio( );
        rp2p_service_pingpong( );
    }
    else
    {
        smtc_modem_run_engine( );
        modem_event_callback( );
#if( APP_ENABLE_MULTICAST == 1 )
        if( s_multicast_mode )
        {
            lora_multicast_service( );
        }
#endif
    }

    bsp_console_poll( );
    if( bsp_uart_get_line( tx_payload, &tx_len ) )
    {
        if( ( uint32_t ) tx_len >= sizeof( tx_payload ) ) tx_len = ( uint8_t )( sizeof( tx_payload ) - 1 );
        tx_payload[tx_len] = '\0';
        app_dispatch_line( tx_payload, tx_len );
    }

    if( APP_IS_LP_MODE( current_op_mode ) )
    {
        app_lp_service( );
    }

    bsp_watchdog_reload( );

    if( s_p2p_active )
    {
        hal_mcu_wait_us( 200 );
        return;
    }

    if( ( smtc_modem_is_irq_flag_pending( ) == true ) || ( smtc_modem_hal_poll_radio_irq( ) == true ) )
    {
        smtc_modem_run_engine( );
        modem_event_callback( );
    }
    else
    {
        hal_mcu_wait_us( 200 );
    }
}

void main_periodical_uplink( void )
{
    lora_app_init( );

    while( 1 )
    {
        lora_app_process( );
    }
}

static void modem_event_callback( void )
{
    smtc_modem_event_t current_event;
    uint8_t            event_pending_count;

    static uint8_t                  rx_payload[SMTC_MODEM_MAX_LORAWAN_PAYLOAD_LENGTH];
    static uint8_t                  rx_payload_size = 0;
    static smtc_modem_dl_metadata_t rx_metadata;
    static uint8_t                  rx_remaining = 0;

    do
    {
        smtc_modem_return_code_t rc = smtc_modem_get_event( &current_event, &event_pending_count );
        if( rc != SMTC_MODEM_RC_OK )
        {
            break;
        }

        switch( current_event.event_type )
        {
        case SMTC_MODEM_EVENT_RESET:
            smtc_modem_set_region( 0, CUSTOM_REGION );
            app_sc_refresh( );
            lora_app_join_network( );
            break;

        case SMTC_MODEM_EVENT_JOINED:
            SMTC_HAL_TRACE_INFO( "\r\n[STATUS] Successfully joined the LoRaWAN network!\r\n" );
            s_network_ready = true;
            app_sc_refresh( );
            app_set_modem_class( app_listen_class( ) );
#if( APP_ENABLE_MULTICAST == 1 )
            if( s_multicast_mode )
            {
                lora_multicast_push_all( );
            }
#endif
            app_print_protocol_info( );
            SMTC_HAL_TRACE_INFO( "> " );
            break;

        case SMTC_MODEM_EVENT_JOINFAIL:
            SMTC_HAL_TRACE_WARNING( "\r\n[WARN] Join failed. Retrying...\r\n" );
            break;

        case SMTC_MODEM_EVENT_TXDONE:
        {
            const int txs = ( int ) current_event.event_data.txdone.status;

            /* single-channel: the network may have re-enabled other channels (MAC commands) -> lock again */
            if( s_single_channel ) { app_sync_sc_lock( ); }

            SMTC_HAL_TRACE_INFO( "\r\n[TX] %s\r\n", ( txs == 0 ) ? "NOT sent" :
                                                    ( txs == 1 ) ? "Sent OK (unconfirmed uplink, no ACK expected)" :
                                                                   "Sent OK + ACK received" );
#if( LORA_ACTIVATION_MODE == CUSTOM_ACTIVATION_MODE_ABP )
            if( txs != 0 )
            {
                active_fcnt_up++;
                /* EEPROM write only every N frames: frequent writes wear the cell and a reset mid-write can corrupt the key block */
                if( ( active_fcnt_up % APP_FCNT_SAVE_INTERVAL ) == 0U )
                {
                    eeprom_update_fcnt_up( active_fcnt_up );
                }
            }
#endif
            if( APP_IS_LP_MODE( current_op_mode ) )
            {
                app_lp_on_tx_done( );
            }
            else
            {
                app_set_modem_class( app_listen_class( ) );
            }
            SMTC_HAL_TRACE_INFO( "> " );
            break;
        }

        case SMTC_MODEM_EVENT_DOWNDATA:
        {
            bool is_mc = false;
#if( APP_ENABLE_MULTICAST == 1 ) && ( APP_MC_WINDOW_DETECT == 1 )
            int mc_g = -1;
#endif
            smtc_modem_get_downlink_data( rx_payload, &rx_payload_size, &rx_metadata, &rx_remaining );

            s_dl_valid   = true;
            s_dl_rssi    = ( int16_t ) rx_metadata.rssi - 64;      /* modem reports rssi + 64 */
            s_dl_snr     = ( int16_t ) ( rx_metadata.snr >> 2 );   /* modem reports snr x 4 */
            s_dl_fport   = rx_metadata.fport;
            s_dl_time_ms = APP_TIME_MS( );

            /* single-channel: NewChannelReq / LinkADRReq inside this downlink may have re-enabled channels -> lock again */
            if( s_single_channel ) { app_sync_sc_lock( ); }

#if( APP_ENABLE_MULTICAST == 1 ) && ( APP_MC_WINDOW_DETECT == 1 )
            mc_g  = mc_group_from_window( ( uint8_t ) rx_metadata.window );
            is_mc = ( mc_g >= 0 );
#endif

#if( LORA_ACTIVATION_MODE == CUSTOM_ACTIVATION_MODE_ABP )
            if( !is_mc )   /* multicast frames must not move the unicast counter */
            {
                active_fcnt_down++;
                if( ( active_fcnt_down % APP_FCNT_SAVE_INTERVAL ) == 0U )
                {
                    eeprom_update_fcnt_down( active_fcnt_down );
                }
            }
#endif
            SMTC_HAL_TRACE_INFO( "\r\n\r\n========== %s ==========\r\n", is_mc ? "MULTICAST DOWNLINK" : "INSTANT DOWNLINK" );
            SMTC_HAL_TRACE_INFO( "FPort: %u | RSSI: %d dBm | SNR: %d dB | Size: %u bytes\r\n", rx_metadata.fport,
                                 ( int ) s_dl_rssi, ( int ) s_dl_snr, rx_payload_size );

#if( APP_ENABLE_MULTICAST == 1 ) && ( APP_MC_WINDOW_DETECT == 1 )
            if( is_mc )
            {
                /* spec 4.3: only accept minMcFCount <= FCnt < maxMcFCount */
                if( ( rx_metadata.fcnt_down < mc_groups[mc_g].min_fcnt ) ||
                    ( rx_metadata.fcnt_down >= mc_groups[mc_g].max_fcnt ) )
                {
                    SMTC_HAL_TRACE_WARNING( "[MC G%d] FCnt %lu outside [%lu..%lu) - ignored\r\n", mc_g,
                                            ( unsigned long ) rx_metadata.fcnt_down,
                                            ( unsigned long ) mc_groups[mc_g].min_fcnt,
                                            ( unsigned long ) mc_groups[mc_g].max_fcnt );
                    SMTC_HAL_TRACE_INFO( "> " );
                    break;
                }
            }
#endif

            if( rx_payload_size > 0 )
            {
                if( rx_metadata.fport == LORA_PORT_SENSOR_CMD )
                {
                    sensor_manager_process_downlink( rx_payload, rx_payload_size );
                }
                else if( rx_metadata.fport == LORA_PORT_MULTICAST_CTRL )
                {
#if( APP_ENABLE_MULTICAST == 1 )
                    if( !s_multicast_mode )
                    {
                        SMTC_HAL_TRACE_INFO( "[MC] Port 200 ignored: unicast mode (type 'multicast' first)\r\n" );
                    }
                    else if( !is_mc ) /* control messages received on a multicast address MUST be dropped silently */
                    {
                        lora_multicast_process_downlink( rx_payload, rx_payload_size );
                    }
#endif
                }
                else if( rx_metadata.fport == LORA_PORT_CLOCK_SYNC )
                {
                    SMTC_HAL_TRACE_INFO( "[FUOTA] Clock Sync Port 202 Data Received\r\n" );
                }
                else if( rx_metadata.fport == LORA_PORT_FRAG_CTRL )
                {
                    SMTC_HAL_TRACE_INFO( "[FUOTA] Firmware Fragment Port 201 Data Received\r\n" );
                }

                if( rx_payload_size >= sizeof( rx_payload ) )
                {
                    rx_payload_size = sizeof( rx_payload ) - 1;
                }
                rx_payload[rx_payload_size] = '\0';
                SMTC_HAL_TRACE_INFO( "Payload: %s\r\n", ( char* ) rx_payload );
            }
            else
            {
                SMTC_HAL_TRACE_INFO( "Payload: <EMPTY ACK / MAC COMMAND>\r\n" );
            }
            SMTC_HAL_TRACE_INFO( "======================================\r\n" );
            SMTC_HAL_TRACE_INFO( "> " );
            break;
        }

        default:
#if( APP_DEBUG_EVENTS == 1 )
            SMTC_HAL_TRACE_INFO( "[EVT] modem event type=%d\r\n", ( int ) current_event.event_type );
#endif
            break;
        }
    } while( event_pending_count > 0 );
}

#endif