./objects/hw_modem.o: ..\SWL2001-master\hw_modem\hw_modem.c \
  ..\SWL2001-master\smtc_hal_l0_LL\smtc_hal_dbg_trace.h \
  ..\SWL2001-master\smtc_hal_l0_LL\smtc_hal_trace.h \
  ..\SWL2001-master\hw_modem\hw_modem.h \
  ..\SWL2001-master\hw_modem\cmd_parser.h \
  ..\SWL2001-master\smtc_modem_api\smtc_modem_api.h \
  ..\SWL2001-master\modem_pinout.h \
  ..\SWL2001-master\smtc_hal_l0_LL\smtc_hal_gpio_pin_names.h \
  ..\SWL2001-master\smtc_modem_api\smtc_modem_utilities.h \
  ..\SWL2001-master\smtc_hal_l0_LL\smtc_hal_uart.h \
  ..\SWL2001-master\smtc_hal_l0_LL\smtc_hal_mcu.h \
  ..\SWL2001-master\smtc_hal_l0_LL\smtc_hal_gpio.h
