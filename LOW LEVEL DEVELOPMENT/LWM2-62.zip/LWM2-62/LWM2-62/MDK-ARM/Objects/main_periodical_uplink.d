./objects/main_periodical_uplink.o: \
  ..\SWL2001-master\main_examples\main_periodical_uplink.c
