./objects/rose.o: ..\SWL2001-master\lbm_lib\smtc_modem_core\rose.c \
  ..\SWL2001-master\smtc_modem_core\smtc_modem_crypto\smtc_modem_crypto.h \
  ..\SWL2001-master\smtc_modem_core\smtc_modem_crypto\smtc_secure_element\smtc_secure_element.h \
  ..\SWL2001-master\smtc_modem_core\logging\smtc_modem_hal_dbg_trace.h \
  ..\SWL2001-master\smtc_modem_hal\smtc_modem_hal.h \
  ..\SWL2001-master\lbm_lib\smtc_modem_core\modem_services_common.h \
  ..\SWL2001-master\lbm_lib\smtc_modem_core\rose.h \
  ..\SWL2001-master\lbm_lib\smtc_modem_core\rose_defs.h
