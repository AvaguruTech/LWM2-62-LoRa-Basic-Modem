./objects/main_1.o: ..\SWL2001-master\lbm_examples\main.c \
  ..\SWL2001-master\lbm_examples\lora_eg\main.h
