./objects/git_version.o: ..\SWL2001-master\hw_modem\git_version.c \
  ..\SWL2001-master\hw_modem\git_version.h
