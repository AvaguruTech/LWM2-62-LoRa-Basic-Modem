./objects/smtc_hal_gpio.o: \
  ..\SWL2001-master\smtc_hal_l0_LL\smtc_hal_gpio.c \
  ..\SWL2001-master\smtc_hal_l0_LL\smtc_hal_gpio.h \
  ..\SWL2001-master\smtc_hal_l0_LL\smtc_hal_gpio_pin_names.h \
  ..\SWL2001-master\modem_pinout.h \
  ..\Drivers\STM32L0xx_HAL_Driver\Inc\stm32l0xx_ll_gpio.h \
  ..\Drivers\CMSIS\Device\ST\STM32L0xx\Include\stm32l0xx.h \
  ..\Drivers\CMSIS\Device\ST\STM32L0xx\Include\stm32l071xx.h \
  ..\Drivers\CMSIS\Include\core_cm0plus.h \
  ..\Drivers\CMSIS\Device\ST\STM32L0xx\Include\system_stm32l0xx.h \
  ..\Drivers\STM32L0xx_HAL_Driver\Inc\stm32l0xx_ll_exti.h \
  ..\Drivers\STM32L0xx_HAL_Driver\Inc\stm32l0xx_ll_bus.h \
  ..\Drivers\STM32L0xx_HAL_Driver\Inc\stm32l0xx_ll_system.h
