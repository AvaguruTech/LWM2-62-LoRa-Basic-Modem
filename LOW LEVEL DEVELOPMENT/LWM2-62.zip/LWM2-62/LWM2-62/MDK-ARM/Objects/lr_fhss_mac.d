./objects/lr_fhss_mac.o: \
  ..\SWL2001-master\smtc_modem_core\radio_drivers\sx126x_driver\src\lr_fhss_mac.c \
  ..\SWL2001-master\smtc_modem_core\radio_drivers\sx126x_driver\src\lr_fhss_mac.h \
  ..\SWL2001-master\smtc_modem_core\radio_drivers\sx126x_driver\src\lr_fhss_v1_base_types.h
