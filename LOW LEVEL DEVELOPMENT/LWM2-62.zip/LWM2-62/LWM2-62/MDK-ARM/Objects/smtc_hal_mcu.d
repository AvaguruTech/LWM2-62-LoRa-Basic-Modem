./objects/smtc_hal_mcu.o: ..\SWL2001-master\smtc_hal_l0_LL\smtc_hal_mcu.c \
  ..\SWL2001-master\smtc_hal_l0_LL\smtc_hal_mcu.h \
  ..\SWL2001-master\smtc_hal_l0_LL\smtc_hal_dbg_trace.h \
  ..\SWL2001-master\smtc_hal_l0_LL\smtc_hal_trace.h \
  ..\SWL2001-master\modem_pinout.h \
  ..\SWL2001-master\smtc_hal_l0_LL\smtc_hal_gpio_pin_names.h \
  ..\SWL2001-master\smtc_hal_l0_LL\smtc_hal_gpio.h \
  ..\Drivers\STM32L0xx_HAL_Driver\Inc\stm32l0xx_ll_utils.h \
  ..\Drivers\CMSIS\Device\ST\STM32L0xx\Include\stm32l0xx.h \
  ..\Drivers\CMSIS\Device\ST\STM32L0xx\Include\stm32l071xx.h \
  ..\Drivers\CMSIS\Include\core_cm0plus.h \
  ..\Drivers\CMSIS\Device\ST\STM32L0xx\Include\system_stm32l0xx.h \
  ..\Drivers\STM32L0xx_HAL_Driver\Inc\stm32l0xx_ll_cortex.h \
  ..\Drivers\STM32L0xx_HAL_Driver\Inc\stm32l0xx_ll_pwr.h \
  ..\Drivers\STM32L0xx_HAL_Driver\Inc\stm32l0xx_ll_rcc.h \
  ..\Drivers\STM32L0xx_HAL_Driver\Inc\stm32l0xx_ll_system.h \
  ..\Drivers\STM32L0xx_HAL_Driver\Inc\stm32l0xx_ll_bus.h \
  ..\SWL2001-master\smtc_hal_l0_LL\smtc_hal_uart.h \
  ..\SWL2001-master\smtc_hal_l0_LL\smtc_hal_rtc.h \
  ..\SWL2001-master\smtc_hal_l0_LL\smtc_hal_spi.h \
  ..\SWL2001-master\smtc_hal_l0_LL\smtc_hal_lp_timer.h \
  ..\SWL2001-master\smtc_hal_l0_LL\smtc_hal_watchdog.h
