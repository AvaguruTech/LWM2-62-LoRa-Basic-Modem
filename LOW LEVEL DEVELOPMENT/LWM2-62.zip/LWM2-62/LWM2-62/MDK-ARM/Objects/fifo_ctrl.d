./objects/fifo_ctrl.o: \
  ..\SWL2001-master\smtc_modem_core\modem_utilities\fifo_ctrl.c \
  ..\SWL2001-master\smtc_modem_core\modem_utilities\fifo_ctrl.h \
  ..\SWL2001-master\smtc_modem_hal\smtc_modem_hal.h \
  ..\SWL2001-master\smtc_modem_core\logging\smtc_modem_hal_dbg_trace.h
