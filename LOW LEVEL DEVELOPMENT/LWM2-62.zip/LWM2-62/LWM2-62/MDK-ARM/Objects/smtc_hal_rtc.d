./objects/smtc_hal_rtc.o: ..\SWL2001-master\smtc_hal_l0_LL\smtc_hal_rtc.c \
  ..\SWL2001-master\smtc_hal_l0_LL\smtc_hal_rtc.h \
  ..\Drivers\STM32L0xx_HAL_Driver\Inc\stm32l0xx_ll_rtc.h \
  ..\Drivers\CMSIS\Device\ST\STM32L0xx\Include\stm32l0xx.h \
  ..\Drivers\CMSIS\Device\ST\STM32L0xx\Include\stm32l071xx.h \
  ..\Drivers\CMSIS\Include\core_cm0plus.h \
  ..\Drivers\CMSIS\Device\ST\STM32L0xx\Include\system_stm32l0xx.h \
  ..\Drivers\STM32L0xx_HAL_Driver\Inc\stm32l0xx_ll_rcc.h \
  ..\Drivers\STM32L0xx_HAL_Driver\Inc\stm32l0xx_ll_exti.h \
  ..\Drivers\STM32L0xx_HAL_Driver\Inc\stm32l0xx_ll_bus.h \
  ..\SWL2001-master\smtc_hal_l0_LL\smtc_hal_mcu.h \
  ..\SWL2001-master\smtc_hal_l0_LL\smtc_hal_dbg_trace.h \
  ..\SWL2001-master\smtc_hal_l0_LL\smtc_hal_trace.h
