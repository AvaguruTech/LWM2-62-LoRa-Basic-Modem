./objects/sx126x_lr_fhss.o: \
  ..\SWL2001-master\smtc_modem_core\radio_drivers\sx126x_driver\src\sx126x_lr_fhss.c \
  ..\SWL2001-master\smtc_modem_core\radio_drivers\sx126x_driver\src\lr_fhss_mac.h \
  ..\SWL2001-master\smtc_modem_core\radio_drivers\sx126x_driver\src\lr_fhss_v1_base_types.h \
  ..\SWL2001-master\smtc_modem_core\radio_drivers\sx126x_driver\src\sx126x_lr_fhss.h \
  ..\SWL2001-master\smtc_modem_core\radio_drivers\sx126x_driver\src\sx126x.h \
  ..\SWL2001-master\smtc_modem_core\radio_drivers\sx126x_driver\src\sx126x_status.h \
  ..\SWL2001-master\smtc_modem_core\radio_drivers\sx126x_driver\src\sx126x_hal.h
