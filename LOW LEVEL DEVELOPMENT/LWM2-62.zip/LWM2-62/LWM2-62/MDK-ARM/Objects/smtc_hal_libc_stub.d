./objects/smtc_hal_libc_stub.o: \
  ..\SWL2001-master\smtc_hal_l0_LL\smtc_hal_libc_stub.c \
  ..\SWL2001-master\smtc_hal_l0_LL\smtc_hal_mcu.h \
  ..\SWL2001-master\smtc_hal_l0_LL\smtc_hal_dbg_trace.h \
  ..\SWL2001-master\smtc_hal_l0_LL\smtc_hal_trace.h
