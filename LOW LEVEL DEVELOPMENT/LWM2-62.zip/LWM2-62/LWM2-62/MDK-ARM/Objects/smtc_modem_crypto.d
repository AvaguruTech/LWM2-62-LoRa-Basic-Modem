./objects/smtc_modem_crypto.o: \
  ..\SWL2001-master\smtc_modem_core\smtc_modem_crypto\smtc_modem_crypto.c \
  ..\SWL2001-master\smtc_modem_core\smtc_modem_crypto\smtc_modem_crypto.h \
  ..\SWL2001-master\smtc_modem_core\smtc_modem_crypto\smtc_secure_element\smtc_secure_element.h \
  ..\SWL2001-master\smtc_modem_core\logging\smtc_modem_hal_dbg_trace.h \
  ..\SWL2001-master\smtc_modem_hal\smtc_modem_hal.h
