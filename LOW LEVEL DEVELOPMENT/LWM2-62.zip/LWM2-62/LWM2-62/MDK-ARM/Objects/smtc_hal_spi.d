./objects/smtc_hal_spi.o: ..\SWL2001-master\smtc_hal_l0_LL\smtc_hal_spi.c \
  ..\SWL2001-master\smtc_hal_l0_LL\smtc_hal_spi.h \
  ..\SWL2001-master\smtc_hal_l0_LL\smtc_hal_gpio.h \
  ..\SWL2001-master\smtc_hal_l0_LL\smtc_hal_gpio_pin_names.h \
  ..\Drivers\STM32L0xx_HAL_Driver\Inc\stm32l0xx_ll_spi.h \
  ..\Drivers\CMSIS\Device\ST\STM32L0xx\Include\stm32l0xx.h \
  ..\Drivers\CMSIS\Device\ST\STM32L0xx\Include\stm32l071xx.h \
  ..\Drivers\CMSIS\Include\core_cm0plus.h \
  ..\Drivers\CMSIS\Device\ST\STM32L0xx\Include\system_stm32l0xx.h \
  ..\Drivers\STM32L0xx_HAL_Driver\Inc\stm32l0xx_ll_gpio.h \
  ..\Drivers\STM32L0xx_HAL_Driver\Inc\stm32l0xx_ll_bus.h \
  ..\SWL2001-master\modem_pinout.h
