./objects/radio_utilities.o: \
  ..\SWL2001-master\radio_hal\radio_utilities.c \
  ..\SWL2001-master\radio_hal\radio_utilities.h
