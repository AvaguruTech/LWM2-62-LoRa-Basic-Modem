./objects/aes.o: \
  ..\SWL2001-master\smtc_modem_core\smtc_modem_crypto\soft_secure_element\aes.c \
  ..\SWL2001-master\smtc_modem_core\smtc_modem_crypto\soft_secure_element\aes.h
