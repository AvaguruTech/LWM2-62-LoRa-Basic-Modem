./objects/sx126x.o: \
  ..\SWL2001-master\smtc_modem_core\radio_drivers\sx126x_driver\src\sx126x.c \
  ..\SWL2001-master\smtc_modem_core\radio_drivers\sx126x_driver\src\sx126x.h \
  ..\SWL2001-master\smtc_modem_core\radio_drivers\sx126x_driver\src\sx126x_status.h \
  ..\SWL2001-master\smtc_modem_core\radio_drivers\sx126x_driver\src\sx126x_hal.h \
  ..\SWL2001-master\smtc_modem_core\radio_drivers\sx126x_driver\src\sx126x_regs.h
