./objects/smtc_duty_cycle.o: \
  ..\SWL2001-master\smtc_modem_core\lr1mac\src\services\smtc_duty_cycle.c \
  ..\SWL2001-master\smtc_modem_core\lr1mac\src\services\smtc_duty_cycle.h \
  ..\SWL2001-master\smtc_modem_hal\smtc_modem_hal.h \
  ..\SWL2001-master\smtc_modem_core\logging\smtc_modem_hal_dbg_trace.h
