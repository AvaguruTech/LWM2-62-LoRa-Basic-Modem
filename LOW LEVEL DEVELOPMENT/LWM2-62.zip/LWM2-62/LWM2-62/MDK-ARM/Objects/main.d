./objects/main.o: main.c bsp_mcu.h \
  ..\Drivers\STM32L0xx_HAL_Driver\Inc\stm32l0xx_ll_rcc.h \
  ..\Drivers\CMSIS\Device\ST\STM32L0xx\Include\stm32l0xx.h \
  ..\Drivers\CMSIS\Device\ST\STM32L0xx\Include\stm32l071xx.h \
  ..\Drivers\CMSIS\Include\core_cm0plus.h \
  ..\Drivers\CMSIS\Device\ST\STM32L0xx\Include\system_stm32l0xx.h \
  ..\Drivers\STM32L0xx_HAL_Driver\Inc\stm32l0xx_ll_bus.h \
  ..\Drivers\STM32L0xx_HAL_Driver\Inc\stm32l0xx_ll_gpio.h \
  ..\Drivers\STM32L0xx_HAL_Driver\Inc\stm32l0xx_ll_usart.h \
  ..\Drivers\STM32L0xx_HAL_Driver\Inc\stm32l0xx_ll_i2c.h \
  ..\Drivers\STM32L0xx_HAL_Driver\Inc\stm32l0xx_ll_utils.h \
  ..\Drivers\STM32L0xx_HAL_Driver\Inc\stm32l0xx_ll_pwr.h \
  ..\Drivers\STM32L0xx_HAL_Driver\Inc\stm32l0xx_ll_exti.h \
  ..\Drivers\STM32L0xx_HAL_Driver\Inc\stm32l0xx_ll_system.h lora_app.h \
  ..\SWL2001-master\smtc_modem_api\smtc_modem_api.h sensor_manager.h
