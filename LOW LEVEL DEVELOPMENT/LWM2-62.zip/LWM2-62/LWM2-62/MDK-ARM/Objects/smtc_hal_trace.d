./objects/smtc_hal_trace.o: \
  ..\SWL2001-master\smtc_hal_l0_LL\smtc_hal_trace.c \
  ..\SWL2001-master\smtc_hal_l0_LL\smtc_hal_trace.h \
  ..\SWL2001-master\smtc_hal_l0_LL\smtc_hal_uart.h
