./objects/ralf_sx126x.o: \
  ..\SWL2001-master\smtc_modem_core\smtc_ralf\src\ralf_sx126x.c \
  ..\SWL2001-master\smtc_modem_core\smtc_ralf\src\ralf_sx126x.h \
  ..\SWL2001-master\smtc_modem_core\smtc_ral\src\ral_sx126x.h \
  ..\SWL2001-master\smtc_modem_core\smtc_ral\src\ral_defs.h \
  ..\SWL2001-master\smtc_modem_core\radio_drivers\sx126x_driver\src\lr_fhss_v1_base_types.h \
  ..\SWL2001-master\smtc_modem_core\smtc_ralf\src\ralf.h \
  ..\SWL2001-master\smtc_modem_core\smtc_ral\src\ral.h \
  ..\SWL2001-master\smtc_modem_core\smtc_ral\src\ral_drv.h \
  ..\SWL2001-master\smtc_modem_core\smtc_ralf\src\ralf_defs.h \
  ..\SWL2001-master\smtc_modem_core\smtc_ralf\src\ralf_drv.h
