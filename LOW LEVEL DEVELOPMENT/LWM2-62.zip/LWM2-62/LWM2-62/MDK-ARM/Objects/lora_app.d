./objects/lora_app.o: lora_app.c lora_app.h \
  ..\SWL2001-master\smtc_modem_api\smtc_modem_api.h bsp_mcu.h \
  ..\Drivers\STM32L0xx_HAL_Driver\Inc\stm32l0xx_ll_rcc.h \
  ..\Drivers\CMSIS\Device\ST\STM32L0xx\Include\stm32l0xx.h \
  ..\Drivers\CMSIS\Device\ST\STM32L0xx\Include\stm32l071xx.h \
  ..\Drivers\CMSIS\Include\core_cm0plus.h \
  ..\Drivers\CMSIS\Device\ST\STM32L0xx\Include\system_stm32l0xx.h \
  ..\Drivers\STM32L0xx_HAL_Driver\Inc\stm32l0xx_ll_bus.h \
  ..\Drivers\STM32L0xx_HAL_Driver\Inc\stm32l0xx_ll_gpio.h \
  ..\Drivers\STM32L0xx_HAL_Driver\Inc\stm32l0xx_ll_usart.h \
  ..\Drivers\STM32L0xx_HAL_Driver\Inc\stm32l0xx_ll_i2c.h \
  ..\Drivers\STM32L0xx_HAL_Driver\Inc\stm32l0xx_ll_utils.h \
  ..\Drivers\STM32L0xx_HAL_Driver\Inc\stm32l0xx_ll_pwr.h \
  ..\Drivers\STM32L0xx_HAL_Driver\Inc\stm32l0xx_ll_exti.h \
  ..\Drivers\STM32L0xx_HAL_Driver\Inc\stm32l0xx_ll_system.h \
  eeprom_manager.h sensor_manager.h \
  ..\SWL2001-master\smtc_hal_l0_LL\smtc_hal_mcu.h \
  ..\SWL2001-master\smtc_hal_l0_LL\smtc_hal_dbg_trace.h \
  ..\SWL2001-master\smtc_hal_l0_LL\smtc_hal_trace.h \
  ..\SWL2001-master\smtc_hal_l0_LL\smtc_hal_watchdog.h \
  ..\SWL2001-master\smtc_modem_hal\smtc_modem_hal.h \
  ..\SWL2001-master\smtc_modem_core\smtc_modem_crypto\smtc_modem_crypto.h \
  ..\SWL2001-master\smtc_modem_core\smtc_modem_crypto\smtc_secure_element\smtc_secure_element.h \
  ..\SWL2001-master\smtc_modem_core\radio_drivers\sx126x_driver\src\sx126x.h \
  ..\SWL2001-master\smtc_modem_core\radio_drivers\sx126x_driver\src\sx126x_status.h \
  ..\SWL2001-master\smtc_modem_core\radio_drivers\sx126x_driver\src\sx126x_hal.h \
  ..\SWL2001-master\smtc_modem_api\smtc_modem_utilities.h
