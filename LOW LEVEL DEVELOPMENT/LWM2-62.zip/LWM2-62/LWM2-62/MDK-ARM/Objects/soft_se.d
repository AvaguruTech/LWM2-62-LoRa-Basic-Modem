./objects/soft_se.o: \
  ..\SWL2001-master\smtc_modem_core\smtc_modem_crypto\soft_secure_element\soft_se.c \
  ..\SWL2001-master\smtc_modem_core\smtc_modem_crypto\smtc_secure_element\smtc_secure_element.h \
  ..\SWL2001-master\smtc_modem_core\smtc_modem_crypto\soft_secure_element\aes.h \
  ..\SWL2001-master\smtc_modem_core\smtc_modem_crypto\soft_secure_element\cmac.h \
  ..\SWL2001-master\smtc_modem_hal\smtc_modem_hal.h \
  ..\SWL2001-master\smtc_modem_core\logging\smtc_modem_hal_dbg_trace.h
