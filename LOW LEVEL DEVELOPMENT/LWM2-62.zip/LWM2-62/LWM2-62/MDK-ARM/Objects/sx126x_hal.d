./objects/sx126x_hal.o: ..\SWL2001-master\radio_hal\sx126x_hal.c \
  ..\SWL2001-master\smtc_modem_core\radio_drivers\sx126x_driver\src\sx126x_hal.h \
  ..\SWL2001-master\smtc_hal_l0_LL\smtc_hal_gpio.h \
  ..\SWL2001-master\smtc_hal_l0_LL\smtc_hal_gpio_pin_names.h \
  ..\SWL2001-master\smtc_hal_l0_LL\smtc_hal_spi.h \
  ..\SWL2001-master\smtc_hal_l0_LL\smtc_hal_mcu.h \
  ..\SWL2001-master\smtc_hal_l0_LL\smtc_hal_dbg_trace.h \
  ..\SWL2001-master\smtc_hal_l0_LL\smtc_hal_trace.h \
  ..\SWL2001-master\modem_pinout.h
