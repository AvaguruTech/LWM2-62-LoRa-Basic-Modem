./objects/lr1mac_utilities.o: \
  ..\SWL2001-master\smtc_modem_core\lr1mac\src\lr1mac_utilities.c \
  ..\SWL2001-master\smtc_modem_core\lr1mac\src\lr1mac_utilities.h \
  ..\SWL2001-master\smtc_modem_core\smtc_ral\src\ral_defs.h \
  ..\SWL2001-master\smtc_modem_core\radio_drivers\sx126x_driver\src\lr_fhss_v1_base_types.h \
  ..\SWL2001-master\smtc_modem_core\lr1mac\src\lr1mac_defs.h \
  ..\SWL2001-master\smtc_modem_core\smtc_modem_crypto\smtc_secure_element\smtc_secure_element.h \
  ..\SWL2001-master\smtc_modem_hal\smtc_modem_hal.h \
  ..\SWL2001-master\smtc_modem_core\logging\smtc_modem_hal_dbg_trace.h
