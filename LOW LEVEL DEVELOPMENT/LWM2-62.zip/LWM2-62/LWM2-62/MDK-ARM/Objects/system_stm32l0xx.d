./objects/system_stm32l0xx.o: ..\Core\src\system_stm32l0xx.c \
  ..\Drivers\CMSIS\Device\ST\STM32L0xx\Include\stm32l0xx.h \
  ..\Drivers\CMSIS\Device\ST\STM32L0xx\Include\stm32l071xx.h \
  ..\Drivers\CMSIS\Include\core_cm0plus.h \
  ..\Drivers\CMSIS\Device\ST\STM32L0xx\Include\system_stm32l0xx.h
