./objects/cmd_parser.o: ..\SWL2001-master\hw_modem\cmd_parser.c \
  ..\SWL2001-master\hw_modem\cmd_parser.h \
  ..\SWL2001-master\smtc_modem_api\smtc_modem_api.h \
  ..\SWL2001-master\smtc_modem_api\smtc_modem_test_api.h \
  ..\SWL2001-master\smtc_modem_core\smtc_ral\src\ral_defs.h \
  ..\SWL2001-master\smtc_modem_core\radio_drivers\sx126x_driver\src\lr_fhss_v1_base_types.h \
  ..\SWL2001-master\smtc_modem_hal\smtc_modem_hal.h \
  ..\SWL2001-master\smtc_hal_l0_LL\smtc_hal_dbg_trace.h \
  ..\SWL2001-master\smtc_hal_l0_LL\smtc_hal_trace.h \
  ..\SWL2001-master\modem_pinout.h \
  ..\SWL2001-master\smtc_hal_l0_LL\smtc_hal_gpio_pin_names.h \
  ..\SWL2001-master\smtc_hal_l0_LL\smtc_hal_gpio.h \
  ..\SWL2001-master\smtc_hal_l0_LL\smtc_hal_mcu.h \
  ..\SWL2001-master\radio_hal\radio_utilities.h
