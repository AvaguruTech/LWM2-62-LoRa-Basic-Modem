./objects/ral_sx126x_bsp.o: ..\SWL2001-master\radio_hal\ral_sx126x_bsp.c \
  ..\SWL2001-master\smtc_modem_core\smtc_ral\src\ral_sx126x_bsp.h \
  ..\SWL2001-master\smtc_modem_core\smtc_ral\src\ral_defs.h \
  ..\SWL2001-master\smtc_modem_core\radio_drivers\sx126x_driver\src\lr_fhss_v1_base_types.h \
  ..\SWL2001-master\smtc_modem_core\radio_drivers\sx126x_driver\src\sx126x.h \
  ..\SWL2001-master\smtc_modem_core\radio_drivers\sx126x_driver\src\sx126x_status.h \
  ..\SWL2001-master\radio_hal\radio_utilities.h
