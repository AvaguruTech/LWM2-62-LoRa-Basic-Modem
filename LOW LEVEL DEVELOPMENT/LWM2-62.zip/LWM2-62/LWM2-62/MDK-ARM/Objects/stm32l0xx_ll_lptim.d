./objects/stm32l0xx_ll_lptim.o: \
  ..\Drivers\STM32L0xx_HAL_Driver\Src\stm32l0xx_ll_lptim.c \
  ..\Drivers\STM32L0xx_HAL_Driver\Inc\stm32l0xx_ll_lptim.h \
  ..\Drivers\CMSIS\Device\ST\STM32L0xx\Include\stm32l0xx.h \
  ..\Drivers\CMSIS\Device\ST\STM32L0xx\Include\stm32l071xx.h \
  ..\Drivers\CMSIS\Include\core_cm0plus.h \
  ..\Drivers\CMSIS\Device\ST\STM32L0xx\Include\system_stm32l0xx.h \
  ..\Drivers\STM32L0xx_HAL_Driver\Inc\stm32l0xx_ll_bus.h \
  ..\Drivers\STM32L0xx_HAL_Driver\Inc\stm32l0xx_ll_rcc.h
