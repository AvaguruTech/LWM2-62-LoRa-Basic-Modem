/**
 * @file      main.c
 * @brief     Firmware Entry Point & Orchestrator
 *
 * Boots low-level microcontroller clock trees and peripherals, then hands over
 * control directly to the autonomous LoRaWAN application loop.
 */

#include <stdint.h>
#include <stdbool.h>

#include "bsp_mcu.h"
#include "lora_app.h"
#include "sensor_manager.h"
int main( void )
{
    // 1. Give power rails and SX1262 radio time to stabilize on cold boot / flash
    for( volatile uint32_t i = 0; i < 500000; i++ ) { __NOP(); }

    // 2. Low-level hardware initialization (PLL, Clocks, UART, I2C)
    bsp_mcu_init();

    // 3. Execute self-healing LoRaWAN / P2P application loop
    main_periodical_uplink();

    // 4. Safety trap: should never reach here
    while( 1 )
    {
        bsp_watchdog_reload();
    }

    return 0;
}