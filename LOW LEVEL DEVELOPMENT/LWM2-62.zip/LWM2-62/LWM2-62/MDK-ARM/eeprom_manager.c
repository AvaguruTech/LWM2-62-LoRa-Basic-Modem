/**
 * @file      eeprom_manager.c
 * @brief     EEPROM-First Provisioning Controller for LoRaWAN Credentials, Keys & Multicast
 */

#include "eeprom_manager.h"
#include "stm32l0xx_hal.h"
#include "smtc_hal_dbg_trace.h"
#include <string.h>

static int eeprom_stricmp( const char *a, const char *b )
{
    for( ;; )
    {
        char ca = *a++;
        char cb = *b++;
        if( ( ca >= 'a' ) && ( ca <= 'z' ) ) ca = ( char )( ca - 32 );
        if( ( cb >= 'a' ) && ( cb <= 'z' ) ) cb = ( char )( cb - 32 );
        if( ca != cb ) return ( int ) ( unsigned char ) ca - ( int ) ( unsigned char ) cb;
        if( ca == '\0' ) return 0;
    }
}
#define strcasecmp eeprom_stricmp

#define DATA_EEPROM_BASE_ADDR    0x08080000U
#define DATA_EEPROM_END_ADDR     0x080817FFU
#define FACTORY_ID_ADDR          DATA_EEPROM_BASE_ADDR
#define APP_EEPROM_ADDR          ( DATA_EEPROM_BASE_ADDR + 0x100U )
#define BACKUP_EEPROM_ADDR       ( DATA_EEPROM_BASE_ADDR + 0x180U )
#define EEPROM_MAGIC_VALID       0x4C6F5233U   /* "LoR3" */

#define EEPROM_ALL_ERR_FLAGS ( FLASH_FLAG_WRPERR | FLASH_FLAG_PGAERR | FLASH_FLAG_SIZERR | \
                             FLASH_FLAG_OPTVERR | FLASH_FLAG_RDERR | FLASH_FLAG_FWWERR | \
                             FLASH_FLAG_NOTZEROERR )

volatile uint32_t g_eeprom_guard_hits      = 0;
volatile uint32_t g_eeprom_guard_last_addr = 0;

static uint32_t s_reserved_fcnt_up   = 0;
static uint32_t s_reserved_fcnt_down = 0;

static uint32_t crc32_calc( const void *data, uint32_t len )
{
    const uint8_t *p   = ( const uint8_t * ) data;
    uint32_t        crc = 0xFFFFFFFFU;

    while( len-- )
    {
        crc ^= *p++;
        for( uint32_t i = 0; i < 8U; i++ )
        {
            crc = ( crc & 1U ) ? ( ( crc >> 1 ) ^ 0xEDB88320U ) : ( crc >> 1 );
        }
    }
    return ~crc;
}

static bool eeprom_raw_program_word( uint32_t addr, uint32_t value )
{
    uint32_t t;

    if( *( volatile uint32_t * ) addr == value )
    {
        return true; 
    }

    for( t = 1000000U; ( t > 0U ) && ( FLASH->SR & FLASH_SR_BSY ); t-- ) { }
    __HAL_FLASH_CLEAR_FLAG( EEPROM_ALL_ERR_FLAGS | FLASH_FLAG_EOP );

    *( volatile uint32_t * ) addr = value;

    for( t = 1000000U; ( t > 0U ) && ( FLASH->SR & FLASH_SR_BSY ); t-- ) { }
    __HAL_FLASH_CLEAR_FLAG( FLASH_FLAG_EOP );

    return ( *( volatile uint32_t * ) addr == value );
}

static bool factory_write_bytes( uint32_t offset, const uint8_t *data, uint32_t len )
{
    bool ok = true;

    if( ( ( len & 3U ) != 0U ) || ( ( offset & 3U ) != 0U ) || ( ( offset + len ) > 12U ) )
    {
        return false;
    }

    HAL_FLASHEx_DATAEEPROM_Unlock( );
    __HAL_FLASH_CLEAR_FLAG( EEPROM_ALL_ERR_FLAGS );

    for( uint32_t i = 0; i < len; i += 4U )
    {
        uint32_t w;
        memcpy( &w, data + i, 4 );
        if( !eeprom_raw_program_word( FACTORY_ID_ADDR + offset + i, w ) )
        {
            ok = false;
            break;
        }
    }

    HAL_FLASHEx_DATAEEPROM_Lock( );

    if( ok )
    {
        const volatile uint8_t *p = ( const volatile uint8_t * )( FACTORY_ID_ADDR + offset );
        for( uint32_t i = 0; i < len; i++ )
        {
            if( p[i] != data[i] )
            {
                ok = false;
                break;
            }
        }
    }
    return ok;
}

void eeprom_get_hardware_uid_ids( uint8_t dev_eui[8], uint32_t *dev_addr )
{
    const uint8_t *uid = ( const uint8_t * ) 0x1FF80050U;
    uint32_t hash = 0x811C9DC5U;

    for( uint32_t i = 0; i < 12U; i++ )
    {
        hash ^= uid[i];
        hash *= 0x01000193U;
    }

    if( ( hash == 0x00000000U ) || ( hash == 0xFFFFFFFFU ) )
    {
        hash = 0x31560328U;
    }

    dev_eui[0] = 0x5F;
    dev_eui[1] = 0x6A;
    dev_eui[2] = 0x23;
    dev_eui[3] = 0x00;
    dev_eui[4] = ( uint8_t )( hash >> 24 );
    dev_eui[5] = ( uint8_t )( hash >> 16 );
    dev_eui[6] = ( uint8_t )( hash >> 8 );
    dev_eui[7] = ( uint8_t )( hash );

    *dev_addr = hash;
}

static bool ids_decode( const uint8_t b[12], uint8_t dev_eui[8], uint32_t *dev_addr )
{
    uint32_t zeros = 0, ffs = 0;

    for( uint32_t i = 0; i < 12U; i++ )
    {
        if( b[i] == 0x00U ) zeros++;
        if( b[i] == 0xFFU ) ffs++;
    }

    if( ( zeros >= 12U ) || ( ffs >= 12U ) ) return false;

    memcpy( dev_eui, &b[0], 8 );

    *dev_addr = ( ( uint32_t ) b[8] << 24 ) | ( ( uint32_t ) b[9] << 16 ) |
                ( ( uint32_t ) b[10] << 8 ) | ( ( uint32_t ) b[11] );

    return true;
}

bool eeprom_get_factory_ids( uint8_t dev_eui[8], uint32_t *dev_addr )
{
    const volatile uint8_t *p = ( const volatile uint8_t * ) FACTORY_ID_ADDR;
    uint8_t b[12];

    for( uint32_t i = 0; i < 12U; i++ )
    {
        b[i] = p[i];
    }

    if( ids_decode( b, dev_eui, dev_addr ) )
    {
        return true;
    }

    eeprom_get_hardware_uid_ids( dev_eui, dev_addr );

    uint8_t addr_bytes[4];
    addr_bytes[0] = ( uint8_t )( *dev_addr >> 24 );
    addr_bytes[1] = ( uint8_t )( *dev_addr >> 16 );
    addr_bytes[2] = ( uint8_t )( *dev_addr >> 8 );
    addr_bytes[3] = ( uint8_t )( *dev_addr );

    ( void ) factory_write_bytes( 0U, dev_eui, 8U );
    ( void ) factory_write_bytes( 8U, addr_bytes, 4U );

    return true;
}

eeprom_id_source_t eeprom_get_device_ids( uint8_t dev_eui[8], uint32_t *dev_addr )
{
    eeprom_get_factory_ids( dev_eui, dev_addr );
    return EEPROM_ID_FACTORY;
}

void eeprom_print_ids( void )
{
    uint8_t  eui[8];
    uint32_t addr = 0;
    eeprom_get_factory_ids( eui, &addr );

    SMTC_HAL_TRACE_INFO( "\r\n[EEPROM] Active DevEUI %02X%02X%02X%02X%02X%02X%02X%02X | DevAddr 0x%08lX\r\n",
                         ( unsigned ) eui[0], ( unsigned ) eui[1], ( unsigned ) eui[2], ( unsigned ) eui[3],
                         ( unsigned ) eui[4], ( unsigned ) eui[5], ( unsigned ) eui[6], ( unsigned ) eui[7],
                         ( unsigned long ) addr );
    SMTC_HAL_TRACE_INFO( "[EEPROM] HAL guard hits: %lu (last addr 0x%08lX)\r\n> ",
                         ( unsigned long ) g_eeprom_guard_hits, ( unsigned long ) g_eeprom_guard_last_addr );
}

bool eeprom_factory_area_intact( void )
{
    return true;
}

void eeprom_manager_init( void )
{
    __HAL_FLASH_CLEAR_FLAG( EEPROM_ALL_ERR_FLAGS );
}

static bool eeprom_addr_allowed( uint32_t address, uint32_t len )
{
    if( len == 0U ) return false;
    return ( address >= APP_EEPROM_ADDR ) && ( ( address + len - 1U ) <= DATA_EEPROM_END_ADDR );
}

static void eeprom_read_bytes( uint32_t addr, void *dst, uint32_t len )
{
    for( uint32_t i = 0; i < len; i += 4U )
    {
        uint32_t w = *( volatile uint32_t * )( addr + i );
        memcpy( ( uint8_t * ) dst + i, &w, 4 );
    }
}

static bool eeprom_write_words_diff( uint32_t addr, const void *src, uint32_t len )
{
    bool unlocked = false;
    bool ok        = true;

    if( !eeprom_addr_allowed( addr, len ) || ( ( len & 3U ) != 0U ) || ( ( addr & 3U ) != 0U ) )
    {
        return false;
    }

    for( uint32_t i = 0; i < len; i += 4U )
    {
        uint32_t w;
        memcpy( &w, ( const uint8_t * ) src + i, 4 );

        if( *( volatile uint32_t * )( addr + i ) != w )
        {
            if( !unlocked )
            {
                HAL_FLASHEx_DATAEEPROM_Unlock( );
                __HAL_FLASH_CLEAR_FLAG( EEPROM_ALL_ERR_FLAGS );
                unlocked = true;
            }
            if( !eeprom_raw_program_word( addr + i, w ) )
            {
                ok = false;
                break;
            }
        }
    }

    if( unlocked )
    {
        HAL_FLASHEx_DATAEEPROM_Lock( );
    }
    return ok;
}

static void eeprom_raw_write_word( uint32_t address, uint32_t data )
{
    ( void ) eeprom_write_words_diff( address, &data, 4U );
}

static uint32_t cfg_calc_crc( const lora_eeprom_config_t *c )
{
    return crc32_calc( c, ( uint32_t ) offsetof( lora_eeprom_config_t, keys_crc ) );
}

static bool cfg_keys_valid( const lora_eeprom_config_t *c )
{
    return ( c->magic_word == EEPROM_MAGIC_VALID ) && ( c->keys_crc == cfg_calc_crc( c ) );
}

static void cfg_apply_keys( lora_eeprom_config_t *c, const lora_credentials_t *k )
{
    c->magic_word = EEPROM_MAGIC_VALID;
    memcpy( c->join_eui,    k->join_eui,    8 );
    memcpy( c->app_key,     k->app_key,     16 );
    memcpy( c->gen_app_key, k->gen_app_key, 16 );
    memcpy( c->nwk_s_key,   k->nwk_s_key,   16 );
    memcpy( c->app_s_key,   k->app_s_key,   16 );
    c->keys_crc = cfg_calc_crc( c );
}

static void active_fill( lora_credentials_t *a, const uint8_t dev_eui[8], uint32_t dev_addr,
                         const lora_eeprom_config_t *c )
{
    memset( a, 0, sizeof( *a ) );
    memcpy( a->dev_eui,      dev_eui,        8 );
    a->dev_addr = dev_addr;
    memcpy( a->join_eui,     c->join_eui,    8 );
    memcpy( a->app_key,      c->app_key,     16 );
    memcpy( a->gen_app_key,  c->gen_app_key, 16 );
    memcpy( a->nwk_s_key,    c->nwk_s_key,   16 );
    memcpy( a->app_s_key,    c->app_s_key,   16 );
}

eeprom_sync_result_t eeprom_sync_credentials( const lora_credentials_t *wanted, bool force_reset,
                                              lora_credentials_t *active, uint32_t *fcnt_up, uint32_t *fcnt_down )
{
    lora_eeprom_config_t stored;
    lora_eeprom_config_t desired;
    uint8_t              dev_eui[8];
    uint32_t             dev_addr = 0;

    eeprom_get_factory_ids( dev_eui, &dev_addr );
    eeprom_read_bytes( APP_EEPROM_ADDR, &stored, sizeof( stored ) );

    if( !cfg_keys_valid( &stored ) || force_reset )
    {
        memset( &desired, 0, sizeof( desired ) );
        cfg_apply_keys( &desired, wanted );
        desired.fcnt_up   = FCNT_RESERVATION_BLOCK_SIZE;
        desired.fcnt_down = FCNT_RESERVATION_BLOCK_SIZE;
        ( void ) eeprom_write_words_diff( APP_EEPROM_ADDR, &desired, sizeof( desired ) );
        eeprom_read_bytes( APP_EEPROM_ADDR, &stored, sizeof( stored ) );
    }

    active_fill( active, dev_eui, dev_addr, &stored );

    *fcnt_up   = stored.fcnt_up;
    *fcnt_down = stored.fcnt_down;

    s_reserved_fcnt_up   = stored.fcnt_up + FCNT_RESERVATION_BLOCK_SIZE;
    s_reserved_fcnt_down = stored.fcnt_down + FCNT_RESERVATION_BLOCK_SIZE;
    eeprom_raw_write_word( APP_EEPROM_ADDR + offsetof( lora_eeprom_config_t, fcnt_up ), s_reserved_fcnt_up );
    eeprom_raw_write_word( APP_EEPROM_ADDR + offsetof( lora_eeprom_config_t, fcnt_down ), s_reserved_fcnt_down );

    return EEPROM_SYNC_OK;
}

void eeprom_update_fcnt_up( uint32_t current_ram_fcnt_up )
{
    if( current_ram_fcnt_up >= s_reserved_fcnt_up )
    {
        s_reserved_fcnt_up = current_ram_fcnt_up + FCNT_RESERVATION_BLOCK_SIZE;
        eeprom_raw_write_word( APP_EEPROM_ADDR + offsetof( lora_eeprom_config_t, fcnt_up ), s_reserved_fcnt_up );
    }
}

void eeprom_update_fcnt_down( uint32_t current_ram_fcnt_down )
{
    if( current_ram_fcnt_down >= s_reserved_fcnt_down )
    {
        s_reserved_fcnt_down = current_ram_fcnt_down + FCNT_RESERVATION_BLOCK_SIZE;
        eeprom_raw_write_word( APP_EEPROM_ADDR + offsetof( lora_eeprom_config_t, fcnt_down ), s_reserved_fcnt_down );
    }
}

static void print_key_line( const char *name, const uint8_t *p, uint8_t n )
{
    static const char hx[] = "0123456789ABCDEF";
    char buf[33]; 

    if( n > 16U ) n = 16U;
    for( uint8_t i = 0; i < n; i++ )
    {
        buf[i * 2U]      = hx[p[i] >> 4];
        buf[i * 2U + 1U] = hx[p[i] & 0x0FU];
    }
    buf[n * 2U] = '\0';
    SMTC_HAL_TRACE_INFO( "  %-10s %s\r\n", name, buf );
}

void eeprom_print_keys( void )
{
    lora_eeprom_config_t c;
    eeprom_read_bytes( APP_EEPROM_ADDR, &c, sizeof( c ) );

    SMTC_HAL_TRACE_INFO( "\r\n[EEPROM] magic=%s crc=%s fcnt_up=%lu fcnt_down=%lu\r\n",
                         ( c.magic_word == EEPROM_MAGIC_VALID ) ? "OK" : "BAD",
                         ( c.keys_crc == cfg_calc_crc( &c ) ) ? "OK" : "BAD",
                         ( unsigned long ) c.fcnt_up, ( unsigned long ) c.fcnt_down );
    print_key_line( "JOINEUI",   c.join_eui,    8 );
    print_key_line( "APPKEY",    c.app_key,     16 );
    print_key_line( "GENAPPKEY", c.gen_app_key, 16 );
    print_key_line( "NWKSKEY",   c.nwk_s_key,   16 );
    print_key_line( "APPSKEY",   c.app_s_key,   16 );
    SMTC_HAL_TRACE_INFO( "> " );
}

bool eeprom_manager_update_key( const char *key_name, uint8_t length, const uint8_t *data )
{
    if( ( strcasecmp( key_name, "DEVEUI" ) == 0 ) && ( length == 8 ) )
    {
        bool ok = factory_write_bytes( 0U, data, 8U );
        if( !ok )
        {
            SMTC_HAL_TRACE_ERROR( "\r\n[CFG] DEVEUI write/verify FAILED (guard hits=%lu)\r\n",
                                  ( unsigned long ) g_eeprom_guard_hits );
        }
        return ok;
    }
    else if( ( strcasecmp( key_name, "DEVADDR" ) == 0 ) && ( length == 4 ) )
    {
        bool ok = factory_write_bytes( 8U, data, 4U );
        if( !ok )
        {
            SMTC_HAL_TRACE_ERROR( "\r\n[CFG] DEVADDR write/verify FAILED (guard hits=%lu)\r\n",
                                  ( unsigned long ) g_eeprom_guard_hits );
        }
        return ok;
    }

    lora_eeprom_config_t cfg;
    eeprom_read_bytes( APP_EEPROM_ADDR, &cfg, sizeof( cfg ) );

    if( cfg.magic_word != EEPROM_MAGIC_VALID )
    {
        SMTC_HAL_TRACE_ERROR( "\r\n[CFG] Key block not initialised yet (reboot once first)\r\n" );
        return false;
    }

    bool matched = false;
    if( ( strcasecmp( key_name, "JOINEUI" ) == 0 ) && ( length == 8 ) )
    {
        memcpy( cfg.join_eui, data, 8 ); matched = true;
    }
    else if( ( strcasecmp( key_name, "APPKEY" ) == 0 ) && ( length == 16 ) )
    {
        memcpy( cfg.app_key, data, 16 ); matched = true;
    }
    else if( ( strcasecmp( key_name, "GENAPPKEY" ) == 0 ) && ( length == 16 ) )
    {
        memcpy( cfg.gen_app_key, data, 16 ); matched = true;
    }
    else if( ( strcasecmp( key_name, "NWKSKEY" ) == 0 ) && ( length == 16 ) )
    {
        memcpy( cfg.nwk_s_key, data, 16 ); matched = true;
        cfg.fcnt_up = 0; cfg.fcnt_down = 0;   
    }
    else if( ( strcasecmp( key_name, "APPSKEY" ) == 0 ) && ( length == 16 ) )
    {
        memcpy( cfg.app_s_key, data, 16 ); matched = true;
        cfg.fcnt_up = 0; cfg.fcnt_down = 0;   
    }

    if( !matched )
    {
        return false;
    }

    cfg.keys_crc = cfg_calc_crc( &cfg );
    if( !eeprom_write_words_diff( APP_EEPROM_ADDR, &cfg, sizeof( cfg ) ) )
    {
        return false;
    }

    lora_eeprom_config_t check;
    eeprom_read_bytes( APP_EEPROM_ADDR, &check, sizeof( check ) );
    return cfg_keys_valid( &check ) && ( memcmp( &check, &cfg, sizeof( cfg ) ) == 0 );
}

/* ============================================================================
 * Multicast persistence: double-buffered (A/B) slots with magic + seq + CRC
 * ========================================================================== */

#define MC_BLOB_MAGIC   0x4D433032U   /* "MC02" - bump if the stored layout changes */

typedef struct
{
    uint32_t magic;
    uint32_t seq;     /* higher = newer */
    uint32_t len;     /* payload length in bytes (unpadded) */
    uint32_t crc;     /* crc32 over the padded payload */
} mc_blob_hdr_t;

static uint32_t mc_slot_addr( uint8_t slot )
{
    return EEPROM_MULTICAST_ADDR + ( uint32_t ) slot * EEPROM_MULTICAST_SLOT_SIZE;
}

/* Returns true if the slot holds a valid blob of exactly 'length' bytes.
 * On success *seq is its sequence number and, if out != NULL, payload is copied to it. */
static bool mc_slot_check( uint8_t slot, uint16_t length, uint32_t *seq, uint8_t *out )
{
    uint8_t       buf[EEPROM_MULTICAST_SLOT_SIZE];
    mc_blob_hdr_t hdr;
    uint32_t      padded = ( ( uint32_t ) length + 3U ) & ~3U;

    eeprom_read_bytes( mc_slot_addr( slot ), buf, EEPROM_MULTICAST_HDR_SIZE + padded );
    memcpy( &hdr, buf, sizeof( hdr ) );

    if( ( hdr.magic != MC_BLOB_MAGIC ) || ( hdr.len != length ) ) return false;
    if( hdr.crc != crc32_calc( buf + EEPROM_MULTICAST_HDR_SIZE, padded ) ) return false;

    if( seq != NULL ) *seq = hdr.seq;
    if( out != NULL ) memcpy( out, buf + EEPROM_MULTICAST_HDR_SIZE, length );
    return true;
}

bool eeprom_manager_save_multicast( const uint8_t *data, uint16_t length )
{
    uint8_t       buf[EEPROM_MULTICAST_SLOT_SIZE];
    mc_blob_hdr_t hdr;
    uint32_t      padded = ( ( uint32_t ) length + 3U ) & ~3U;
    uint32_t      total  = EEPROM_MULTICAST_HDR_SIZE + padded;
    uint32_t      seq[EEPROM_MULTICAST_SLOTS] = { 0 };
    bool          valid[EEPROM_MULTICAST_SLOTS];
    uint8_t       target;
    uint32_t      new_seq;

    if( ( data == NULL ) || ( length == 0U ) || ( length > EEPROM_MULTICAST_MAX_LEN ) ) return false;

    for( uint8_t s = 0; s < EEPROM_MULTICAST_SLOTS; s++ )
    {
        valid[s] = mc_slot_check( s, length, &seq[s], NULL );
        if( !valid[s] ) seq[s] = 0;
    }

    /* write into the slot that is NOT the newest valid one */
    if( valid[0] && valid[1] ) target = ( seq[0] > seq[1] ) ? 1U : 0U;
    else if( valid[0] )        target = 1U;
    else if( valid[1] )        target = 0U;
    else                       target = 0U;

    new_seq = ( ( seq[0] > seq[1] ) ? seq[0] : seq[1] ) + 1U;
    if( new_seq == 0U ) new_seq = 1U;

    memset( buf, 0, sizeof( buf ) );
    memcpy( buf + EEPROM_MULTICAST_HDR_SIZE, data, length );

    hdr.magic = MC_BLOB_MAGIC;
    hdr.seq   = new_seq;
    hdr.len   = length;
    hdr.crc   = crc32_calc( buf + EEPROM_MULTICAST_HDR_SIZE, padded );
    memcpy( buf, &hdr, sizeof( hdr ) );

    if( !eeprom_write_words_diff( mc_slot_addr( target ), buf, total ) ) return false;

    /* read-back verification: the new slot must now validate with our seq */
    {
        uint32_t chk_seq = 0;
        if( !mc_slot_check( target, length, &chk_seq, NULL ) || ( chk_seq != new_seq ) ) return false;
    }
    return true;
}

bool eeprom_manager_load_multicast( uint8_t *data, uint16_t length )
{
    uint32_t seq[EEPROM_MULTICAST_SLOTS] = { 0 };
    bool     valid[EEPROM_MULTICAST_SLOTS];
    uint8_t  pick;

    if( ( data == NULL ) || ( length == 0U ) || ( length > EEPROM_MULTICAST_MAX_LEN ) ) return false;

    for( uint8_t s = 0; s < EEPROM_MULTICAST_SLOTS; s++ )
    {
        valid[s] = mc_slot_check( s, length, &seq[s], NULL );
    }

    if( valid[0] && valid[1] ) pick = ( seq[0] >= seq[1] ) ? 0U : 1U;
    else if( valid[0] )        pick = 0U;
    else if( valid[1] )        pick = 1U;
    else                       return false;

    return mc_slot_check( pick, length, NULL, data );
}

bool eeprom_manager_erase_multicast( void )
{
    static const uint32_t zero[EEPROM_MULTICAST_HDR_SIZE / 4U] = { 0 };
    bool ok = true;

    for( uint8_t s = 0; s < EEPROM_MULTICAST_SLOTS; s++ )
    {
        ok = eeprom_write_words_diff( mc_slot_addr( s ), zero, sizeof( zero ) ) && ok;
    }
    return ok;
}